# BBounty Pro v3.3-zen

> **Professional Bug Bounty Automation Platform** — Self-hosted, VPS-only.  
> Go orchestrator · Python AI agent · Next.js 15 dashboard · 78 tools · 34 pipeline optimizations · Claude + Gemini AI

[![go build](https://img.shields.io/badge/go%20build-passing-54b35f?style=flat-square)](/)
[![go test -race](https://img.shields.io/badge/go%20test%20-race-passing-54b35f?style=flat-square)](/)
[![tools](https://img.shields.io/badge/tools-78%2F78-00e5cc?style=flat-square)](/)
[![license](https://img.shields.io/badge/license-MIT-7c6aff?style=flat-square)](/)

---

## What it does

BBounty Pro automates the full bug bounty workflow — from subdomain enumeration to submission-ready report — in **6–9 minutes per target**.

```
subfinder → puredns → httpx → [57 tools parallel] → Claude Code → H1/Bugcrowd report
```

Every tool receives the correct input from the previous tool. No hardcoded paths. No generic targets. 34 conditional chains based on what's actually found.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────────────┐
│              nginx 1.30+ (TLS 1.3, HSTS, CSP, rate limit)           │
└──────────────────────────┬──────────────────────────────────────────┘
                           │
         ┌─────────────────┴─────────────────┐
         │                                   │
┌────────▼────────┐               ┌──────────▼──────────────────────────────┐
│   Next.js 15    │               │   Go Orchestrator (port 8080)           │
│   Dashboard     │               │                                         │
│                 │◄──WebSocket───│   Pipeline: ANALYZE → PLAN              │
│   • Live scan   │               │           → EXECUTE → ITERATE           │
│   • Findings    │               │                                         │
│   • Billing     │               │   ├─ 78-tool registry                   │
│   • Reports     │               │   ├─ 64 dedicated executor cases        │
│   • 2FA / Auth  │               │   ├─ 34 conditional chain optimizations │
│                 │               │   ├─ Dead scan janitor (15min)          │
└─────────────────┘               │   ├─ Session janitor (6h)               │
                                  │   ├─ Asset DB + diff engine             │
                                  │   ├─ Native CORS engine (7 vectors)     │
                                  │   ├─ ROE Gate + SafeTarget validation   │
                                  │   ├─ Stripe billing + scan limits       │
                                  │   └─ JWT + CSRF + httpOnly cookies      │
                                  └──────────┬──────────────────────────────┘
                                             │
                    ┌────────────────────────┼────────────────────┐
                    │                        │                    │
         ┌──────────▼──────────┐  ┌─────────▼──────┐  ┌────────▼────────┐
         │  Python Ultra Agent │  │  FastAPI        │  │  Redis 7.4      │
         │  (ultra_agent.py)   │  │  AI Proxy       │  │  + PostgreSQL   │
         │                     │  │                 │  │                 │
         │  10 modules parallel│  │  Anthropic      │  │  Findings store │
         │  Phase 1: recon     │  │  Claude primary │  │  Scan state     │
         │  Phase 2: report    │  │  Gemini fallback│  │  Asset DB       │
         │                     │  │                 │  │  Sessions       │
         │  • 48 secret patterns│  │  System prompt  │  │  Diff snapshots │
         │  • 15 always-on HTTP │  │  v3 + injection │  │  Scan limits    │
         │  • API security module│  │  defense        │  │                 │
         │  • cariddi processor │  │                 │  │  requirepass    │
         │  • interactsh OOB   │  │                 │  │  FLUSHALL off   │
         │  • notify (Telegram)│  │                 │  │  maxmemory 25%  │
         │  • bountyplz submit │  │                 │  │  AOF everysec   │
         └─────────────────────┘  └─────────────────┘  └─────────────────┘
```

---

## 78 Integrated Tools

**Phase ANALYZE — Recon (parallel):**
subfinder · assetfinder · bbot · chaos-client · dnsx · puredns · alterx · dnsvalidator · emailfinder · metagoofil

**Phase PLAN — Enumeration (parallel):**
httpx · whatweb · wafw00f · naabu · nmap · aquatone · gowitness · hakrawler · gospider · katana · cariddi · waybackurls · gau · gf · kxss · arjun · paramspider · freq · linkfinder · gitleaks · trufflehog · secretfinder · mantra · porch-pirate · leaksearch

**Phase EXECUTE — Scanning (parallel):**
nuclei · nuclei-ai · afrog · dalfox · xsstrike · ffuf · feroxbuster · wfuzz · nikto · sqlmap · ghauri · wpscan · hydra · subzy · subjack · cors-engine · corsy · crlfuzz · ssrfmap · tplmap · jwt-tool · graphw00f · graphql-cop · swaggerspy · openredirex · nomore403 · 403fuzzer · ppmap

**API Security Tools (Top 5 Open Source):**
kiterunner · vulnapi · astra · apifuzzer · gotestwaf

**Phase ITERATE — Exploitation (serial):**
commix · race-the-web · smuggler · zap · osmedeus · reconftw · interactsh · notify · bountyplz

**Native Go (no subprocess):**
cors-engine — 7 vectors: origin reflection, null, subdomain spoof, HTTP downgrade, preflight bypass, wildcard, credentials

---

## Pipeline Optimizations — 34 Active

### Original 17 chains:

| Chain | Trigger | Effect |
|-------|---------|--------|
| subfinder → puredns → httpx | always | Wildcard DNS filter, -50% traffic |
| gf xss → kxss → dalfox | XSS params found | dalfox on 20% URLs only |
| httpx tech → nuclei tagged | tech detected | Relevant templates only |
| httpx 401/403 → nomore403 | 403 found | Exact URLs |
| nuclei SQLi → sqlmap-targeted | SQLi confirmed | Exact param |
| katana JS → trufflehog-js | JS files found | Secrets in live bundles |
| ffuf paths → nuclei-paths | 200/301 found | Misconfiguration scan |
| wafw00f WAF → nuclei-waf-bypass | WAF detected | Bypass headers auto |
| nuclei SSRF → ssrfmap-targeted | SSRF confirmed | Exact URL + param |
| crlfuzz CRLF → smuggler | CRLF found | Same host smuggling |
| waybackurls/gau → ffuf-custom | URLs discovered | Historical wordlist |
| dalfox/nuclei XSS → notify | XSS confirmed | Telegram instant |
| httpx version → nuclei-cve-{tech} | Version detected | CVE-specific templates |
| subzy takeover → notify | Takeover found | Telegram instant |
| gitleaks/trufflehog → notify | Secret found | Telegram instant |
| naabu ports → nuclei port-specific | Non-standard port | Port-targeted scan |
| nuclei Critical → bountyplz | Critical confirmed | Auto-submit H1/Bugcrowd |

### API Security chains (5 new):

| Chain | Trigger | Effect |
|-------|---------|--------|
| katana JS paths → kiterunner | API endpoints found | 20k Swagger route bruteforce |
| swaggerspy spec → astra + apifuzzer + kiterunner | OpenAPI spec found | Full API security trio |
| wafw00f WAF → gotestwaf + notify | WAF + API detected | Bypass test + alert |
| graphw00f confirmed → kiterunner + vulnapi + graphql-cop | GraphQL found | Full GraphQL audit |
| httpx tech (FastAPI/Django/Express/Spring) → kiterunner + vulnapi | Framework detected | OWASP API Top 10 auto |

### Additional chains (12):

| Chain | Trigger | Effect |
|-------|---------|--------|
| naabu port 8080/9090 → vulnapi | API port found | OWASP scan on port |
| naabu port 9200 → nuclei elastic | Elasticsearch found | Elastic templates |
| arjun 3+ params → vulnapi | Rich API endpoint | OWASP risk assessment |
| kiterunner routes → nuclei + dalfox + sqlmap | API routes found | Full exploitation chain |
| vulnapi High/Critical → notify | OWASP finding | Telegram instant |
| astra SQLi confirmed → sqlmap targeted | SQLi confirmed | Exact endpoint exploitation |
| hakrawler JS → linkfinder → nuclei | JS files found | Endpoint extraction + scan |
| gospider JS → secretfinder → notify | JS crawled | Secret cross-validation |
| dnsx CNAME → subzy → notify | CNAME found | Takeover check instant |
| feroxbuster /api* 200 → astra + nuclei | API path found | Injection test |
| metagoofil usernames → hydra | Users from metadata | SSH/FTP brute force |
| porch-pirate Postman → kiterunner + nuclei | Postman collection | Internal API routes |

### cariddi (all-in-one):

| Chain | Trigger | Effect |
|-------|---------|--------|
| cariddi secrets → notify + gitleaks + trufflehog | Secret in HTTP response | Cross-validate instantly |
| cariddi juicy files → nuclei-paths | .sql/.bak/.env found | Exposure scan |
| cariddi /api endpoint → kiterunner + vulnapi | API endpoint crawled | OWASP API scan |
| cariddi errors → tplmap + commix | Error page found | SSTI + OS injection |

---

## Quick Start

### Prerequisites

```bash
# Ubuntu 22.04 / 24.04 LTS — recommended
# Minimum: 4GB RAM, 20GB disk, 2 vCPU
# Production: Hetzner AX102 — 128GB RAM, 16 cores, ~€124/mo
# Go 1.22+, Node 20+, Python 3.11+, Redis 7+
```

### Install

```bash
git clone https://github.com/your-username/bbounty-pro.git
cd bbounty-pro

# Install all 78 tools (Ubuntu 22/24)
sudo bash scripts/install-ubuntu.sh

# Fix any failed tools (non-critical, run after install)
sudo bash scripts/fix-failed-tools.sh
```

### Configure

```bash
cp .env.example .env
chmod 600 .env
nano .env
```

**Required `.env` keys:**
```bash
JWT_SECRET=<openssl rand -hex 32>
ANTHROPIC_API_KEY=sk-ant-...
REDIS_PASSWORD=<strong password>
REDIS_URL=redis://:${REDIS_PASSWORD}@127.0.0.1:6379

# Recommended
STRIPE_SECRET_KEY=sk_live_...
RESEND_API_KEY=re_...
TELEGRAM_TOKEN=...
GEMINI_API_KEY=AIza...       # Fallback AI
BACKUP_ENCRYPTION_KEY=<openssl rand -hex 32>
```

### Harden

```bash
# Redis hardening (maxmemory, FLUSHALL off, requirepass, AOF)
sudo bash scripts/harden-redis.sh

# Platform hardening (UFW, Fail2Ban, SSH, auto-updates, log rotation, backup cron)
sudo bash scripts/secure-platform.sh

# NGINX CVE check (CVE-2026-42945 + 3 associated)
sudo bash scripts/check-nginx-cve.sh

# Pre-flight validation
sudo bash scripts/preflight-check.sh
```

### Launch

```bash
# Build orchestrator
cd apps/orchestrator && go build -o orchestrator ./cmd/server

# Start services (3 terminals)
redis-server --daemonize yes
./apps/orchestrator/orchestrator

cd apps/ai-proxy && uvicorn main:app --port 8001

cd apps/web && npm install && npm run build && npm start
```

### First Scan

```bash
curl -X POST http://localhost:8080/api/v1/scan/start \
  -H "Content-Type: application/json" \
  --cookie "bb_access=YOUR_JWT" \
  -d '{"target":"testphp.vulnweb.com","profile":"quick","platform":"hackerone"}'

# Or via Dashboard: https://your-domain.com → Login → New Scan
```

---

## Scan Profiles

| Profile | Tools | Duration | Use case |
|---------|-------|----------|----------|
| `quick` | 15 tools | 2–3 min | First look, CTF |
| `deep` | 57 tools | 6–9 min | Active programs |
| `stealth` | 20 tools | 15+ min | Rate-limit sensitive targets |
| `api` | 25 tools | 5–7 min | API-first targets (+ API Top 5) |
| `wordpress` | 30 tools | 8–12 min | WordPress sites |
| `reconftw-deep` | 78 tools | 45–90 min | Full passive + active recon |

---

## AI Integration

### Claude Code Reports (primary)
Every Critical/High finding generates:
- CVSS 3.1 score with full vector string
- Working PoC (curl/Python, minimal and safe)
- Business impact statement
- HackerOne-compatible title: `[Component] Vulnerability Type allows Action`
- Remediation with framework-specific guidance

### Gemini (fallback)
Activates automatically if Claude API is unavailable. Same output format.

### Cost estimate
```
50 users × 30 scans × 5 findings = 7.500 AI analyses/month
Claude Sonnet: ~$22.50/month total
Per user: ~$0.45/month AI cost vs $29-79 subscription
```

---

## Security Features

| Feature | Implementation |
|---------|---------------|
| Authentication | JWT httpOnly cookie + 2FA TOTP |
| CSRF | Double-submit cookie, all mutations |
| Scope enforcement | `SafeTarget()` — private IPs, cloud metadata, injection blocked |
| Scan limits | Per JWT userID, per plan — VPN-proof |
| Rate limiting | Login 5/min, Register 3/hour, API 60/min |
| Fail2Ban | SSH + API endpoint protection |
| Redis | requirepass, FLUSHALL off, maxmemory 25%, AOF everysec, CNAME rename |
| Backups | Daily 03:00, AES-256 encrypted, 30-day retention |
| SSL | nginx + Let's Encrypt, TLS 1.3, HSTS, CSP |
| Subprocess env | Allowlist — JWT/Stripe/Anthropic keys never reach tool processes |
| Dead scan janitor | Cancels stuck scans >2h every 15min |
| Panic recovery | Middleware — server never crashes on unhandled panic |

---

## Scan Limits (per plan)

| Plan | Price | Concurrent scans | Monthly scans |
|------|-------|-----------------|---------------|
| Solo Hunter | $29/mo | 1 | 30 |
| Professional | $79/mo | 3 | Unlimited |
| Team | $199/mo | 5 per seat | Unlimited |

Limits enforced via JWT userID in Redis. Bypassing with VPN, alt tabs, or incognito is not possible — the limit is tied to the authenticated account, not the IP.

---

## Continuous Monitoring (Asset DB)

```
Scan 1: 5 subdomains → snapshot saved (Redis, 90-day TTL)
Scan 2: 7 subdomains → diff detected → Telegram alert:
        "2 new subdomains: api2.target.com, dev2.target.com"
```

New subdomain, new port, escalated severity → instant alert.

---

## Tests

```bash
cd apps/orchestrator

go build ./...        # Zero errors
go vet ./...          # Zero warnings
go test -race ./...   # Zero race conditions — all packages
go test ./internal/tools/... -v  # 78-tool integration tests
```

**Current:** `go build ✅` `go vet ✅` `go test -race ✅` — 0 failures.

---

## Scripts Reference

| Script | Purpose |
|--------|---------|
| `install-ubuntu.sh` | Install all 78 tools on Ubuntu 22/24 |
| `fix-failed-tools.sh` | Fix non-critical tools that failed install |
| `harden-redis.sh` | Redis hardening (password, limits, disabled commands) |
| `secure-platform.sh` | Full platform hardening (UFW, SSH, Fail2Ban, auto-updates, backups) |
| `check-nginx-cve.sh` | Check + fix CVE-2026-42945 (NGINX Rift) |
| `preflight-check.sh` | Pre-launch validation (all services, tools, config) |
| `backup-encrypted.sh` | AES-256 encrypted backup (Redis + PostgreSQL) |

---

## Directory Structure

```
bbounty-pro/
├── apps/
│   ├── orchestrator/              # Go 1.26 — main API server
│   │   ├── cmd/server/main.go     # Entry point
│   │   └── internal/
│   │       ├── agent/             # Pipeline + 34 conditions chains
│   │       ├── auth/              # JWT, 2FA, CSRF, session management
│   │       ├── billing/           # Stripe + scan limits per plan
│   │       ├── cache/             # Redis client (hardened)
│   │       ├── cors/              # Native Go CORS engine (7 vectors)
│   │       ├── diff/              # Asset DB + snapshot diff engine
│   │       ├── email/             # Transactional email (Resend/SMTP)
│   │       ├── findings/          # Finding store + Redis/PG sync
│   │       ├── metrics/           # Prometheus-compatible metrics
│   │       ├── profile/           # Scan profiles (TOML)
│   │       ├── roe/               # Rules of Engagement gate
│   │       └── tools/             # 78-tool registry + executor
│   ├── agents/
│   │   └── specialist_agents/
│   │       ├── ultra_agent.py     # Python agent — 10 parallel modules
│   │       └── orchestrator_client.py
│   ├── ai-proxy/                  # FastAPI — Claude primary + Gemini fallback
│   └── web/                       # Next.js 15 — dashboard
├── infra/
│   ├── nginx/nginx.conf           # nginx — hardened, rate limiting, CSP, HSTS
│   ├── redis/redis.conf           # Redis — hardened config
│   ├── postgres/pg_hba.conf       # PostgreSQL — restricted connections
│   └── docker-compose.yml
├── scripts/                       # All install + hardening scripts
├── .env.example                   # 55+ env vars documented
└── README.md
```

---

## Legal

**Authorized testing only.** BBounty Pro enforces scope at every level. `SafeTarget()` blocks private IP ranges, cloud metadata endpoints, and any target outside declared scope. The ROE Gate validates scope before any tool executes.

Always obtain explicit written permission before scanning any system.

---

*Built with Go 1.26 · Python 3.11+ · Next.js 15 · Redis 7.4 · PostgreSQL 17*
