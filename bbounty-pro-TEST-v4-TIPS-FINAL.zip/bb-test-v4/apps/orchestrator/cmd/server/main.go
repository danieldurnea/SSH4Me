package main

import (
	"context"
	"encoding/json"
	"fmt"
	"net"
	"strings"
	"net/http"
	"os"
	"os/signal"
	"sync"
	"syscall"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/agent"
	"github.com/bbounty-pro/orchestrator/internal/ai"
	"github.com/bbounty-pro/orchestrator/internal/auditlog"
	"github.com/bbounty-pro/orchestrator/internal/auth"
	"github.com/bbounty-pro/orchestrator/internal/billing"
	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/bbounty-pro/orchestrator/internal/cors"
	"github.com/bbounty-pro/orchestrator/internal/email"
	chicors "github.com/go-chi/cors"
	"github.com/bbounty-pro/orchestrator/internal/diff"
	"github.com/bbounty-pro/orchestrator/internal/findings"
	"github.com/bbounty-pro/orchestrator/internal/health"
	"github.com/bbounty-pro/orchestrator/internal/metrics"
	"github.com/bbounty-pro/orchestrator/internal/notify"
	"github.com/bbounty-pro/orchestrator/internal/priority"
	"github.com/bbounty-pro/orchestrator/internal/profile"
	"github.com/bbounty-pro/orchestrator/internal/ratelimit"
	"github.com/bbounty-pro/orchestrator/internal/roe"
	"github.com/bbounty-pro/orchestrator/internal/skills"
	"github.com/bbounty-pro/orchestrator/internal/tools"
	"github.com/bbounty-pro/orchestrator/internal/vps"
	"github.com/bbounty-pro/orchestrator/internal/ws"

	"github.com/go-chi/chi/v5"
	"github.com/go-chi/chi/v5/middleware"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/rs/zerolog"
	"github.com/rs/zerolog/log"
	"github.com/spf13/viper"
)

var version = "3.3.0-zen"

// authRateLimiter returns a per-IP sliding window rate limiter middleware.
// register: 5/hour, login: 20/15min — prevents brute force and mass account creation.
func authRateLimiter(endpoint string, max int, window time.Duration) func(http.Handler) http.Handler {
	type entry struct {
		count   int
		resetAt time.Time
	}
	var (
		mu    sync.Mutex
		store = make(map[string]*entry)
	)
	return func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			ip := r.RemoteAddr
			if xff := r.Header.Get("X-Forwarded-For"); xff != "" {
				for i, c := range xff {
					if c == ',' { ip = xff[:i]; break }
					if i == len(xff)-1 { ip = xff }
				}
			}
			mu.Lock()
			e, ok := store[ip+endpoint]
			now := time.Now()
			if !ok || now.After(e.resetAt) {
				e = &entry{count: 0, resetAt: now.Add(window)}
				store[ip+endpoint] = e
			}
			e.count++
			count := e.count
			mu.Unlock()
			if count > max {
				w.Header().Set("Retry-After", fmt.Sprintf("%.0f", window.Seconds()))
				http.Error(w, fmt.Sprintf(
					`{"error":"too many %s attempts — retry after %s"}`, endpoint, window,
				), http.StatusTooManyRequests)
				return
			}
			next.ServeHTTP(w, r)
		})
	}
}


// devBypassMiddleware bypass auth complet în DEV_MODE=true.
// NICIODATĂ în producție.
func devBypassMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		ctx := auth.InjectDevClaims(r.Context())
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

func main() {
	if os.Getenv("ENV") != "production" {
		log.Logger = log.Output(zerolog.ConsoleWriter{Out: os.Stderr, TimeFormat: time.RFC3339})
	}

	if err := vps.EnforceMode(); err != nil {
		log.Fatal().Err(err).Msg("VPS enforcement failed — set ALLOW_LOCAL=true for dev")
	}

	viper.AutomaticEnv()
	viper.SetDefault("BIND_ADDR", "127.0.0.1")
	viper.SetDefault("PORT",           "8080")
	viper.SetDefault("REDIS_URL",      "redis://redis:6379")
	viper.SetDefault("MAX_CONCURRENT", 8)
	viper.SetDefault("FRONTEND_URL",   "")
	viper.SetDefault("SKILLS_ROOT",    "/opt/bbounty-pro/apps/skills")
	viper.SetDefault("DATABASE_URL",   "")
	viper.SetDefault("AI_PROXY_URL",   "http://127.0.0.1:8001")
	viper.SetDefault("PROFILES_DIR",   "") // empty = embedded built-ins only

	if viper.GetString("JWT_SECRET") == "" {
		log.Fatal().Msg("JWT_SECRET required — generate with: openssl rand -hex 32")
	}

	rootCtx, stop := signal.NotifyContext(context.Background(), syscall.SIGINT, syscall.SIGTERM)
	defer stop()

	// ── Core deps ─────────────────────────────────────────────────────────────
	redisClient   := cache.MustConnect(viper.GetString("REDIS_URL"))
	wsHub         := ws.NewHub(redisClient)
	registry      := tools.NewRegistry()
	roeGate       := roe.NewGate()
	findingsStore := findings.NewStore(redisClient)
	primaryAI     := ai.NewClient(viper.GetString("ANTHROPIC_API_KEY"))
	cachedAI      := ai.NewCachedClient(primaryAI, redisClient)
	rateLimReg    := ratelimit.NewRegistry(redisClient)
	scorer        := priority.NewScorer(primaryAI, redisClient)
	diffEngine    := diff.NewEngine(redisClient)
	notifier      := notify.New()

	// Auth manager — handles login, register, JWT, 2FA
	authMgr := auth.NewManager(redisClient, viper.GetString("JWT_SECRET"))

	// Optional Postgres — nil-safe everywhere
	var pgPool *pgxpool.Pool
	if dsn := viper.GetString("DATABASE_URL"); dsn != "" {
		cfg, err := pgxpool.ParseConfig(dsn)
		if err != nil {
			log.Warn().Err(err).Msg("postgres: invalid DATABASE_URL — Redis-only")
		} else {
			cfg.MaxConns = 10
			cfg.MinConns = 2
			cfg.MaxConnLifetime = time.Hour
			pool, err := pgxpool.NewWithConfig(rootCtx, cfg)
			if err != nil || pool.Ping(rootCtx) != nil {
				log.Warn().Msg("postgres: unavailable — Redis-only")
				if pool != nil { pool.Close() }
			} else {
				pgPool = pool
				log.Info().Msg("postgres: connected ✓")
				defer pgPool.Close()
			}
		}
	} else {
		log.Info().Msg("postgres: not configured — Redis-only mode")
	}

	healthChecker   := health.New(redisClient, pgPool)
	auditLogger     := auditlog.New(redisClient, pgPool)

	// ── Email service ─────────────────────────────────────────────────────────
	emailSvc   := email.New(email.ConfigFromEnv())
	resetStore := email.NewResetStore(redisClient)

	// Inject email into auth manager (welcome email on register)
	authMgr.SetEmailService(emailSvc)
	pipeline        := agent.NewPipeline(registry, wsHub, roeGate, findingsStore, redisClient)
	checkpoints     := agent.NewCheckpointStore(redisClient)

	// Profile loader — built-in profiles + optional user profiles from disk
	profileLoader := profile.NewLoader(viper.GetString("PROFILES_DIR"))
	if err := profileLoader.Load(); err != nil {
		log.Warn().Err(err).Msg("profiles: load failed — built-ins only")
	}

	pipeline.SetCheckpointStore(checkpoints)
	pipeline.SetRateLimiter(rateLimReg)
	pipeline.SetProfileLoader(profileLoader)
	pipeline.SetEmailService(emailSvc)
	pipeline.SetDiffEngine(diffEngine)

	if pgPool != nil {
		go findings.NewPostgresSync(findingsStore, pgPool).Run(rootCtx)
		log.Info().Msg("findings: Postgres sync started")
	}

	// Wire audit hook into auth manager
	authMgr.SetAuditLoginSuccess(func(ctx context.Context, _ *auth.Manager, u *auth.User) {
		auditLogger.Log(ctx, auditlog.Event{
			Type:      auditlog.EventLoginSuccess,
			Timestamp: time.Now(),
			UserID:    u.ID,
			Username:  u.Username,
			UserRole:  string(u.Role),
			Action:    "auth.login",
			Success:   true,
		})
	})

	// ── Cross-module hooks ────────────────────────────────────────────────────
	findingsStore.OnSave(func(f *findings.Finding) {
		auditLogger.Log(context.Background(), auditlog.Event{
			Type:       auditlog.EventFindingCreate,
			Timestamp:  time.Now(),
			ResourceID: f.ScanID,
			Action:     "finding.saved",
			Success:    true,
			Metadata:   map[string]any{"id": f.ID, "severity": string(f.Severity), "title": f.Title},
		})
		if f.Severity == findings.SeverityCritical || f.Severity == findings.SeverityHigh {
			sev := notify.SevWarning
			if f.Severity == findings.SeverityCritical {
				sev = notify.SevCritical
			}
			notifier.Send(context.Background(), notify.Message{
				Title:    "[" + string(f.Severity) + "] " + f.Title,
				Body:     f.URL,
				Severity: sev,
				Target:   f.URL,
				Fields:   map[string]any{"category": f.Category, "source": f.Source},
			})
			metrics.FindingsTotal.Inc(string(f.Severity))
		}
	})

	// ── Health probe: AI proxy ─────────────────────────────────────────────────
	healthChecker.AddProbe(health.Probe{
		Name: "ai-proxy", Critical: false,
		Check: func(ctx context.Context) error {
			if viper.GetString("ANTHROPIC_API_KEY") == "" {
				return nil
			}
			c, cancel := context.WithTimeout(ctx, 3*time.Second)
			defer cancel()
			req, _ := http.NewRequestWithContext(c, "GET", viper.GetString("AI_PROXY_URL")+"/health", nil)
			resp, err := http.DefaultClient.Do(req)
			if err != nil { return err }
			resp.Body.Close()
			return nil
		},
	})

	// ── Skills ────────────────────────────────────────────────────────────────
	skillRegistry := skills.NewRegistry(viper.GetString("SKILLS_ROOT"))
	if err := skillRegistry.LoadFromDisk(); err != nil {
		log.Warn().Err(err).Msg("skills: disk load failed — built-ins only")
	}
	pythonRunner := skills.NewPythonRunner()

	// ── Background workers ────────────────────────────────────────────────────
	go wsHub.Run()
	go auditLogger.Run(rootCtx)
	go func() {
		t := time.NewTicker(6 * time.Hour)
		defer t.Stop()
		for {
			select {
			case <-t.C: agent.CleanOldOutputs(72 * time.Hour)
			case <-rootCtx.Done(): return
			}
		}
	}()

	// ── Router ────────────────────────────────────────────────────────────────
	r := chi.NewRouter()
	r.Use(middleware.RequestID)
	r.Use(middleware.RealIP)
	r.Use(middleware.Recoverer)
	r.Use(middleware.Compress(5))
	// HARDENING: panic recovery — un panic nu mai omoară serverul
	r.Use(func(next http.Handler) http.Handler {
		return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
			defer func() {
				if rec := recover(); rec != nil {
					log.Error().
						Str("method", r.Method).
						Str("path", r.URL.Path).
						Interface("panic", rec).
						Msg("recovered from panic")
					http.Error(w, `{"error":"internal server error"}`, http.StatusInternalServerError)
				}
			}()
			next.ServeHTTP(w, r)
		})
	})
	r.Use(metrics.HTTPMiddleware)

	allowedOrigins := []string{"http://localhost:3000"}
	if u := viper.GetString("FRONTEND_URL"); u != "" {
		allowedOrigins = []string{u}
	}
	r.Use(chicors.Handler(chicors.Options{
		AllowedOrigins:   allowedOrigins,
		AllowedMethods:   []string{"GET", "POST", "PUT", "DELETE", "OPTIONS"},
		AllowedHeaders:   []string{"Accept", "Authorization", "Content-Type", "X-Request-ID"},
		AllowCredentials: true,
		MaxAge:           300,
	}))

	// ── Public routes ─────────────────────────────────────────────────────────
	r.Get("/healthz", func(w http.ResponseWriter, _ *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		// C4-FIX: public_ip, vps_mode, postgres removed — infrastructure enumeration.
		_ = json.NewEncoder(w).Encode(map[string]any{
			"status":  "ok",
			"version": version,
		})
	})
	r.Get("/livez",   healthChecker.HandleLive)
	r.Get("/readyz",  healthChecker.HandleReady)
	r.Get("/health",  healthChecker.HandleHealth)
	// C3-FIX: /metrics restricted to localhost only — prevents info leak.
	// Prometheus scraper must run on same host or use SSH tunnel.
	r.Get("/metrics", func(w http.ResponseWriter, r *http.Request) {
		// Allow only loopback and RFC1918 addresses
		host, _, _ := net.SplitHostPort(r.RemoteAddr)
		allowed := host == "127.0.0.1" || host == "::1" ||
			strings.HasPrefix(host, "10.") ||
			strings.HasPrefix(host, "172.") ||
			strings.HasPrefix(host, "192.168.")
		if !allowed {
			http.Error(w, `{"error":"forbidden"}`, http.StatusForbidden)
			return
		}
		metrics.HandleMetrics(w, r)
	})

	// ── Auth routes (public) ──────────────────────────────────────────────────
	r.Route("/auth", func(r chi.Router) {
		// Public — rate limited to prevent account creation abuse and brute force
		// register: max 5/hour per IP (prevents mass account creation)
		// login:    max 20/15min per IP (brute force protection — Redis two-tier
		//           per-account limit is handled inside HandleLogin)
		r.With(authRateLimiter("register", 5, time.Hour)).
			Post("/register", authMgr.HandleRegister)
		r.With(authRateLimiter("login", 20, 15*time.Minute)).
			Post("/login", authMgr.HandleLogin)
		r.Post("/refresh",      authMgr.HandleRefresh)
		r.Post("/2fa/validate", authMgr.HandleValidate2FA)

		// Forgot / reset password
		emailHandler := email.NewHandler(
			emailSvc, resetStore,
			authMgr.FindUserByEmail,
			authMgr.UpdatePassword,
		)
		r.Post("/forgot-password", emailHandler.HandleForgotPassword)
		r.Post("/reset-password",  emailHandler.HandleResetPassword)

		// Protected
		r.Group(func(r chi.Router) {
			r.Use(authMgr.Middleware)
			r.Get("/me",          authMgr.HandleMe)
			r.Post("/logout",     authMgr.HandleLogout)
			r.Post("/invite",     authMgr.HandleInvite)
			r.Get("/team",        authMgr.HandleTeam)
			r.Put("/team/{id}",   authMgr.HandleUpdateMember)

			// 2FA management
			r.Post("/2fa/setup",   authMgr.HandleSetup2FA)   // generate QR + secret
			r.Post("/2fa/verify",  authMgr.HandleVerify2FA)  // confirm code → enable 2FA
			r.Post("/2fa/disable", authMgr.HandleDisable2FA) // disable 2FA (requires valid code)
		})
	})

	// ── Billing service (single instance shared by webhook + API routes) ──────
	billingSvc := billing.New(
		redisClient,
		viper.GetString("STRIPE_SECRET_KEY"),
		viper.GetString("STRIPE_WEBHOOK_SECRET"),
		viper.GetString("APP_URL"),
	)
	// Inject Stripe price IDs from .env
	if p := billing.Plans["solo"]; viper.GetString("STRIPE_PRICE_SOLO") != "" {
		p.StripePriceID = viper.GetString("STRIPE_PRICE_SOLO"); billing.Plans["solo"] = p
	}
	if p := billing.Plans["professional"]; viper.GetString("STRIPE_PRICE_PROFESSIONAL") != "" {
		p.StripePriceID = viper.GetString("STRIPE_PRICE_PROFESSIONAL"); billing.Plans["professional"] = p
	}
	if p := billing.Plans["team"]; viper.GetString("STRIPE_PRICE_TEAM") != "" {
		p.StripePriceID = viper.GetString("STRIPE_PRICE_TEAM"); billing.Plans["team"] = p
	}
	// Send receipt email after successful Stripe payment
	billingSvc.SetPaymentCallback(func(ctx context.Context, userID, planName string, amountUSD int) {
		users, err := authMgr.ListTeamByID(ctx)
		if err != nil { return }
		for _, u := range users {
			if u.ID == userID {
				if err := emailSvc.SendReceipt(ctx, u.Email, u.Username, planName, amountUSD); err != nil {
					log.Warn().Err(err).Str("user", userID).Msg("[billing] receipt email failed")
				}
				return
			}
		}
	})

	// ── Stripe Webhook (public — Stripe calls this, no JWT) ──────────────────
	// Must be registered BEFORE the authenticated API block.
	// We verify the Stripe-Signature header instead of JWT.
	r.Post("/api/v1/billing/webhook", billingSvc.HandleWebhook)

	// ── Protected API ─────────────────────────────────────────────────────────
	r.Route("/api/v1", func(r chi.Router) {
		r.Use(authMgr.Middleware)
		// CSRF enforcement on all state-changing requests.
		// Double-submit cookie pattern: X-CSRF-Token header must match bb_csrf cookie.
		// GET/HEAD/OPTIONS are exempt. Legacy Bearer-only clients (no cookie) are exempt.
		r.Use(auth.CSRFMiddleware)
		hunterAdmin := authMgr.RequireRole(auth.RoleAdmin, auth.RoleHunter)

		// ── Billing (Stripe) — uses shared billingSvc from above ──────────────
		r.Get("/billing/plans",     billingSvc.HandlePlans)
		r.Get("/billing/status",    billingSvc.HandleStatus)
		r.Post("/billing/checkout", billingSvc.HandleCheckout)
		r.Post("/billing/portal",   billingSvc.HandlePortal)

		// Scan — wrapped with plan enforcement
		r.With(hunterAdmin, billingSvc.EnforcePlan).Post("/scan/start", pipeline.HandleStart)
		r.With(hunterAdmin).Post("/scan/stop",            pipeline.HandleStop)
		r.With(hunterAdmin).Post("/scan/pause",           pipeline.HandlePause)
		r.Get("/scan/status/{scanID}",                    pipeline.HandleStatus)
		r.Get("/scan/resumable",                          pipeline.HandleListResumable)
		r.With(hunterAdmin).Post("/scan/{scanID}/resume", pipeline.HandleResume)

		// Tools
		r.Get("/tools",               registry.HandleList)
		r.Get("/tools/{toolID}/info", registry.HandleInfo)
		r.With(hunterAdmin).Post("/tools/{toolID}/run", registry.HandleRunSingle)

		// Profiles
		r.Get("/profiles", profileLoader.HandleList)

		// Skills
		r.Get("/skills",           skillRegistry.HandleList)
		r.Get("/skills/{skillID}", skillRegistry.HandleGet)
		r.With(hunterAdmin).Post("/skills/{skillID}/execute", skillRegistry.HandleExecute(pythonRunner))

		// ROE
		r.Post("/roe/validate",    roeGate.HandleValidate)
		r.Post("/roe/check-scope", roeGate.HandleCheckScope)

		// CORS Engine (native Go — tests 7 vectors per URL)
		corsHandler := cors.NewHandler()
		r.Get("/cors/scan",  corsHandler.HandleScanSingle) // GET ?url=https://target.com
		r.Post("/cors/scan", corsHandler.HandleScan)       // POST {"urls":[...]}

		// Findings
		r.Get("/findings/{scanID}",        findingsStore.HandleList)
		r.Get("/findings/{scanID}/stream", findingsStore.HandleStream)
		r.Get("/findings/{scanID}/export", findingsStore.HandleExport)  // Markdown + JSON report
		r.With(hunterAdmin).Post("/findings",     findingsStore.HandleCreate)
		r.With(hunterAdmin).Put("/findings/{id}", findingsStore.HandleUpdate)
		r.With(authMgr.RequireRole(auth.RoleAdmin)).Delete("/findings/{id}", findingsStore.HandleDelete)
		r.Post("/findings/{id}/analyze", primaryAI.HandleAnalyzeFinding)

		// AI
		r.Post("/ai/chat",          primaryAI.HandleChat)
		r.Post("/ai/report-review", primaryAI.HandleReportReview)
		_ = cachedAI

		// Audit
		r.With(authMgr.RequireRole(auth.RoleAdmin)).
			Get("/audit", func(w http.ResponseWriter, r *http.Request) {
				if pgPool == nil {
					http.Error(w, `{"error":"audit requires Postgres"}`, http.StatusServiceUnavailable)
					return
				}
				events, err := auditLogger.Query(r.Context(), auditlog.QueryOptions{Limit: 100})
				if err != nil {
					http.Error(w, `{"error":"audit query failed"}`, http.StatusInternalServerError)
					return
				}
				w.Header().Set("Content-Type", "application/json")
				_ = json.NewEncoder(w).Encode(events)
			})

		// Dashboards
		r.Get("/stats/{scanID}",  pipeline.HandleStats)
		r.Get("/ratelimit/stats", rateLimReg.HandleStats)
		r.Get("/priority/{scanID}", func(w http.ResponseWriter, r *http.Request) {
			q, err := scorer.GetQueue(r.Context(), chi.URLParam(r, "scanID"))
			if err != nil {
				http.Error(w, `{"error":"queue not ready"}`, http.StatusNotFound)
				return
			}
			w.Header().Set("Content-Type", "application/json")
			_ = json.NewEncoder(w).Encode(q)
		})

		// Diff
		r.Get("/diff/latest",  diffEngine.HandleLatestDiff)
		r.Get("/diff/history", diffEngine.HandleScanHistory)
		r.Get("/diff/compare", func(w http.ResponseWriter, r *http.Request) {
			q := r.URL.Query()
			old, new_, target := q.Get("old"), q.Get("new"), q.Get("target")
			if old == "" || new_ == "" || target == "" {
				http.Error(w, `{"error":"old, new, target required"}`, http.StatusBadRequest)
				return
			}
			oldSnap, err1 := diffEngine.GetSnapshot(r.Context(), target, old)
			newSnap, err2 := diffEngine.GetSnapshot(r.Context(), target, new_)
			if err1 != nil || err2 != nil {
				http.Error(w, `{"error":"snapshot not found"}`, http.StatusNotFound)
				return
			}
			w.Header().Set("Content-Type", "application/json")
			_ = json.NewEncoder(w).Encode(diffEngine.Compare(r.Context(), oldSnap, newSnap))
		})
	})

	// ── WebSocket (JWT via ?token= query param) ───────────────────────────────
	r.Group(func(r chi.Router) {
		r.Use(authMgr.WSMiddleware)
		r.Get("/ws/terminal/{scanID}/{toolID}", wsHub.HandleTerminal)
		r.Get("/ws/stats/{scanID}",             wsHub.HandleStats)
		r.Get("/ws/pipeline/{scanID}",          wsHub.HandlePipeline)
	})

	addr := viper.GetString("BIND_ADDR") + ":" + viper.GetString("PORT")
	if os.Getenv("DEV_MODE") == "true" && !strings.HasPrefix(addr, "127.") {
		log.Warn().Msg("[DEV] BIND_ADDR forțat 127.0.0.1 — DEV_MODE force")
		addr = "127.0.0.1:" + viper.GetString("PORT")
	}
	srv := &http.Server{
		Addr:              addr,
		Handler:           r,
		ReadTimeout:       10 * time.Second,
		WriteTimeout:      0,
		IdleTimeout:       120 * time.Second,
		ReadHeaderTimeout: 5 * time.Second,
	}

	go func() {
		log.Info().
			Str("addr", srv.Addr).
			Str("version", version).
			Str("public_ip", vps.PublicIP()).
			Bool("postgres", pgPool != nil).
			Msg("BBounty Pro orchestrator started — 2FA enabled")
		if err := srv.ListenAndServe(); err != nil && err != http.ErrServerClosed {
			log.Fatal().Err(err).Msg("server error")
		}
	}()

	<-rootCtx.Done()
	log.Info().Msg("Shutting down...")
	shutdownCtx, cancel := context.WithTimeout(context.Background(), 30*time.Second)
	defer cancel()
	pipeline.DrainAll(shutdownCtx)
	if err := srv.Shutdown(shutdownCtx); err != nil {
		log.Error().Err(err).Msg("shutdown error")
	}
	log.Info().Msg("Stopped cleanly")
}
