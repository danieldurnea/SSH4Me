module github.com/bbounty-pro/orchestrator

go 1.26

require (
	github.com/boombuler/barcode v1.0.1-0.20190219062509-6c824513bacc
	github.com/go-chi/chi/v5 v5.2.0
	github.com/go-chi/cors v1.2.1
	github.com/golang-jwt/jwt/v5 v5.2.1
	github.com/google/uuid v1.6.0
	github.com/gorilla/websocket v1.5.3
	github.com/jackc/pgx/v5 v5.7.1
	github.com/pquerna/otp v1.5.0
	github.com/redis/go-redis/v9 v9.7.0
	github.com/rs/zerolog v1.33.0
	github.com/spf13/viper v1.19.0
	golang.org/x/crypto v0.31.0
	golang.org/x/sync v0.10.0
	golang.org/x/time v0.9.0
)

require github.com/alicebob/miniredis/v2 v2.33.0

require (
	github.com/alicebob/gopher-json v0.0.0-20200520072559-a9ecdc9d1d3a // indirect
	github.com/cespare/xxhash/v2 v2.2.0 // indirect
	github.com/dgryski/go-rendezvous v0.0.0-20200823014737-9f7001d12a5f // indirect
	github.com/fsnotify/fsnotify v1.7.0 // indirect
	github.com/hashicorp/hcl v1.0.0 // indirect
	github.com/jackc/pgpassfile v1.0.0 // indirect
	github.com/jackc/pgservicefile v0.0.0-20240606120523-5a60cdf6a761 // indirect
	github.com/jackc/puddle/v2 v2.2.2 // indirect
	github.com/magiconair/properties v1.8.7 // indirect
	github.com/mattn/go-colorable v0.1.13 // indirect
	github.com/mattn/go-isatty v0.0.19 // indirect
	github.com/mitchellh/mapstructure v1.5.0 // indirect
	github.com/pelletier/go-toml/v2 v2.2.2 // indirect
	github.com/sagikazarmark/slog-shim v0.1.0 // indirect
	github.com/spf13/afero v1.11.0 // indirect
	github.com/spf13/cast v1.6.0 // indirect
	github.com/spf13/pflag v1.0.5 // indirect
	github.com/subosito/gotenv v1.6.0 // indirect
	github.com/yuin/gopher-lua v1.1.1 // indirect
	golang.org/x/sys v0.28.0 // indirect
	golang.org/x/text v0.21.0 // indirect
	gopkg.in/ini.v1 v1.67.0 // indirect
	gopkg.in/yaml.v3 v3.0.1 // indirect
)

replace (
	golang.org/x/crypto => /tmp/golang-mirrors/crypto
	golang.org/x/exp => /tmp/golang-mirrors/exp
	golang.org/x/mod => /tmp/golang-mirrors/mod
	golang.org/x/net => /tmp/golang-mirrors/net
	golang.org/x/sync => /tmp/golang-mirrors/sync
	golang.org/x/sys => /tmp/golang-mirrors/sys
	golang.org/x/term => /tmp/golang-mirrors/term
	golang.org/x/text => /tmp/golang-mirrors/text
	golang.org/x/time => /tmp/golang-mirrors/time
	golang.org/x/tools => /tmp/golang-mirrors/tools
	gopkg.in/check.v1 => /tmp/golang-mirrors/check.v1
	gopkg.in/ini.v1 => /tmp/golang-mirrors/ini.v1
	gopkg.in/yaml.v3 => /tmp/golang-mirrors/yaml.v3
)
