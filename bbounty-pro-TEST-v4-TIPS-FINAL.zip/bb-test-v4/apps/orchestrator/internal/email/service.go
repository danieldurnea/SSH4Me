// Package email provides transactional email for BBounty Pro.
//
// Provider priority:
//  1. Resend (RESEND_API_KEY) — recommended, simple API, generous free tier
//  2. SMTP (SMTP_HOST/PORT/USER/PASS) — fallback for self-hosted mail
//  3. Stdout logger — development mode when no provider configured
//
// Templates:
//   - Welcome        → sent on successful registration
//   - Receipt        → sent after Stripe payment confirmed
//   - ForgotPassword → password reset link (6h expiry)
//   - ScanComplete   → optional scan summary (configurable)
package email

import (
	"bytes"
	"context"
	"crypto/tls"
	"encoding/json"
	"fmt"
	"html/template"
	"net/http"
	"net/smtp"
	"os"
	"strings"
	"time"

	"github.com/rs/zerolog/log"
)

// ── Config ────────────────────────────────────────────────────────────────────

type Config struct {
	// Resend (preferred)
	ResendAPIKey string

	// SMTP fallback
	SMTPHost string
	SMTPPort string
	SMTPUser string
	SMTPPass string
	SMTPTLS  bool

	// Sender
	FromName    string
	FromAddress string

	// App
	AppURL  string
	AppName string
}

func ConfigFromEnv() Config {
	return Config{
		ResendAPIKey: os.Getenv("RESEND_API_KEY"),
		SMTPHost:     os.Getenv("SMTP_HOST"),
		SMTPPort:     orDefault(os.Getenv("SMTP_PORT"), "587"),
		SMTPUser:     os.Getenv("SMTP_USER"),
		SMTPPass:     os.Getenv("SMTP_PASS"),
		SMTPTLS:      os.Getenv("SMTP_TLS") == "true",
		FromName:     orDefault(os.Getenv("EMAIL_FROM_NAME"), "BBounty Pro"),
		FromAddress:  orDefault(os.Getenv("EMAIL_FROM"), "noreply@bbounty.pro"),
		AppURL:       orDefault(os.Getenv("APP_URL"), "https://bbounty.pro"),
		AppName:      "BBounty Pro",
	}
}

// ── Service ───────────────────────────────────────────────────────────────────

type Service struct {
	cfg    Config
	client *http.Client
}

func New(cfg Config) *Service {
	return &Service{
		cfg:    cfg,
		client: &http.Client{Timeout: 15 * time.Second},
	}
}

// ── Email types ───────────────────────────────────────────────────────────────

type Email struct {
	To      string
	Subject string
	HTML    string
	Text    string
}

// ── Public API ────────────────────────────────────────────────────────────────

// SendWelcome sends a welcome email after successful registration.
func (s *Service) SendWelcome(ctx context.Context, to, username string) error {
	html, text := s.renderWelcome(username)
	return s.send(ctx, Email{
		To:      to,
		Subject: fmt.Sprintf("Welcome to %s, %s! 🔐", s.cfg.AppName, username),
		HTML:    html,
		Text:    text,
	})
}

// SendReceipt sends a payment receipt after Stripe confirms a subscription.
func (s *Service) SendReceipt(ctx context.Context, to, username, planName string, amountUSD int) error {
	html, text := s.renderReceipt(username, planName, amountUSD)
	return s.send(ctx, Email{
		To:      to,
		Subject: fmt.Sprintf("Payment confirmed — %s $%d/month", planName, amountUSD/100),
		HTML:    html,
		Text:    text,
	})
}

// SendForgotPassword sends a password reset link with 6h expiry token.
func (s *Service) SendForgotPassword(ctx context.Context, to, username, resetToken string) error {
	resetURL := fmt.Sprintf("%s/auth/reset-password?token=%s", s.cfg.AppURL, resetToken)
	html, text := s.renderForgotPassword(username, resetURL)
	return s.send(ctx, Email{
		To:      to,
		Subject: "Reset your BBounty Pro password",
		HTML:    html,
		Text:    text,
	})
}

// SendScanComplete sends an optional scan summary email.
func (s *Service) SendScanComplete(ctx context.Context, to, username, target string, critCount, highCount, totalCount int, scanID string) error {
	if critCount+highCount == 0 && totalCount < 3 {
		return nil // Don't spam on clean scans
	}
	dashURL := fmt.Sprintf("%s/dashboard/scans/%s", s.cfg.AppURL, scanID)
	html, text := s.renderScanComplete(username, target, critCount, highCount, totalCount, dashURL)
	return s.send(ctx, Email{
		To:      to,
		Subject: fmt.Sprintf("Scan complete: %d findings on %s", totalCount, target),
		HTML:    html,
		Text:    text,
	})
}

// ── Send dispatch ─────────────────────────────────────────────────────────────

func (s *Service) send(ctx context.Context, e Email) error {
	// Resend API (preferred)
	if s.cfg.ResendAPIKey != "" {
		if err := s.sendViaResend(ctx, e); err != nil {
			log.Warn().Err(err).Str("to", e.To).Msg("[email] Resend failed — trying SMTP")
		} else {
			return nil
		}
	}

	// SMTP fallback
	if s.cfg.SMTPHost != "" {
		if err := s.sendViaSMTP(e); err != nil {
			log.Error().Err(err).Str("to", e.To).Msg("[email] SMTP failed")
			return err
		}
		return nil
	}

	// Dev mode — log to stdout
	log.Info().
		Str("to", e.To).
		Str("subject", e.Subject).
		Msg("[email] DEV MODE — no provider configured, email not sent")
	log.Debug().Str("body", e.Text).Msg("[email] text body")
	return nil
}

// ── Resend API ────────────────────────────────────────────────────────────────

func (s *Service) sendViaResend(ctx context.Context, e Email) error {
	payload := map[string]any{
		"from":    fmt.Sprintf("%s <%s>", s.cfg.FromName, s.cfg.FromAddress),
		"to":      []string{e.To},
		"subject": e.Subject,
		"html":    e.HTML,
		"text":    e.Text,
	}
	body, err := json.Marshal(payload)
	if err != nil {
		return err
	}

	req, err := http.NewRequestWithContext(ctx,
		http.MethodPost, "https://api.resend.com/emails",
		bytes.NewReader(body),
	)
	if err != nil {
		return err
	}
	req.Header.Set("Authorization", "Bearer "+s.cfg.ResendAPIKey)
	req.Header.Set("Content-Type", "application/json")

	resp, err := s.client.Do(req)
	if err != nil {
		return err
	}
	defer resp.Body.Close()

	if resp.StatusCode >= 400 {
		var errBody map[string]any
		json.NewDecoder(resp.Body).Decode(&errBody)
		return fmt.Errorf("resend API error %d: %v", resp.StatusCode, errBody)
	}

	log.Info().Str("to", e.To).Str("subject", e.Subject).Msg("[email] sent via Resend")
	return nil
}

// ── SMTP ──────────────────────────────────────────────────────────────────────

func (s *Service) sendViaSMTP(e Email) error {
	addr := s.cfg.SMTPHost + ":" + s.cfg.SMTPPort

	msg := []byte(
		"MIME-Version: 1.0\r\n" +
			"Content-Type: text/html; charset=UTF-8\r\n" +
			"From: " + s.cfg.FromName + " <" + s.cfg.FromAddress + ">\r\n" +
			"To: " + e.To + "\r\n" +
			"Subject: " + e.Subject + "\r\n" +
			"\r\n" +
			e.HTML,
	)

	var auth smtp.Auth
	if s.cfg.SMTPUser != "" {
		auth = smtp.PlainAuth("", s.cfg.SMTPUser, s.cfg.SMTPPass, s.cfg.SMTPHost)
	}

	if s.cfg.SMTPTLS {
		tlsCfg := &tls.Config{ServerName: s.cfg.SMTPHost}
		conn, err := tls.Dial("tcp", addr, tlsCfg)
		if err != nil {
			return err
		}
		c, err := smtp.NewClient(conn, s.cfg.SMTPHost)
		if err != nil {
			return err
		}
		defer c.Quit()
		if auth != nil {
			if err := c.Auth(auth); err != nil {
				return err
			}
		}
		if err := c.Mail(s.cfg.FromAddress); err != nil { return err }
		if err := c.Rcpt(e.To); err != nil { return err }
		w, err := c.Data()
		if err != nil { return err }
		_, err = w.Write(msg)
		if err != nil { return err }
		return w.Close()
	}

	return smtp.SendMail(addr, auth, s.cfg.FromAddress, []string{e.To}, msg)
}

// ── HTML templates ────────────────────────────────────────────────────────────

const baseStyle = `
<style>
  body{margin:0;padding:0;background:#060a0c;font-family:'Courier New',monospace}
  .wrap{max-width:560px;margin:0 auto;padding:32px 20px}
  .header{border-bottom:1px solid #1a2a32;padding-bottom:20px;margin-bottom:28px}
  .badge{display:inline-block;background:#00e5cc;color:#060a0c;font-weight:700;font-size:13px;padding:4px 10px;border-radius:3px;letter-spacing:1px;margin-bottom:12px}
  .title{color:#c8d8e0;font-size:22px;font-weight:700;margin:0;letter-spacing:-0.5px}
  .body{color:#4a6a7a;font-size:14px;line-height:1.8}
  .body p{margin:0 0 16px}
  .body strong{color:#c8d8e0}
  .btn{display:inline-block;background:#00e5cc;color:#060a0c;font-weight:700;font-size:13px;padding:12px 28px;border-radius:4px;text-decoration:none;letter-spacing:1px;margin:8px 0}
  .box{background:#0e1a20;border:1px solid #1a2a32;border-radius:6px;padding:16px 20px;margin:20px 0}
  .box-row{display:flex;justify-content:space-between;padding:6px 0;border-bottom:1px solid #1a2a32;font-size:13px}
  .box-row:last-child{border-bottom:none}
  .box-key{color:#2a4a5a}
  .box-val{color:#c8d8e0;font-weight:700}
  .box-val.green{color:#54b35f}
  .box-val.red{color:#ff3a5c}
  .box-val.gold{color:#f0c060}
  .footer{margin-top:32px;padding-top:20px;border-top:1px solid #1a2a32;color:#1a3a4a;font-size:11px;line-height:1.6}
  .warn{background:#ff3a5c18;border:1px solid #ff3a5c44;border-radius:4px;padding:10px 14px;color:#ff9b9b;font-size:12px;margin:16px 0}
</style>`

func (s *Service) renderWelcome(username string) (html, text string) {
	tpl := template.Must(template.New("").Parse(`<!DOCTYPE html><html><head>` + baseStyle + `</head><body>
<div class="wrap">
  <div class="header">
    <div class="badge">BB</div>
    <h1 class="title">Welcome to BBounty Pro 🔐</h1>
  </div>
  <div class="body">
    <p>Hey <strong>{{.Username}}</strong>,</p>
    <p>Your account is ready. You now have access to the BBounty Pro platform — 72 security tools, parallel execution, Claude Code AI reports, and more.</p>
    <a href="{{.AppURL}}/dashboard" class="btn">Open Dashboard →</a>
    <div class="box">
      <div class="box-row"><span class="box-key">Username</span><span class="box-val">{{.Username}}</span></div>
      <div class="box-row"><span class="box-key">Platform</span><span class="box-val">BBounty Pro v3.3-zen</span></div>
      <div class="box-row"><span class="box-key">Tools</span><span class="box-val green">72 integrated</span></div>
    </div>
    <p>First scan recommended: <strong>testphp.vulnweb.com</strong> with profile <strong>quick</strong> to verify everything works on your VPS.</p>
    <p>Questions? Reply to this email.</p>
    <p>Happy hunting,<br><strong>BBounty Pro Team</strong></p>
  </div>
  <div class="footer">
    BBounty Pro · Authorized testing only · Your data stays on your VPS<br>
    <a href="{{.AppURL}}/docs" style="color:#2a4a5a">Documentation</a> &middot;
    <a href="{{.AppURL}}/auth/unsubscribe" style="color:#2a4a5a">Unsubscribe</a>
  </div>
</div>
</body></html>`))

	var buf bytes.Buffer
	tpl.Execute(&buf, map[string]string{
		"Username": username,
		"AppURL":   s.cfg.AppURL,
	})
	html = buf.String()
	text = fmt.Sprintf("Welcome to BBounty Pro, %s!\n\nYour account is ready.\nDashboard: %s/dashboard\n\nAuthorized testing only.", username, s.cfg.AppURL)
	return
}

func (s *Service) renderReceipt(username, planName string, amountUSD int) (html, text string) {
	tpl := template.Must(template.New("").Parse(`<!DOCTYPE html><html><head>` + baseStyle + `</head><body>
<div class="wrap">
  <div class="header">
    <div class="badge">BB</div>
    <h1 class="title">Payment confirmed ✓</h1>
  </div>
  <div class="body">
    <p>Hey <strong>{{.Username}}</strong>,</p>
    <p>Your subscription is active. You have full access to all <strong>{{.PlanName}}</strong> features.</p>
    <div class="box">
      <div class="box-row"><span class="box-key">Plan</span><span class="box-val">{{.PlanName}}</span></div>
      <div class="box-row"><span class="box-key">Amount</span><span class="box-val green">${{.Amount}}/month</span></div>
      <div class="box-row"><span class="box-key">Status</span><span class="box-val green">Active</span></div>
      <div class="box-row"><span class="box-key">Date</span><span class="box-val">{{.Date}}</span></div>
    </div>
    <a href="{{.AppURL}}/dashboard" class="btn">Start Hunting →</a>
    <p>To manage your subscription, update payment method, or cancel anytime, visit your <a href="{{.AppURL}}/billing" style="color:#00e5cc">billing portal</a>.</p>
    <p>Thank you for choosing BBounty Pro.</p>
  </div>
  <div class="footer">
    Payments processed securely by Stripe · Card data never touches our servers<br>
    <a href="{{.AppURL}}/billing" style="color:#2a4a5a">Manage Subscription</a> &middot;
    <a href="{{.AppURL}}/auth/unsubscribe" style="color:#2a4a5a">Unsubscribe</a>
  </div>
</div>
</body></html>`))

	var buf bytes.Buffer
	tpl.Execute(&buf, map[string]string{
		"Username": username,
		"PlanName": planName,
		"Amount":   fmt.Sprintf("%d", amountUSD/100),
		"Date":     time.Now().Format("2 January 2006"),
		"AppURL":   s.cfg.AppURL,
	})
	html = buf.String()
	text = fmt.Sprintf("Payment confirmed!\nPlan: %s — $%d/month\nDashboard: %s/dashboard", planName, amountUSD/100, s.cfg.AppURL)
	return
}

func (s *Service) renderForgotPassword(username, resetURL string) (html, text string) {
	tpl := template.Must(template.New("").Parse(`<!DOCTYPE html><html><head>` + baseStyle + `</head><body>
<div class="wrap">
  <div class="header">
    <div class="badge">BB</div>
    <h1 class="title">Reset your password</h1>
  </div>
  <div class="body">
    <p>Hey <strong>{{.Username}}</strong>,</p>
    <p>You requested a password reset. Click the button below to set a new password. This link expires in <strong>6 hours</strong>.</p>
    <a href="{{.ResetURL}}" class="btn">Reset Password →</a>
    <div class="warn">
      ⚠️ If you didn't request this, ignore this email. Your password remains unchanged.
    </div>
    <p>For security, this link can only be used once and expires automatically.</p>
  </div>
  <div class="footer">
    BBounty Pro security notification · Authorized testing only<br>
    If the button doesn't work, copy this link: {{.ResetURL}}
  </div>
</div>
</body></html>`))

	var buf bytes.Buffer
	tpl.Execute(&buf, map[string]string{
		"Username": username,
		"ResetURL": resetURL,
	})
	html = buf.String()
	text = fmt.Sprintf("Reset your BBounty Pro password:\n%s\n\nThis link expires in 6 hours. If you didn't request this, ignore this email.", resetURL)
	return
}

func (s *Service) renderScanComplete(username, target string, critCount, highCount, totalCount int, dashURL string) (html, text string) {
	critColor := "box-val"
	if critCount > 0 { critColor = "box-val red" }
	highColor := "box-val"
	if highCount > 0 { highColor = "box-val gold" }

	tpl := template.Must(template.New("").Parse(`<!DOCTYPE html><html><head>` + baseStyle + `</head><body>
<div class="wrap">
  <div class="header">
    <div class="badge">BB</div>
    <h1 class="title">Scan complete 🎯</h1>
  </div>
  <div class="body">
    <p>Hey <strong>{{.Username}}</strong>,</p>
    <p>Your scan on <strong>{{.Target}}</strong> has finished.</p>
    <div class="box">
      <div class="box-row"><span class="box-key">Target</span><span class="box-val">{{.Target}}</span></div>
      <div class="box-row"><span class="box-key">Critical</span><span class="{{.CritColor}}">{{.CritCount}}</span></div>
      <div class="box-row"><span class="box-key">High</span><span class="{{.HighColor}}">{{.HighCount}}</span></div>
      <div class="box-row"><span class="box-key">Total</span><span class="box-val">{{.TotalCount}} findings</span></div>
    </div>
    <a href="{{.DashURL}}" class="btn">View Findings →</a>
    <p>Review findings, validate PoCs, and submit when ready. Always verify within authorized scope.</p>
  </div>
  <div class="footer">
    BBounty Pro · Authorized testing only · ROE enforcement active<br>
    <a href="{{.DashURL}}" style="color:#2a4a5a">View Dashboard</a> &middot;
    <a href="{{.AppURL}}/auth/unsubscribe" style="color:#2a4a5a">Unsubscribe</a>
  </div>
</div>
</body></html>`))

	var buf bytes.Buffer
	tpl.Execute(&buf, map[string]string{
		"Username":   username,
		"Target":     target,
		"CritCount":  fmt.Sprintf("%d", critCount),
		"HighCount":  fmt.Sprintf("%d", highCount),
		"TotalCount": fmt.Sprintf("%d", totalCount),
		"CritColor":  critColor,
		"HighColor":  highColor,
		"DashURL":    dashURL,
		"AppURL":     s.cfg.AppURL,
	})
	html = buf.String()
	text = fmt.Sprintf(
		"Scan complete on %s\nCritical: %d | High: %d | Total: %d\nView: %s",
		target, critCount, highCount, totalCount, dashURL,
	)
	return
}

// ── Helpers ───────────────────────────────────────────────────────────────────

func orDefault(val, def string) string {
	if strings.TrimSpace(val) == "" {
		return def
	}
	return val
}
