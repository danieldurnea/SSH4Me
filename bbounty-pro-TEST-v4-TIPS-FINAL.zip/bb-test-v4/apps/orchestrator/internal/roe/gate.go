package roe

import (
	"encoding/json"
	"fmt"
	"net"
	"net/http"
	"net/url"
	"strings"
)

// Platform represents a bug bounty platform.
type Platform string

const (
	PlatformHackerOne Platform = "hackerone"
	PlatformBugcrowd  Platform = "bugcrowd"
	PlatformIntigriti Platform = "intigriti"
	PlatformPrivate   Platform = "private"
)

// ROE defines the Rules of Engagement for a scan.
type ROE struct {
	Target   string   `json:"target"`
	Program  string   `json:"program"`
	Tester   string   `json:"tester"`
	Scope    []string `json:"scope"`
	Excluded []string `json:"excluded"`
	Platform Platform `json:"platform"`
}

// ValidationResult holds a full ROE check result.
type ValidationResult struct {
	Valid    bool     `json:"valid"`
	InScope  bool     `json:"in_scope"`
	Reasons  []string `json:"reasons"`
	Warnings []string `json:"warnings"`
}

// Gate enforces ROE constraints across all tools.
type Gate struct {
	Abuse *AbuseDetector // optional — set via NewGateWithAbuse
}

func NewGate() *Gate { return &Gate{} }

// NewGateWithAbuse creates a Gate with abuse detection enabled.
func NewGateWithAbuse(abuse *AbuseDetector) *Gate {
	return &Gate{Abuse: abuse}
}

// Validate returns nil if target is permissible under scope/excluded, or an error.
// Blacklist is checked first — it cannot be overridden by scope.
func (g *Gate) Validate(target string, scope, excluded []string) error {
	if target == "" {
		return fmt.Errorf("target cannot be empty")
	}
	if len(scope) == 0 {
		return fmt.Errorf("scope must define at least one entry — refusing to scan without ROE boundaries")
	}
	host := extractHost(target)

	// ── Blacklist check — hard block, no override ──────────────────────────────
	if blocked, reason := IsBlacklisted(host); blocked {
		return fmt.Errorf("BLACKLISTED: %s — %s", host, reason)
	}
	for _, exc := range excluded {
		if matchesScope(host, exc) {
			return fmt.Errorf("target %q is explicitly excluded (%s)", host, exc)
		}
	}
	for _, s := range scope {
		if matchesScope(host, s) {
			return nil
		}
	}
	return fmt.Errorf("target %q not in scope %v", host, scope)
}

// CheckInScope is a boolean wrapper around Validate.
func (g *Gate) CheckInScope(target string, scope, excluded []string) bool {
	return g.Validate(target, scope, excluded) == nil
}

// HandleValidate is the HTTP handler for full ROE validation.
func (g *Gate) HandleValidate(w http.ResponseWriter, r *http.Request) {
	var roe ROE
	if err := json.NewDecoder(r.Body).Decode(&roe); err != nil {
		http.Error(w, `{"error":"invalid body"}`, http.StatusBadRequest)
		return
	}
	result := g.validateFull(r, roe)
	w.Header().Set("Content-Type", "application/json")
	if !result.Valid {
		w.WriteHeader(http.StatusForbidden)
	}
	json.NewEncoder(w).Encode(result)
}

// HandleCheckScope checks whether a URL is in scope.
func (g *Gate) HandleCheckScope(w http.ResponseWriter, r *http.Request) {
	var req struct {
		URL      string   `json:"url"`
		Scope    []string `json:"scope"`
		Excluded []string `json:"excluded"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, `{"error":"invalid body"}`, http.StatusBadRequest)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]bool{
		"in_scope": g.CheckInScope(req.URL, req.Scope, req.Excluded),
	})
}

func (g *Gate) validateFull(r *http.Request, roe ROE) ValidationResult {
	result := ValidationResult{Valid: true}

	if roe.Target == "" {
		result.Valid = false
		result.Reasons = append(result.Reasons, "target is required")
	}
	if roe.Program == "" {
		result.Warnings = append(result.Warnings, "program name not specified")
	}
	if len(roe.Scope) == 0 {
		result.Valid = false
		result.Reasons = append(result.Reasons, "scope must contain at least one entry")
	}
	for _, s := range roe.Scope {
		if s == "*" || s == "*.*" {
			result.Valid = false
			result.Reasons = append(result.Reasons, fmt.Sprintf("scope %q is dangerously broad", s))
		}
	}

	// ── Blacklist check — runs before scope, cannot be bypassed ───────────────
	if roe.Target != "" {
		host := extractHost(roe.Target)
		if blocked, reason := IsBlacklisted(host); blocked {
			result.Valid = false
			result.InScope = false
			result.Reasons = append(result.Reasons,
				fmt.Sprintf("🚫 BLACKLISTED: %s", reason),
			)
			// Fire abuse alert if detector is configured
			if g.Abuse != nil {
				userID, _ := r.Context().Value("userID").(string)
				username, _ := r.Context().Value("username").(string)
				ip := r.RemoteAddr
				if fwd := r.Header.Get("X-Forwarded-For"); fwd != "" {
					ip = fwd
				}
				go g.Abuse.RecordBlacklistViolation(r.Context(), AbuseEvent{
					UserID:    userID,
					Username:  username,
					IPAddress: ip,
					Target:    roe.Target,
					Reason:    reason,
				})
			}
			return result // stop here — no further checks needed
		}
	}

	if roe.Target != "" && len(roe.Scope) > 0 {
		if err := g.Validate(roe.Target, roe.Scope, roe.Excluded); err != nil {
			result.Valid = false
			result.InScope = false
			result.Reasons = append(result.Reasons, err.Error())
		} else {
			result.InScope = true
		}
	}

	if isPrivateIP(roe.Target) {
		result.Warnings = append(result.Warnings, "target is a private IP — ensure this is authorised")
	}

	return result
}

// matchesScope checks if host matches a scope entry.
// Supports: exact match, *.domain.com wildcards, CIDR ranges.
func matchesScope(host, pattern string) bool {
	host = strings.ToLower(strings.TrimSpace(host))
	pattern = strings.ToLower(strings.TrimSpace(pattern))

	// Strip protocol from pattern if present
	if u, err := url.Parse(pattern); err == nil && u.Host != "" {
		pattern = u.Hostname() // strips port automatically
	}

	// Exact match
	if host == pattern {
		return true
	}

	// Wildcard: *.example.com matches sub.example.com AND example.com
	if strings.HasPrefix(pattern, "*.") {
		base := pattern[2:]
		return host == base || strings.HasSuffix(host, "."+base)
	}

	// CIDR range (IP targets)
	if _, ipNet, err := net.ParseCIDR(pattern); err == nil {
		if ip := net.ParseIP(host); ip != nil {
			return ipNet.Contains(ip)
		}
	}

	return false
}

// extractHost extracts the hostname from a URL or raw host:port string.
// FIXED: properly strips port using url.Hostname() instead of manual split.
func extractHost(target string) string {
	if strings.Contains(target, "://") {
		if u, err := url.Parse(target); err == nil && u.Hostname() != "" {
			return strings.ToLower(u.Hostname())
		}
	}
	// Raw host — may have :port
	host, _, err := net.SplitHostPort(target)
	if err != nil {
		return strings.ToLower(strings.TrimSpace(target))
	}
	return strings.ToLower(host)
}

func isPrivateIP(target string) bool {
	ip := net.ParseIP(extractHost(target))
	if ip == nil {
		return false
	}
	for _, cidr := range []string{"10.0.0.0/8", "172.16.0.0/12", "192.168.0.0/16", "127.0.0.0/8", "::1/128"} {
		_, block, _ := net.ParseCIDR(cidr)
		if block.Contains(ip) {
			return true
		}
	}
	return false
}
