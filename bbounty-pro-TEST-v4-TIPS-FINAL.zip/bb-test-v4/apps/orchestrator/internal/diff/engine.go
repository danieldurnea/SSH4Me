package diff

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"sort"
	"strings"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/bbounty-pro/orchestrator/internal/findings"
	"github.com/redis/go-redis/v9"
	"github.com/rs/zerolog/log"
)

// ── Snapshot types ────────────────────────────────────────────────────────────

// ScanSnapshot captures the full state of a scan's output for future comparison.
type ScanSnapshot struct {
	ScanID    string    `json:"scan_id"`
	Target    string    `json:"target"`
	CreatedAt time.Time `json:"created_at"`

	Subdomains []string            `json:"subdomains"`
	LiveHosts  []LiveHost          `json:"live_hosts"`
	Findings   []FindingRecord     `json:"findings"`
	Ports      map[string][]int    `json:"ports"`     // host → open ports
	Tech       map[string][]string `json:"tech"`      // host → detected tech
}

// LiveHost is a lightweight representation of a probed host.
type LiveHost struct {
	URL        string   `json:"url"`
	StatusCode int      `json:"status_code"`
	Tech       []string `json:"tech"`
	Title      string   `json:"title"`
}

// FindingRecord is a minimal finding representation for diffing.
// Hash is the dedup key: deterministic string of title+url+category.
type FindingRecord struct {
	ID       string `json:"id"`
	Title    string `json:"title"`
	URL      string `json:"url"`
	Severity string `json:"severity"`
	Category string `json:"category"`
	Hash     string `json:"hash"`
}

// FindingHash produces a stable dedup key for a finding.
func FindingHash(title, url, category string) string {
	return strings.ToLower(title + "|" + url + "|" + category)
}

// ── Diff types ────────────────────────────────────────────────────────────────

// ScanDiff holds the complete delta between two scan snapshots.
type ScanDiff struct {
	Target      string    `json:"target"`
	OldScanID   string    `json:"old_scan_id"`
	NewScanID   string    `json:"new_scan_id"`
	GeneratedAt time.Time `json:"generated_at"`
	Period      string    `json:"period"`
	Summary     string    `json:"summary"`
	AlertLevel  string    `json:"alert_level"` // none | info | warning | critical
	HasNewCrits bool      `json:"has_new_crits"`

	Subdomains SubdomainDiff `json:"subdomains"`
	Hosts      HostDiff      `json:"hosts"`
	Findings   FindingsDiff  `json:"findings"`
	Ports      PortDiff      `json:"ports"`
	Tech       TechDiff      `json:"tech"`
}

type SubdomainDiff struct {
	New         []string `json:"new"`
	Disappeared []string `json:"disappeared"`
	Stable      int      `json:"stable"`
	TotalOld    int      `json:"total_old"`
	TotalNew    int      `json:"total_new"`
}

type HostDiff struct {
	New      []LiveHost `json:"new"`
	WentDown []string   `json:"went_down"`
	Stable   int        `json:"stable"`
}

type FindingsDiff struct {
	New          []*findings.Finding `json:"new"`
	Fixed        []FindingRecord     `json:"fixed"`
	StillOpen    []FindingRecord     `json:"still_open"`
	SeverityUp   []SeverityChange    `json:"severity_up"`
	SeverityDown []SeverityChange    `json:"severity_down"`
}

type SeverityChange struct {
	Finding    FindingRecord `json:"finding"`
	OldSev     string        `json:"old_severity"`
	NewSev     string        `json:"new_severity"`
}

type PortDiff struct {
	NewlyOpen   map[string][]int `json:"newly_open"`
	NewlyClosed map[string][]int `json:"newly_closed"`
}

type TechDiff struct {
	NewlyDetected map[string][]string `json:"newly_detected"`
	Removed       map[string][]string `json:"removed"`
}

// ── Engine ────────────────────────────────────────────────────────────────────

// Engine stores and compares scan snapshots.
type Engine struct {
	cache *cache.Client
}

func NewEngine(c *cache.Client) *Engine { return &Engine{cache: c} }

// SaveSnapshotRaw is an adapter used by the pipeline via interface.
// Builds a ScanSnapshot from raw components and saves it.
func (e *Engine) SaveSnapshotRaw(
	ctx context.Context,
	target, scanID string,
	subsRaw, liveHostsRaw, portsRaw, techRaw interface{},
	findingIDsRaw interface{},
) error {
	snap := &ScanSnapshot{
		ScanID:    scanID,
		Target:    target,
		CreatedAt: time.Now(),
	}
	if s, ok := subsRaw.([]string); ok {
		snap.Subdomains = s
	}
	if ids, ok := findingIDsRaw.([]string); ok {
		for _, id := range ids {
			snap.Findings = append(snap.Findings, FindingRecord{ID: id, Hash: id})
		}
	}
	return e.SaveSnapshot(ctx, snap)
}

// CompareLatestRaw compares the two most recent scans for a target.
// Returns (shouldAlert, summary, error).
// Used by pipeline via interface to avoid circular import.
func (e *Engine) CompareLatestRaw(ctx context.Context, target string) (bool, string, error) {
	d, err := e.CompareLatest(ctx, target)
	if err != nil {
		return false, "", err
	}
	should, summary := ShouldNotify(d)
	return should, summary, nil
}

func snapshotKey(target, scanID string) string {
	return "diff:snap:" + sanitise(target) + ":" + scanID
}

func historyKey(target string) string {
	return "diff:hist:" + sanitise(target)
}

// SaveSnapshot persists a scan's state with a 90-day TTL.
func (e *Engine) SaveSnapshot(ctx context.Context, snap *ScanSnapshot) error {
	if snap.Target == "" || snap.ScanID == "" {
		return fmt.Errorf("snapshot requires target and scan_id")
	}
	if err := e.cache.SetJSON(ctx, snapshotKey(snap.Target, snap.ScanID), snap, 90*24*time.Hour); err != nil {
		return err
	}
	// FIXED: use redis.Z struct correctly with Score and Member
	_ = e.cache.Raw().ZAdd(ctx, historyKey(snap.Target), redis.Z{
		Score:  float64(snap.CreatedAt.Unix()),
		Member: snap.ScanID,
	})
	// Keep only last 30 snapshots
	e.cache.Raw().ZRemRangeByRank(ctx, historyKey(snap.Target), 0, -31)

	log.Info().
		Str("target", snap.Target).
		Str("scan", snap.ScanID).
		Int("subs", len(snap.Subdomains)).
		Int("findings", len(snap.Findings)).
		Msg("diff: snapshot saved")
	return nil
}

// GetSnapshot retrieves a snapshot by target+scanID.
func (e *Engine) GetSnapshot(ctx context.Context, target, scanID string) (*ScanSnapshot, error) {
	var snap ScanSnapshot
	if err := e.cache.GetJSON(ctx, snapshotKey(target, scanID), &snap); err != nil {
		return nil, fmt.Errorf("snapshot not found: %s/%s", target, scanID)
	}
	return &snap, nil
}

// LatestScans returns the n most recent scan IDs for a target (newest first).
func (e *Engine) LatestScans(ctx context.Context, target string, n int64) ([]string, error) {
	return e.cache.Raw().ZRevRange(ctx, historyKey(target), 0, n-1).Result()
}

// Compare computes the full diff between two snapshots.
func (e *Engine) Compare(_ context.Context, old, new *ScanSnapshot) *ScanDiff {
	d := &ScanDiff{
		Target:      new.Target,
		OldScanID:   old.ScanID,
		NewScanID:   new.ScanID,
		GeneratedAt: time.Now(),
		Period:      formatPeriod(new.CreatedAt.Sub(old.CreatedAt)),
	}

	d.Subdomains = compareSubdomains(old.Subdomains, new.Subdomains)
	d.Hosts = compareHosts(old.LiveHosts, new.LiveHosts)
	d.Findings = compareFindings(old.Findings, new.Findings)
	d.Ports = comparePorts(old.Ports, new.Ports)
	d.Tech = compareTech(old.Tech, new.Tech)

	// Determine alert level
	d.AlertLevel = "none"
	for _, f := range d.Findings.New {
		if f.Severity == findings.SeverityCritical {
			d.HasNewCrits = true
			d.AlertLevel = "critical"
			break
		}
		if f.Severity == findings.SeverityHigh && d.AlertLevel != "critical" {
			d.AlertLevel = "warning"
		}
	}
	if d.AlertLevel == "none" && (len(d.Subdomains.New) > 0 || len(d.Hosts.New) > 0) {
		d.AlertLevel = "info"
	}

	d.Summary = buildSummary(d)
	return d
}

// CompareLatest computes the diff between the last two scans for a target.
func (e *Engine) CompareLatest(ctx context.Context, target string) (*ScanDiff, error) {
	ids, err := e.LatestScans(ctx, target, 2)
	if err != nil || len(ids) < 2 {
		return nil, fmt.Errorf("need at least 2 scans to compare (have %d)", len(ids))
	}
	newSnap, err := e.GetSnapshot(ctx, target, ids[0])
	if err != nil {
		return nil, fmt.Errorf("load new snapshot: %w", err)
	}
	oldSnap, err := e.GetSnapshot(ctx, target, ids[1])
	if err != nil {
		return nil, fmt.Errorf("load old snapshot: %w", err)
	}
	return e.Compare(ctx, oldSnap, newSnap), nil
}

// ── HTTP Handlers ─────────────────────────────────────────────────────────────

func (e *Engine) HandleLatestDiff(w http.ResponseWriter, r *http.Request) {
	target := r.URL.Query().Get("target")
	if target == "" {
		http.Error(w, `{"error":"target required"}`, http.StatusBadRequest)
		return
	}
	d, err := e.CompareLatest(r.Context(), target)
	if err != nil {
		http.Error(w, fmt.Sprintf(`{"error":%q}`, err.Error()), http.StatusNotFound)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(d)
}

func (e *Engine) HandleScanHistory(w http.ResponseWriter, r *http.Request) {
	target := r.URL.Query().Get("target")
	ids, _ := e.LatestScans(r.Context(), target, 30)
	if ids == nil {
		ids = []string{}
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]any{"target": target, "scans": ids})
}

// ── ShouldNotify decides whether a diff warrants an external alert ────────────

func ShouldNotify(d *ScanDiff) (bool, string) {
	if d.HasNewCrits {
		return true, fmt.Sprintf("🚨 New CRITICAL finding on %s", d.Target)
	}
	highs := 0
	for _, f := range d.Findings.New {
		if f.Severity == findings.SeverityHigh {
			highs++
		}
	}
	if highs > 0 {
		return true, fmt.Sprintf("⚠️  %d new HIGH finding(s) on %s", highs, d.Target)
	}
	if len(d.Subdomains.New) >= 10 {
		return true, fmt.Sprintf("📡 %d new subdomains on %s", len(d.Subdomains.New), d.Target)
	}
	return false, ""
}

// ── Diff computation ──────────────────────────────────────────────────────────

func compareSubdomains(old, new []string) SubdomainDiff {
	oldSet := toStringSet(old)
	newSet := toStringSet(new)

	var added, removed []string
	for s := range newSet {
		if !oldSet[s] {
			added = append(added, s)
		}
	}
	for s := range oldSet {
		if !newSet[s] {
			removed = append(removed, s)
		}
	}
	sort.Strings(added)
	sort.Strings(removed)

	stable := 0
	for s := range newSet {
		if oldSet[s] {
			stable++
		}
	}
	return SubdomainDiff{New: added, Disappeared: removed, Stable: stable,
		TotalOld: len(old), TotalNew: len(new)}
}

func compareHosts(old, new []LiveHost) HostDiff {
	oldMap := make(map[string]LiveHost, len(old))
	for _, h := range old {
		oldMap[h.URL] = h
	}
	newMap := make(map[string]LiveHost, len(new))
	for _, h := range new {
		newMap[h.URL] = h
	}

	var added []LiveHost
	var wentDown []string
	for _, h := range new {
		if _, existed := oldMap[h.URL]; !existed {
			added = append(added, h)
		}
	}
	for url := range oldMap {
		if _, stillLive := newMap[url]; !stillLive {
			wentDown = append(wentDown, url)
		}
	}
	stable := len(newMap) - len(added)
	return HostDiff{New: added, WentDown: wentDown, Stable: stable}
}

func compareFindings(old, new []FindingRecord) FindingsDiff {
	oldByHash := make(map[string]FindingRecord, len(old))
	for _, f := range old {
		oldByHash[f.Hash] = f
	}
	newByHash := make(map[string]FindingRecord, len(new))
	for _, f := range new {
		newByHash[f.Hash] = f
	}

	var newFindings []*findings.Finding
	var fixed, stillOpen []FindingRecord
	var sevUp, sevDown []SeverityChange

	for hash, f := range newByHash {
		if oldF, existed := oldByHash[hash]; !existed {
			newFindings = append(newFindings, &findings.Finding{
				ID: f.ID, Title: f.Title, URL: f.URL,
				Severity: findings.Severity(f.Severity),
				Category: f.Category, Status: findings.StatusNew,
			})
		} else {
			stillOpen = append(stillOpen, f)
			if oldF.Severity != f.Severity {
				chg := SeverityChange{Finding: f, OldSev: oldF.Severity, NewSev: f.Severity}
				if severityRank(f.Severity) > severityRank(oldF.Severity) {
					sevUp = append(sevUp, chg)
				} else {
					sevDown = append(sevDown, chg)
				}
			}
		}
	}
	for hash, f := range oldByHash {
		if _, still := newByHash[hash]; !still {
			fixed = append(fixed, f)
		}
	}

	return FindingsDiff{
		New: newFindings, Fixed: fixed, StillOpen: stillOpen,
		SeverityUp: sevUp, SeverityDown: sevDown,
	}
}

func comparePorts(old, new map[string][]int) PortDiff {
	opened := make(map[string][]int)
	closed := make(map[string][]int)
	all := make(map[string]bool)
	for h := range old { all[h] = true }
	for h := range new { all[h] = true }

	for host := range all {
		op := toIntSet(old[host])
		np := toIntSet(new[host])
		for p := range np {
			if !op[p] { opened[host] = append(opened[host], p) }
		}
		for p := range op {
			if !np[p] { closed[host] = append(closed[host], p) }
		}
	}
	return PortDiff{NewlyOpen: opened, NewlyClosed: closed}
}

func compareTech(old, new map[string][]string) TechDiff {
	det := make(map[string][]string)
	rem := make(map[string][]string)
	all := make(map[string]bool)
	for h := range old { all[h] = true }
	for h := range new { all[h] = true }

	for host := range all {
		ot := toStringSet(old[host])
		nt := toStringSet(new[host])
		for t := range nt {
			if !ot[t] { det[host] = append(det[host], t) }
		}
		for t := range ot {
			if !nt[t] { rem[host] = append(rem[host], t) }
		}
	}
	return TechDiff{NewlyDetected: det, Removed: rem}
}

// ── Helpers ───────────────────────────────────────────────────────────────────

func buildSummary(d *ScanDiff) string {
	var parts []string
	if n := len(d.Subdomains.New); n > 0 { parts = append(parts, fmt.Sprintf("+%d subs", n)) }
	if n := len(d.Hosts.New); n > 0      { parts = append(parts, fmt.Sprintf("+%d hosts", n)) }
	if n := len(d.Findings.New); n > 0   { parts = append(parts, fmt.Sprintf("+%d findings", n)) }
	if n := len(d.Findings.Fixed); n > 0 { parts = append(parts, fmt.Sprintf("%d fixed", n)) }
	if len(parts) == 0 {
		return "No changes since last scan"
	}
	return strings.Join(parts, " · ") + " vs " + d.Period + " ago"
}

func formatPeriod(d time.Duration) string {
	switch {
	case d < 2*time.Hour:  return fmt.Sprintf("%.0fmin", d.Minutes())
	case d < 48*time.Hour: return fmt.Sprintf("%.0fh", d.Hours())
	default:               return fmt.Sprintf("%.0fd", d.Hours()/24)
	}
}

func severityRank(s string) int {
	return map[string]int{"critical": 4, "high": 3, "medium": 2, "low": 1, "info": 0}[s]
}

func toStringSet(ss []string) map[string]bool {
	m := make(map[string]bool, len(ss))
	for _, s := range ss { m[s] = true }
	return m
}

func toIntSet(is []int) map[int]bool {
	m := make(map[int]bool, len(is))
	for _, i := range is { m[i] = true }
	return m
}

func sanitise(s string) string {
	return strings.NewReplacer(":", "_", "/", "_", ".", "_").Replace(s)
}
