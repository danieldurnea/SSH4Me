// Package notify — Real webhook-based notifications.
//
// PARTIAL IMPLEMENTATION DISCLAIMER:
// - Slack/Discord/Telegram webhooks work
// - Rate limiting is per-target (max 1 notification / 5min / target / channel)
// - Email NOT implemented (would require SMTP config)
// - PagerDuty NOT implemented
// - No retry on transient failures (best-effort fire-and-forget)
// - No queue persistence — if process dies during send, notification lost

package notify

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"os"
	"sync"
	"time"

	"github.com/rs/zerolog/log"
)

// Severity for notifications.
type Severity string

const (
	SevInfo     Severity = "info"
	SevWarning  Severity = "warning"
	SevCritical Severity = "critical"
)

// Message is a notification to dispatch.
type Message struct {
	Title    string         `json:"title"`
	Body     string         `json:"body"`
	Severity Severity       `json:"severity"`
	Target   string         `json:"target,omitempty"`
	Link     string         `json:"link,omitempty"`
	Fields   map[string]any `json:"fields,omitempty"`
}

// Notifier dispatches messages to configured channels.
type Notifier struct {
	slackURL    string
	discordURL  string
	telegramTok string
	telegramCh  string

	httpClient *http.Client

	// per-target+channel rate limit
	mu          sync.Mutex
	lastSent    map[string]time.Time
	rateLimitTTL time.Duration
}

func New() *Notifier {
	return &Notifier{
		slackURL:     os.Getenv("SLACK_WEBHOOK"),
		discordURL:   os.Getenv("DISCORD_WEBHOOK"),
		telegramTok:  os.Getenv("TELEGRAM_BOT_TOKEN"),
		telegramCh:   os.Getenv("TELEGRAM_CHAT_ID"),
		httpClient:   &http.Client{Timeout: 10 * time.Second},
		lastSent:     make(map[string]time.Time),
		rateLimitTTL: 5 * time.Minute,
	}
}

// Send dispatches msg to all configured channels.
// Each channel is rate-limited independently per target.
//
// LIMITATION: rate limit is in-memory only. Multiple orchestrator replicas
// won't share state — each can send their own notification per target.
func (n *Notifier) Send(ctx context.Context, msg Message) {
	if n.slackURL != "" && !n.shouldThrottle("slack:"+msg.Target) {
		go n.sendSlack(ctx, msg)
	}
	if n.discordURL != "" && !n.shouldThrottle("discord:"+msg.Target) {
		go n.sendDiscord(ctx, msg)
	}
	if n.telegramTok != "" && n.telegramCh != "" && !n.shouldThrottle("telegram:"+msg.Target) {
		go n.sendTelegram(ctx, msg)
	}
}

func (n *Notifier) shouldThrottle(key string) bool {
	n.mu.Lock()
	defer n.mu.Unlock()
	last, ok := n.lastSent[key]
	if ok && time.Since(last) < n.rateLimitTTL {
		return true
	}
	n.lastSent[key] = time.Now()
	return false
}

// ── Slack ────────────────────────────────────────────────────────────────────

func (n *Notifier) sendSlack(ctx context.Context, msg Message) {
	color := "#36a64f"
	emoji := "ℹ️"
	switch msg.Severity {
	case SevWarning:
		color = "#ff9b3a"
		emoji = "⚠️"
	case SevCritical:
		color = "#ff3a5c"
		emoji = "🚨"
	}

	payload := map[string]any{
		"attachments": []map[string]any{{
			"color":  color,
			"title":  emoji + " " + msg.Title,
			"text":   msg.Body,
			"footer": "BBounty Pro",
			"ts":     time.Now().Unix(),
		}},
	}
	if msg.Link != "" {
		payload["attachments"].([]map[string]any)[0]["title_link"] = msg.Link
	}
	if len(msg.Fields) > 0 {
		fields := []map[string]any{}
		for k, v := range msg.Fields {
			fields = append(fields, map[string]any{
				"title": k, "value": fmt.Sprintf("%v", v), "short": true,
			})
		}
		payload["attachments"].([]map[string]any)[0]["fields"] = fields
	}

	n.post(ctx, n.slackURL, payload, "slack")
}

// ── Discord ──────────────────────────────────────────────────────────────────

func (n *Notifier) sendDiscord(ctx context.Context, msg Message) {
	color := 3066993 // green
	switch msg.Severity {
	case SevWarning:
		color = 16751930 // orange
	case SevCritical:
		color = 16730188 // red
	}

	embed := map[string]any{
		"title":       msg.Title,
		"description": msg.Body,
		"color":       color,
		"timestamp":   time.Now().Format(time.RFC3339),
		"footer":      map[string]string{"text": "BBounty Pro"},
	}
	if msg.Link != "" {
		embed["url"] = msg.Link
	}

	payload := map[string]any{"embeds": []any{embed}}
	n.post(ctx, n.discordURL, payload, "discord")
}

// ── Telegram ─────────────────────────────────────────────────────────────────

func (n *Notifier) sendTelegram(ctx context.Context, msg Message) {
	emoji := "ℹ️"
	switch msg.Severity {
	case SevWarning:
		emoji = "⚠️"
	case SevCritical:
		emoji = "🚨"
	}

	text := fmt.Sprintf("*%s %s*\n\n%s", emoji, msg.Title, msg.Body)
	if msg.Link != "" {
		text += "\n\n" + msg.Link
	}

	url := fmt.Sprintf("https://api.telegram.org/bot%s/sendMessage", n.telegramTok)
	payload := map[string]any{
		"chat_id":    n.telegramCh,
		"text":       text,
		"parse_mode": "Markdown",
	}
	n.post(ctx, url, payload, "telegram")
}

// ── HTTP wrapper ─────────────────────────────────────────────────────────────

func (n *Notifier) post(ctx context.Context, url string, payload any, channel string) {
	data, err := json.Marshal(payload)
	if err != nil {
		log.Warn().Err(err).Str("channel", channel).Msg("notify: marshal failed")
		return
	}

	req, err := http.NewRequestWithContext(ctx, "POST", url, bytes.NewReader(data))
	if err != nil {
		return
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := n.httpClient.Do(req)
	if err != nil {
		log.Warn().Err(err).Str("channel", channel).Msg("notify: send failed")
		return
	}
	defer resp.Body.Close()

	if resp.StatusCode >= 300 {
		log.Warn().Int("status", resp.StatusCode).Str("channel", channel).Msg("notify: non-2xx response")
	}
}
