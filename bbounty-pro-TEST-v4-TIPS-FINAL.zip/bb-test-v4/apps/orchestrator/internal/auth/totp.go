package auth

import (
	"bytes"
	"context"
	"encoding/base64"
	"image/png"
	"net/http"
	"time"

	"github.com/pquerna/otp"
	"github.com/pquerna/otp/totp"
)

const totpIssuer = "BBounty Pro"

// GenerateTOTPSecret creates a new TOTP secret for a user.
// Returns the secret key and base64-encoded QR code PNG.
func GenerateTOTPSecret(username string) (secret, qrBase64 string, err error) {
	key, err := totp.Generate(totp.GenerateOpts{
		Issuer:      totpIssuer,
		AccountName: username,
		Period:      30,
		Digits:      otp.DigitsSix,
		Algorithm:   otp.AlgorithmSHA1,
	})
	if err != nil {
		return "", "", err
	}

	// Encode QR code as base64 PNG
	img, err := key.Image(200, 200)
	if err != nil {
		return "", "", err
	}
	var buf bytes.Buffer
	if err := png.Encode(&buf, img); err != nil {
		return "", "", err
	}

	return key.Secret(), base64.StdEncoding.EncodeToString(buf.Bytes()), nil
}

// ValidateTOTP checks a 6-digit code against the user's secret.
func ValidateTOTP(secret, code string) bool {
	return totp.Validate(code, secret)
}

// ── 2FA API handlers ──────────────────────────────────────────────────────────

type setupTOTPResponse struct {
	Secret   string `json:"secret"`
	QRCode   string `json:"qr_code"`   // base64 PNG, render as <img src="data:image/png;base64,...">
	OTPAuthURL string `json:"otp_auth_url"`
}

// HandleSetup2FA generates a new TOTP secret and returns the QR code.
// Does NOT enable 2FA yet — user must verify first.
func (m *Manager) HandleSetup2FA(w http.ResponseWriter, r *http.Request) {
	user, err := m.userFromRequest(r)
	if err != nil {
		writeErr(w, http.StatusUnauthorized, "unauthorized")
		return
	}

	secret, qr, err := GenerateTOTPSecret(user.Username)
	if err != nil {
		writeErr(w, http.StatusInternalServerError, "failed to generate TOTP secret")
		return
	}

	// Store pending secret in Redis (TTL 10 min — must verify within this window)
	pendingKey := "totp:pending:" + user.ID
	if err := m.cache.SetJSON(r.Context(), pendingKey, map[string]string{
		"secret": secret,
	}, 10*time.Minute); err != nil {
		writeErr(w, http.StatusInternalServerError, "failed to store pending secret")
		return
	}

	// Build OTPAuth URL for display / manual entry
	otpURL := "otpauth://totp/" + totpIssuer + ":" + user.Username +
		"?secret=" + secret + "&issuer=" + totpIssuer + "&algorithm=SHA1&digits=6&period=30"

	writeJSON(w, http.StatusOK, setupTOTPResponse{
		Secret:     secret,
		QRCode:     qr,
		OTPAuthURL: otpURL,
	})
}

// HandleVerify2FA verifies the user's TOTP code and enables 2FA on the account.
func (m *Manager) HandleVerify2FA(w http.ResponseWriter, r *http.Request) {
	user, err := m.userFromRequest(r)
	if err != nil {
		writeErr(w, http.StatusUnauthorized, "unauthorized")
		return
	}

	var req struct {
		Code string `json:"code"`
	}
	if err := decodeJSON(r, &req); err != nil || len(req.Code) != 6 {
		writeErr(w, http.StatusBadRequest, "6-digit code required")
		return
	}

	// Load pending secret
	pendingKey := "totp:pending:" + user.ID
	var pending map[string]string
	if err := m.cache.GetJSON(r.Context(), pendingKey, &pending); err != nil {
		writeErr(w, http.StatusBadRequest, "no pending 2FA setup — call /auth/2fa/setup first")
		return
	}

	secret := pending["secret"]
	if !ValidateTOTP(secret, req.Code) {
		writeErr(w, http.StatusUnauthorized, "invalid TOTP code")
		return
	}

	// Enable 2FA on user account
	user.TOTPSecret  = secret
	user.TOTPEnabled = true
	if err := m.saveUser(r.Context(), user); err != nil {
		writeErr(w, http.StatusInternalServerError, "failed to save 2FA settings")
		return
	}

	// Delete pending secret
	m.cache.Raw().Del(r.Context(), pendingKey)

	writeJSON(w, http.StatusOK, map[string]string{"status": "2fa_enabled"})
}

// HandleDisable2FA disables 2FA after verifying the current code.
func (m *Manager) HandleDisable2FA(w http.ResponseWriter, r *http.Request) {
	user, err := m.userFromRequest(r)
	if err != nil {
		writeErr(w, http.StatusUnauthorized, "unauthorized")
		return
	}

	var req struct {
		Code string `json:"code"`
	}
	if err := decodeJSON(r, &req); err != nil {
		writeErr(w, http.StatusBadRequest, "code required")
		return
	}

	if !user.TOTPEnabled {
		writeErr(w, http.StatusBadRequest, "2FA is not enabled")
		return
	}
	if !ValidateTOTP(user.TOTPSecret, req.Code) {
		writeErr(w, http.StatusUnauthorized, "invalid TOTP code")
		return
	}

	user.TOTPSecret  = ""
	user.TOTPEnabled = false
	if err := m.saveUser(r.Context(), user); err != nil {
		writeErr(w, http.StatusInternalServerError, "failed to disable 2FA")
		return
	}

	writeJSON(w, http.StatusOK, map[string]string{"status": "2fa_disabled"})
}

// HandleValidate2FA is called after a successful password login when 2FA is enabled.
// It accepts the partial token + TOTP code and returns a full JWT pair.
func (m *Manager) HandleValidate2FA(w http.ResponseWriter, r *http.Request) {
	var req struct {
		PendingToken string `json:"pending_token"`
		Code         string `json:"code"`
	}
	if err := decodeJSON(r, &req); err != nil {
		writeErr(w, http.StatusBadRequest, "pending_token and code required")
		return
	}

	// Validate pending token from Redis
	pendingKey := "totp:login:" + req.PendingToken
	var data map[string]string
	if err := m.cache.GetJSON(r.Context(), pendingKey, &data); err != nil {
		writeErr(w, http.StatusUnauthorized, "invalid or expired pending token")
		return
	}

	user, err := m.findByID(r.Context(), data["user_id"])
	if err != nil || !user.Active {
		writeErr(w, http.StatusUnauthorized, "user not found or deactivated")
		return
	}

	if !user.TOTPEnabled {
		writeErr(w, http.StatusBadRequest, "2FA not configured for this user")
		return
	}

	if !ValidateTOTP(user.TOTPSecret, req.Code) {
		writeErr(w, http.StatusUnauthorized, "invalid TOTP code")
		return
	}

	// Delete one-time pending token
	m.cache.Raw().Del(r.Context(), pendingKey)

	// Update last login
	user.LastLoginAt = time.Now()
	_ = m.saveUser(r.Context(), user)

	// Audit
	auditLoginSuccess(r.Context(), m, user)

	pair, err := m.issueTokens(r.Context(), user)
	if err != nil {
		writeErr(w, http.StatusInternalServerError, "failed to issue tokens")
		return
	}
	writeJSON(w, http.StatusOK, pair)
}

// userFromRequest extracts the authenticated user from the JWT in the request.
func (m *Manager) userFromRequest(r *http.Request) (*User, error) {
	claims, err := m.parseBearer(r)
	if err != nil {
		return nil, err
	}
	return m.findByID(r.Context(), claims.UserID)
}

// auditLoginSuccess is a no-op stub — wired to auditlog in main.go via OnLoginSuccess hook.
var auditLoginSuccess = func(ctx context.Context, m *Manager, u *User) {}

// SetAuditLoginSuccess allows main.go to wire an audit callback without circular imports.
func (m *Manager) SetAuditLoginSuccess(fn func(ctx context.Context, mgr *Manager, u *User)) {
	auditLoginSuccess = fn
}
