// Package auth — HttpOnly cookie support
//
// PARTIAL IMPLEMENTATION DISCLAIMER:
// This adds httpOnly cookie support alongside the existing Bearer token.
// Frontend changes are NOT applied (would break existing useAuth.ts hook).
//
// Status:
//   - Backend: cookies issued + parsed correctly (this file)
//   - Frontend: STILL uses sessionStorage (TODO: rewrite useAuth.ts)
//   - CSRF: token generated but NOT enforced on mutation endpoints (TODO)
//
// To make this production-ready you must:
//   1. Update frontend to omit Authorization header, rely on cookies
//   2. Add `credentials: 'include'` to all fetch() calls
//   3. Wire CSRFMiddleware on all POST/PUT/DELETE routes
//   4. Switch CORS to AllowedOrigins (not wildcard) — already done

package auth

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"net/http"
	"os"
	"time"
)

const (
	cookieAccessName  = "bb_access"
	cookieRefreshName = "bb_refresh"
	cookieCSRFName    = "bb_csrf"
)

// SetAuthCookies writes httpOnly cookies for access + refresh tokens.
// Call after successful Register/Login/Refresh.
//
// Cookie attributes:
//   - HttpOnly: prevents JS access (XSS protection)
//   - Secure: only sent over HTTPS in production
//   - SameSite=Strict: CSRF baseline protection
//   - Path=/: scoped to entire app
func SetAuthCookies(w http.ResponseWriter, pair *TokenPair) {
	secure := os.Getenv("ENV") == "production"

	// Access token — short-lived
	http.SetCookie(w, &http.Cookie{
		Name:     cookieAccessName,
		Value:    pair.AccessToken,
		Path:     "/",
		HttpOnly: true,
		Secure:   secure,
		SameSite: http.SameSiteStrictMode,
		Expires:  pair.ExpiresAt,
		MaxAge:   int(time.Until(pair.ExpiresAt).Seconds()),
	})

	// Refresh token — longer-lived, restricted path
	http.SetCookie(w, &http.Cookie{
		Name:     cookieRefreshName,
		Value:    pair.RefreshToken,
		Path:     "/auth", // only sent to auth endpoints
		HttpOnly: true,
		Secure:   secure,
		SameSite: http.SameSiteStrictMode,
		MaxAge:   7 * 24 * 3600,
	})

	// CSRF token — readable by JS, used in custom header
	csrfBytes := make([]byte, 16)
	if _, err := rand.Read(csrfBytes); err != nil {
		// Cannot generate secure CSRF token — refuse to set cookies that
		// would leave the client unprotected against CSRF.
		http.Error(w, `{"error":"failed to generate CSRF token"}`, http.StatusInternalServerError)
		return
	}
	csrfToken := hex.EncodeToString(csrfBytes)
	http.SetCookie(w, &http.Cookie{
		Name:     cookieCSRFName,
		Value:    csrfToken,
		Path:     "/",
		HttpOnly: false, // JS reads this, sends as X-CSRF-Token header
		Secure:   secure,
		SameSite: http.SameSiteStrictMode,
		MaxAge:   int(time.Until(pair.ExpiresAt).Seconds()),
	})
}

// ClearAuthCookies invalidates all auth cookies (used on logout).
func ClearAuthCookies(w http.ResponseWriter) {
	for _, name := range []string{cookieAccessName, cookieRefreshName, cookieCSRFName} {
		http.SetCookie(w, &http.Cookie{
			Name:    name,
			Value:   "",
			Path:    "/",
			MaxAge:  -1,
			Expires: time.Unix(0, 0),
		})
	}
}

// MiddlewareWithCookies extends Middleware to accept tokens from cookies
// in addition to Authorization header. Cookies are checked second, so Bearer
// tokens still work if frontend hasn't migrated.
//
// LIMITATION: This wraps the existing Middleware logic. CSRF is NOT enforced
// here — see CSRFMiddleware. Use them together on mutation endpoints.
func (m *Manager) MiddlewareWithCookies(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		// Try Authorization header first (backwards compatible)
		token := ""
		if h := r.Header.Get("Authorization"); h != "" {
			if len(h) > 7 && h[:7] == "Bearer " {
				token = h[7:]
			}
		}
		// Fall back to cookie
		if token == "" {
			if c, err := r.Cookie(cookieAccessName); err == nil {
				token = c.Value
			}
		}
		if token == "" {
			writeErr(w, http.StatusUnauthorized, "missing authorization")
			return
		}
		claims, err := m.VerifyAccessToken(token)
		if err != nil {
			writeErr(w, http.StatusUnauthorized, "invalid or expired token")
			return
		}
		ctx := context.WithValue(r.Context(), claimsKey, claims)
		next.ServeHTTP(w, r.WithContext(ctx))
	})
}

// CSRFMiddleware verifies double-submit token pattern.
// Compares X-CSRF-Token header against bb_csrf cookie.
// Skip on idempotent methods (GET/HEAD/OPTIONS).
//
// LIMITATION: Doesn't bind CSRF to specific user session — token rotation
// happens on every cookie refresh, which is acceptable but not ideal.
func CSRFMiddleware(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.Method {
		case http.MethodGet, http.MethodHead, http.MethodOptions:
			next.ServeHTTP(w, r)
			return
		}

		cookie, err := r.Cookie(cookieCSRFName)
		if err != nil {
			// No cookie = legacy Bearer token client = skip CSRF
			next.ServeHTTP(w, r)
			return
		}

		header := r.Header.Get("X-CSRF-Token")
		if header == "" || header != cookie.Value {
			writeErr(w, http.StatusForbidden, "CSRF token mismatch")
			return
		}
		next.ServeHTTP(w, r)
	})
}

// HandleLogout clears cookies and invalidates refresh token.
func (m *Manager) HandleLogout(w http.ResponseWriter, r *http.Request) {
	if c, err := r.Cookie(cookieRefreshName); err == nil {
		m.cache.Raw().Del(r.Context(), m.refreshKey(c.Value))
	}
	ClearAuthCookies(w)
	writeJSON(w, http.StatusOK, map[string]string{"status": "logged out"})
}
