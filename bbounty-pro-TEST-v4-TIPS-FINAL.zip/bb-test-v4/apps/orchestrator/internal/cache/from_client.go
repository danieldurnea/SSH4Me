package cache

import "github.com/redis/go-redis/v9"

// NewFromClient wraps an existing redis.Client — used by unit tests with miniredis.
func NewFromClient(rdb *redis.Client) *Client {
	return &Client{rdb: rdb}
}
