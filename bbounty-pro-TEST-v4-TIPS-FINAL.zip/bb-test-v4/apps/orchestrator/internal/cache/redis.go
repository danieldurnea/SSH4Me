package cache

import (
	"context"
	"encoding/json"
	"fmt"
	"time"

	"github.com/redis/go-redis/v9"
	"github.com/rs/zerolog/log"
)

// Client wraps redis.Client with typed helpers.
type Client struct {
	rdb *redis.Client
}

// MustConnect creates a Redis client or fatals.
// Suportă URL cu parolă: redis://:password@host:port
// sau redis://host:port (fără parolă pentru dev local)
func MustConnect(redisURL string) *Client {
	opts, err := redis.ParseURL(redisURL)
	if err != nil {
		log.Fatal().Err(err).Str("url", redisURL).Msg("invalid Redis URL")
	}

	// Connection pool optimizat pentru scan workload:
	// - 20 conexiuni active (1 per tool paralel în Phase Execute)
	// - 5 idle min — ready pentru burst
	// - Retry automat pe disconnect temporar
	opts.PoolSize        = 20
	opts.MinIdleConns    = 5
	opts.MaxRetries      = 3
	opts.DialTimeout     = 5 * time.Second
	opts.ReadTimeout     = 5 * time.Second  // crescut față de 3s pentru scan outputs mari
	opts.WriteTimeout    = 5 * time.Second
	opts.PoolTimeout     = 10 * time.Second // timeout așteptare conexiune din pool
	opts.ConnMaxIdleTime = 5 * time.Minute  // eliberează conexiuni idle după 5 min

	rdb := redis.NewClient(opts)

	ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
	defer cancel()
	if err := rdb.Ping(ctx).Err(); err != nil {
		log.Fatal().Err(err).Msg("Redis ping failed — verifică REDIS_URL și REDIS_PASSWORD")
	}

	// Log fără parolă în URL
	safeAddr := opts.Addr
	log.Info().Str("addr", safeAddr).Msg("Redis connected ✓")

	// Verificare comenzi dezactivate — avertizare la startup
	go checkRedisHardening(rdb)

	return &Client{rdb: rdb}
}

// checkRedisHardening verifică că Redis e hardened — log warning dacă nu e.
// Rulează o singură dată la startup, non-blocking.
func checkRedisHardening(rdb *redis.Client) {
	ctx, cancel := context.WithTimeout(context.Background(), 3*time.Second)
	defer cancel()

	// Test requirepass — dacă FLUSHALL merge fără eroare, nu e hardened
	err := rdb.FlushAll(ctx).Err()
	if err == nil {
		log.Warn().Msg("[redis] ATENȚIE: FLUSHALL activ — rulează scripts/harden-redis.sh")
	} else {
		log.Info().Msg("[redis] FLUSHALL dezactivat — hardening OK ✓")
	}

	// Log maxmemory
	info, err := rdb.Info(ctx, "memory").Result()
	if err == nil {
		for _, line := range splitLines(info) {
			if len(line) > 0 && (contains(line, "maxmemory_human") || contains(line, "used_memory_human")) {
				log.Debug().Str("redis_mem", line).Msg("[redis] memory info")
			}
		}
	}
}

func splitLines(s string) []string {
	var lines []string
	start := 0
	for i := 0; i < len(s); i++ {
		if s[i] == '\n' {
			lines = append(lines, s[start:i])
			start = i + 1
		}
	}
	return lines
}

func contains(s, sub string) bool {
	return len(s) >= len(sub) && (s == sub || len(s) > 0 && containsCheck(s, sub))
}

func containsCheck(s, sub string) bool {
	for i := 0; i <= len(s)-len(sub); i++ {
		if s[i:i+len(sub)] == sub {
			return true
		}
	}
	return false
}

// Raw returns the underlying redis.Client for advanced operations.
func (c *Client) Raw() *redis.Client { return c.rdb }

// SetJSON marshals v to JSON and stores it with optional TTL (0 = no expiry).
func (c *Client) SetJSON(ctx context.Context, key string, v any, ttl time.Duration) error {
	data, err := json.Marshal(v)
	if err != nil {
		return fmt.Errorf("cache.SetJSON marshal: %w", err)
	}
	return c.rdb.Set(ctx, key, data, ttl).Err()
}

// GetJSON retrieves a key and unmarshals into dest.
// Returns redis.Nil if key does not exist.
func (c *Client) GetJSON(ctx context.Context, key string, dest any) error {
	data, err := c.rdb.Get(ctx, key).Bytes()
	if err != nil {
		return err // caller checks redis.Nil
	}
	return json.Unmarshal(data, dest)
}

// Publish sends a JSON-encoded payload to a Redis pub/sub channel.
func (c *Client) Publish(ctx context.Context, channel string, payload any) error {
	data, err := json.Marshal(payload)
	if err != nil {
		return err
	}
	return c.rdb.Publish(ctx, channel, data).Err()
}

// Del removes one or more keys.
func (c *Client) Del(ctx context.Context, keys ...string) error {
	return c.rdb.Del(ctx, keys...).Err()
}
