// Package config — Centralised constants (Item #26).
package config

import "time"

const (
	AccessTokenTTL  = 15 * time.Minute
	RefreshTokenTTL = 7 * 24 * time.Hour
	InviteCodeTTL   = 48 * time.Hour
	FindingsTTL     = 72 * time.Hour
	SnapshotTTL     = 90 * 24 * time.Hour
	CheckpointTTL   = 24 * time.Hour
	AIAnalysisTTL   = 7 * 24 * time.Hour

	HTTPReadTimeout       = 10 * time.Second
	HTTPReadHeaderTimeout = 5 * time.Second
	HTTPIdleTimeout       = 120 * time.Second
	HTTPShutdownTimeout   = 30 * time.Second

	DefaultToolTimeout = 5 * time.Minute
	MaxToolRetries     = 2
	MaxConcurrentTools = 8

	DefaultRateLimit  = 30
	RateLimitWindow   = time.Hour
	MaxRefreshPerHour = 10

	OldOutputCleanup = 6 * time.Hour
	OldOutputAge     = 72 * time.Hour

	NotifyMinInterval = 5 * time.Minute
)
