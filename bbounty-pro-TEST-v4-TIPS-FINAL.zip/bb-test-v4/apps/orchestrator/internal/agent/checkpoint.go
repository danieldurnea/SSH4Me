// Package agent — Scan checkpointing for resume after crash.
//
// PARTIAL IMPLEMENTATION DISCLAIMER:
// - Checkpoint save/load works (Redis-backed)
// - Pipeline integration is STUB only — pipeline.go would need refactor
//   to actually consult checkpoints on startup
// - No worker process separation (item #10 deferred — would need new binary)
//
// What works:
//   - SaveCheckpoint() persists scan state every phase transition
//   - LoadCheckpoint() retrieves state for resume
//   - ListResumable() lists scans that crashed mid-run
//
// What you'd need to add for real production resume:
//   - Pipeline.run() must call LoadCheckpoint at start
//   - Tool execution must record per-tool completion (not just per-phase)
//   - Idempotency on Redis findings (don't double-write on resume)

package agent

import (
	"context"
	"fmt"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/redis/go-redis/v9"
	"github.com/rs/zerolog/log"
)

// Checkpoint captures scan state for resume.
type Checkpoint struct {
	ScanID        string         `json:"scan_id"`
	Target        string         `json:"target"`
	Phase         Phase          `json:"phase"`
	CompletedTools []string      `json:"completed_tools"`
	Stats         CheckpointStats `json:"stats"`
	UpdatedAt     time.Time      `json:"updated_at"`
	OwnerID       string         `json:"owner_id"`
	Request       ScanRequest    `json:"request"`
}

type CheckpointStats struct {
	Subs  int64 `json:"subs"`
	Live  int64 `json:"live"`
	URLs  int64 `json:"urls"`
	Vulns int64 `json:"vulns"`
}

// CheckpointStore handles checkpoint persistence.
type CheckpointStore struct {
	cache *cache.Client
	ttl   time.Duration
}

func NewCheckpointStore(c *cache.Client) *CheckpointStore {
	return &CheckpointStore{
		cache: c,
		ttl:   24 * time.Hour, // resume window
	}
}

func checkpointKey(scanID string) string { return "scan:checkpoint:" + scanID }
const checkpointIndexKey = "scan:checkpoints:active"

// Save persists current scan state.
// Should be called after each phase transition + every N tool completions.
func (s *CheckpointStore) Save(ctx context.Context, c *Checkpoint) error {
	c.UpdatedAt = time.Now()
	if err := s.cache.SetJSON(ctx, checkpointKey(c.ScanID), c, s.ttl); err != nil {
		return fmt.Errorf("checkpoint save: %w", err)
	}
	// Add to sorted set indexed by update time
	s.cache.Raw().ZAdd(ctx, checkpointIndexKey, redis.Z{
		Score:  float64(c.UpdatedAt.UnixMilli()),
		Member: c.ScanID,
	})
	return nil
}

// Load retrieves checkpoint for a scan.
func (s *CheckpointStore) Load(ctx context.Context, scanID string) (*Checkpoint, error) {
	var c Checkpoint
	if err := s.cache.GetJSON(ctx, checkpointKey(scanID), &c); err != nil {
		return nil, err
	}
	return &c, nil
}

// Delete removes a checkpoint (call when scan completes successfully).
func (s *CheckpointStore) Delete(ctx context.Context, scanID string) error {
	pipe := s.cache.Raw().Pipeline()
	pipe.Del(ctx, checkpointKey(scanID))
	pipe.ZRem(ctx, checkpointIndexKey, scanID)
	_, err := pipe.Exec(ctx)
	return err
}

// ListResumable returns scan IDs that have checkpoints (likely crashed).
// Filter by minimum age — scans updated in the last 30s are probably still running.
func (s *CheckpointStore) ListResumable(ctx context.Context, minAge time.Duration) ([]string, error) {
	maxScore := float64(time.Now().Add(-minAge).UnixMilli())
	return s.cache.Raw().ZRangeByScore(ctx, checkpointIndexKey, &redis.ZRangeBy{
		Min: "0",
		Max: fmt.Sprintf("%f", maxScore),
	}).Result()
}

// Resume helper: takes an activeScan and a checkpoint, restores state.
// LIMITATION: The pipeline must skip already-completed phases manually.
// Currently this only restores stats — actual phase-skipping logic needs
// to be added to pipeline.go's run() method.
func RestoreScanState(scan *activeScan, c *Checkpoint) {
	scan.subs.Store(c.Stats.Subs)
	scan.live.Store(c.Stats.Live)
	scan.urls.Store(c.Stats.URLs)
	scan.vulns.Store(c.Stats.Vulns)
	scan.mu.Lock()
	scan.phase = c.Phase
	scan.mu.Unlock()
	log.Info().Str("scan", c.ScanID).Str("phase", string(c.Phase)).
		Msg("checkpoint: scan state restored")
}
