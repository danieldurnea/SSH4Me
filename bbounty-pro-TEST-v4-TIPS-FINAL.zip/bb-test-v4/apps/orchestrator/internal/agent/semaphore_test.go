package agent_test

import (
	"context"
	"testing"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/agent"
)

func TestSemaphore_AcquireRelease(t *testing.T) {
	sem := agent.NewSemaphore(3)

	// Acquire all slots
	for i := 0; i < 3; i++ {
		if err := sem.Acquire(context.Background()); err != nil {
			t.Fatalf("Acquire %d failed: %v", i, err)
		}
	}

	// TryAcquire should fail when full
	if sem.TryAcquire() {
		t.Error("TryAcquire should fail when semaphore is full")
	}

	// Available should be 0
	if got := sem.Available(); got != 0 {
		t.Errorf("Available() = %d, want 0", got)
	}

	// Release one, then TryAcquire should work
	sem.Release()
	if !sem.TryAcquire() {
		t.Error("TryAcquire should succeed after Release")
	}
	sem.Release()
}

func TestSemaphore_ContextCancellation(t *testing.T) {
	sem := agent.NewSemaphore(1)

	// Fill the semaphore
	_ = sem.Acquire(context.Background())

	// Try to acquire with cancelled context
	ctx, cancel := context.WithTimeout(context.Background(), 50*time.Millisecond)
	defer cancel()

	err := sem.Acquire(ctx)
	if err == nil {
		t.Error("expected context cancellation error")
	}
}

func TestSemaphore_Concurrency(t *testing.T) {
	const (
		maxConcurrent = 4
		totalWorkers  = 20
	)

	sem := agent.NewSemaphore(maxConcurrent)
	ctx := context.Background()

	// Track max concurrent goroutines
	var (
		current int
		maxSeen int
		mu      = make(chan struct{}, 1)
	)
	mu <- struct{}{}

	done := make(chan struct{}, totalWorkers)

	for i := 0; i < totalWorkers; i++ {
		go func() {
			defer func() { done <- struct{}{} }()

			if err := sem.Acquire(ctx); err != nil {
				return
			}
			defer sem.Release()

			<-mu
			current++
			if current > maxSeen {
				maxSeen = current
			}
			mu <- struct{}{}

			time.Sleep(10 * time.Millisecond)

			<-mu
			current--
			mu <- struct{}{}
		}()
	}

	for i := 0; i < totalWorkers; i++ {
		<-done
	}

	if maxSeen > maxConcurrent {
		t.Errorf("max concurrent goroutines = %d, want <= %d", maxSeen, maxConcurrent)
	}
}
