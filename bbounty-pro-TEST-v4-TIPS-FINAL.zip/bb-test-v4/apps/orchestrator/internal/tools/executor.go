package tools

import (
	"fmt"
	"os"
	"path/filepath"
	"regexp"
	"strings"
)

// ── Target sanitisation ───────────────────────────────────────────────────────
//
// BuildCommand interpolates target/scope strings into bash command lines.
// Even though the ROE gate validates targets at scan-start, we re-validate
// here as defence-in-depth: shell escapes belong nowhere near user input.
//
// Allowed shapes:
//   - hostnames:   "api.example.com", "host-1.example.co.uk"
//   - ipv4:        "192.0.2.10"
//   - URLs:        "https://api.example.com/path"
//   - host:port:   "api.example.com:8443"
//
// Anything containing shell metacharacters ($ ` ; & | < > ( ) { } [ ] ! \ * ? newline)
// or quotes is rejected.

var (
	// hostnameRe accepts dot-separated labels of [a-z0-9-], optional :port suffix.
	hostnameRe = regexp.MustCompile(`^[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*(?::[0-9]{1,5})?$`)
	// urlRe accepts http(s)://hostname[:port][/path] with restricted path chars.
	urlRe = regexp.MustCompile(`^https?://[a-zA-Z0-9.-]+(?::[0-9]{1,5})?(?:/[a-zA-Z0-9._~:/?#\[\]@!$&'()*+,;=%-]*)?$`)
)

// SafeTarget returns the input unchanged if it matches a permitted shape,
// or the empty string if it contains anything that could be shell-interpreted
// or targets private/internal infrastructure.
// The empty-string sentinel forces BuildCommand to skip the tool rather than
// emit a dangerous command line.
func SafeTarget(target string) string {
	target = strings.TrimSpace(target)
	if target == "" || len(target) > 512 {
		return ""
	}
	if strings.ContainsAny(target, "`$;&|<>(){}[]!\\\"' \t\r\n*?") {
		return ""
	}

	// Block private IPs, localhost, cloud metadata endpoints.
	// These should NEVER be scanned via the public bug bounty pipeline.
	blocked := []string{
		"localhost", "127.", "::1",
		"10.", "172.16.", "172.17.", "172.18.", "172.19.",
		"172.20.", "172.21.", "172.22.", "172.23.", "172.24.",
		"172.25.", "172.26.", "172.27.", "172.28.", "172.29.",
		"172.30.", "172.31.",
		"192.168.",
		"169.254.",            // AWS/GCP metadata
		"metadata.google",    // GCP metadata
		"metadata.azure",     // Azure metadata
		"169.254.169.254",    // Cloud metadata universal
		"fd00:", "fc00:",     // IPv6 private
	}
	targetLower := strings.ToLower(target)
	for _, b := range blocked {
		if strings.HasPrefix(targetLower, strings.ToLower(b)) ||
			targetLower == strings.ToLower(strings.TrimSuffix(b, ".")) {
			return ""
		}
	}

	if hostnameRe.MatchString(target) || urlRe.MatchString(target) {
		return target
	}
	return ""
}

// SafeScope filters a scope list to entries safe to interpolate into commands.
// It accepts hostnames, *.hostname wildcards, and CIDR notation.
func SafeScope(scope []string) []string {
	out := make([]string, 0, len(scope))
	for _, s := range scope {
		s = strings.TrimSpace(s)
		if s == "" || len(s) > 256 {
			continue
		}
		if strings.ContainsAny(s, "`$;&|<>(){}[]!\\\"' \t\r\n*?") && !strings.HasPrefix(s, "*.") {
			continue
		}
		// Allow leading *. wildcard, then validate the rest.
		bare := strings.TrimPrefix(s, "*.")
		if hostnameRe.MatchString(bare) || cidrRe.MatchString(bare) {
			out = append(out, s)
		}
	}
	return out
}

var cidrRe = regexp.MustCompile(`^[0-9]{1,3}(?:\.[0-9]{1,3}){3}/[0-9]{1,2}$`)

// BuildContext holds all context needed to construct tool commands
type BuildContext struct {
	Target   string
	ScanID   string
	OutDir   string
	PrevOuts map[string]string // toolID → output file path
	Scope    []string
}

// OutputPath returns the canonical output path for a tool's results
func OutputPath(outDir, scanID, toolID, ext string) string {
	return filepath.Join(outDir, fmt.Sprintf("%s_%s.%s", scanID[:8], toolID, ext))
}

// BuildCommand constructs the shell command for a given tool, using prior phase outputs
// as inputs where applicable. All paths use scanID-namespaced temp files.
//
// Returns the empty string if the target fails strict validation; callers MUST
// treat empty-string as "do not execute".
func BuildCommand(tool *Tool, ctx BuildContext) string {
	id := tool.ID
	if len(ctx.ScanID) < 8 {
		return ""
	}
	scanID8 := ctx.ScanID[:8]
	outDir := ctx.OutDir
	if outDir == "" {
		outDir = "/tmp"
	}

	// Defence-in-depth: reject anything that doesn't match a strict
	// hostname/URL shape. The ROE gate already validated the target at
	// scan start, but we interpolate into bash and treat anything weird
	// as a hard refusal.
	target := SafeTarget(ctx.Target)
	if target == "" {
		return ""
	}

	// Canonical output files — standardised names per tool
	subsFile := filepath.Join(outDir, scanID8+"_subs.txt")
	liveFile := filepath.Join(outDir, scanID8+"_live.txt")
	liveJSON := filepath.Join(outDir, scanID8+"_live.json")
	urlsFile := filepath.Join(outDir, scanID8+"_urls.txt")
	portsFile := filepath.Join(outDir, scanID8+"_ports.json")

	switch id {
	// ─── Phase 1: Recon ───────────────────────────────────────────────────────

	case "subfinder":
		return fmt.Sprintf(
			// Added: -sources c99,certspotter,crtsh for broader passive coverage
			// c99.nl and crt.sh often find subdomains missed by other sources
			`subfinder -d %s -all -silent -t 20 -timeout 30 `+
				`-sources c99,certspotter,crtsh,chaos,shodan,virustotal,bufferover,securitytrails `+
				`-o %s 2>&1`,
			target, subsFile,
		)

	case "assetfinder":
		return fmt.Sprintf(
			`assetfinder --subs-only %s | tee -a %s`,
			target, subsFile,
		)

	case "puredns":
		return fmt.Sprintf(
			`puredns bruteforce /opt/wordlists/subdomains-top1million-5000.txt %s `+
				`--resolvers /opt/resolvers.txt `+
				`--rate-limit 3000 `+
				`--wildcard-tests 5 `+
				`| tee -a %s`,
			target, subsFile,
		)

	case "bbot":
		outBbotDir := filepath.Join(outDir, scanID8+"_bbot")
		return fmt.Sprintf(
			`bbot -t %s -p subdomain-enum -o %s --silent 2>&1 | grep "DNS_NAME\|EMAIL\|IP_ADDRESS" | tee -a %s`,
			target, outBbotDir, subsFile,
		)

	case "whatweb":
		// OPT: whatweb runs on ALL live hosts from httpx, not single target.
		// Tech detection on all hosts feeds nuclei-cve-{tech} conditional chaining.
		return fmt.Sprintf(
			`cat %s | xargs -P 5 -I{} whatweb`+
				` -a 3 --log-json=%s {} 2>/dev/null || true`,
			liveFile,
			filepath.Join(outDir, scanID8+"_whatweb.json"),
		)

	case "wafw00f":
		// OPT: wafw00f runs on ALL live hosts, not just the primary target.
		// OPT-API3: WAF detected → gotestwaf (API bypass test) chains automatically.
		wafOut := filepath.Join(outDir, scanID8+"_waf.json")
		return fmt.Sprintf(
			`cat %s | xargs -P 3 -I{} wafw00f -a {} 2>/dev/null`+
				` | tee %s`+"\n"+
				`# OPT-API3: WAF detected → gotestwaf API bypass test`+"\n"+
				`WAF_COUNT=$(grep -c "detected\|Detected" %s 2>/dev/null || echo 0)`+"\n"+
				`if [[ "$WAF_COUNT" -gt 0 ]] && command -v gotestwaf &>/dev/null; then`+"\n"+
				`  gotestwaf --url https://%s`+
				`  --format json`+
				`  --quiet`+
				`  --skipWAFBlockHTTPCodes 400`+
				`  --timeout 30`+
				`  2>/dev/null | tee %s`+"\n"+
				`  # Feed bypass results to notify`+"\n"+
				`  BYPASS=$(cat %s 2>/dev/null | grep -i "bypass\|passed" | head -3)`+"\n"+
				`  [[ -n "$BYPASS" ]] && printf "WAF BYPASS on %s:\n$BYPASS" | notify -silent 2>/dev/null || true`+"\n"+
				`fi`,
			liveFile, wafOut,
			wafOut,
			target,
			filepath.Join(outDir, scanID8+"_gotestwaf.json"),
			filepath.Join(outDir, scanID8+"_gotestwaf.json"),
			target,
		)

	case "gitleaks":
		// OPT-NOTIFY1: Secret found → instant Telegram alert.
		// gitleaks detects secrets in source → notify fires immediately.
		secretsOut := filepath.Join(outDir, scanID8+"_secrets.json")
		return fmt.Sprintf(
			`gitleaks detect --source . -r %s -f json 2>&1 || true`+"\n"+
				`SECRET_COUNT=$(cat %s 2>/dev/null | jq length 2>/dev/null || echo 0)`+"\n"+
				`if [[ "$SECRET_COUNT" -gt 0 ]]; then`+"\n"+
				`  cat %s | jq -r '.[] | "SECRET: " + .RuleID + " in " + .File' 2>/dev/null`+
				`  | head -5 | notify -silent 2>/dev/null || true`+"\n"+
				`fi`,
			secretsOut, secretsOut, secretsOut,
		)

	// ─── Phase 2: Enumeration ──────────────────────────────────────────────────

	case "httpx":
		// Optimization 1: puredns validates + deduplicates before httpx probes.
		// OPT-API5: httpx detects API framework (FastAPI, Django, Express, Spring)
		//           → vulnapi OWASP scan + kiterunner route discovery injected automatically.
		return fmt.Sprintf(
			`if command -v puredns &>/dev/null && [[ -f /opt/resolvers.txt ]]; then`+
				`  puredns resolve %s --resolvers /opt/resolvers.txt --rate-limit 3000 --silent 2>/dev/null`+
				`  | sort -u`+
				`  | httpx -silent -title -tech-detect -status-code -content-length -response-time`+
				`    -rate-limit 150 -threads 50 -timeout 10 -json -o %s 2>&1`+
				`    | tee %s;`+
				`else`+
				`  sort -u %s`+
				`  | httpx -silent -title -tech-detect -status-code -content-length -response-time`+
				`    -rate-limit 150 -threads 50 -timeout 10 -json -o %s 2>&1`+
				`    | tee %s;`+
				`fi`+"\n"+
				`# OPT-API5: detect API frameworks → chain kiterunner + vulnapi`+"\n"+
				`API_TECH=$(cat %s 2>/dev/null | jq -r '.tech[]?' 2>/dev/null`+
				` | grep -iE 'fastapi|django.*rest|express|spring.*boot|rails|laravel.*api|flask|nestjs' | head -3)`+"\n"+
				`if [[ -n "$API_TECH" ]]; then`+"\n"+
				`  echo "[httpx→API] Framework detected: $API_TECH — injecting kiterunner + vulnapi"`+"\n"+
				`  # kiterunner on all live API hosts`+"\n"+
				`  command -v kr &>/dev/null && cat %s | head -10 | kr scan -`+
				`  -A=apiroutes-210328:20000 -x 5 -j 10`+
				`  --fail-status-codes 400,401,404,403,501,502`+
				`  --timeout 30s 2>/dev/null`+
				`  | grep -oP 'https?://[^\s]+' | anew %s || true`+"\n"+
				`  # vulnapi: OWASP API Top 10 on detected API hosts`+"\n"+
				`  command -v vulnapi &>/dev/null && cat %s | head -5 | while read url; do`+"\n"+
				`    vulnapi scan curl "$url/api" --quiet 2>/dev/null || true`+"\n"+
				`  done`+"\n"+
				`fi`,
			subsFile, liveJSON, liveFile,
			subsFile, liveJSON, liveFile,
			liveJSON,
			liveFile, urlsFile,
			liveFile,
		)

	case "naabu":
		// OPT-CHAIN1: naabu ports → nuclei port-specific tags + vulnapi pe porturi non-standard
		// Port 8080/8443/9090 = API endpoints → vulnapi OWASP scan automat
		return fmt.Sprintf(
			`naabu -l %s `+
				`-p 80,443,8080,8443,8000,8888,9090,3000,5000,4443,7443,8181,9200,27017 `+
				`-rate 1500 `+
				`-timeout 5000 `+
				`-silent `+
				`-json -o %s `+
				`2>/dev/null`+"\n"+
				`# OPT-CHAIN1: porturi non-standard găsite → vulnapi OWASP API scan`+"\n"+
				`API_PORTS=$(cat %s 2>/dev/null | jq -r 'select(.port | IN(8080,8443,8000,3000,5000,9090,4443)) | "http://\(.ip):\(.port)"' 2>/dev/null | head -10)`+"\n"+
				`if [[ -n "$API_PORTS" ]] && command -v vulnapi &>/dev/null; then`+"\n"+
				`  echo "$API_PORTS" | while read api_url; do`+"\n"+
				`    vulnapi scan curl "$api_url" --quiet 2>/dev/null | tee -a %s || true`+"\n"+
				`  done`+"\n"+
				`fi`+"\n"+
				`# OPT-CHAIN1b: port 9200 = Elasticsearch → nuclei elastic templates`+"\n"+
				`ES_HOSTS=$(cat %s 2>/dev/null | jq -r 'select(.port==9200) | "http://\(.ip):9200"' 2>/dev/null | head -3)`+"\n"+
				`[[ -n "$ES_HOSTS" ]] && echo "$ES_HOSTS" | nuclei -t technologies/elastic -silent 2>/dev/null | tee -a %s || true`+"\n"+
				`# OPT-CHAIN1c: port 27017 = MongoDB → nuclei mongo templates`+"\n"+
				`MONGO_HOSTS=$(cat %s 2>/dev/null | jq -r 'select(.port==27017) | .ip' 2>/dev/null | head -3)`+"\n"+
				`[[ -n "$MONGO_HOSTS" ]] && echo "$MONGO_HOSTS" | nuclei -t network/mongodb -silent 2>/dev/null | tee -a %s || true`,
			subsFile, portsFile,
			portsFile,
			filepath.Join(outDir, scanID8+"_vulnapi_ports.txt"),
			portsFile,
			filepath.Join(outDir, scanID8+"_nuclei_ports.txt"),
			portsFile,
			filepath.Join(outDir, scanID8+"_nuclei_ports.txt"),
		)

	case "aquatone":
		return fmt.Sprintf(
			`cat %s | aquatone `+
				`-threads 5 `+
				`-timeout 30000 `+
				`-screenshot-timeout 30000 `+
				`-out %s `+
				`2>&1`,
			liveFile, filepath.Join(outDir, scanID8+"_aquatone"),
		)

	case "hakrawler":
		// OPT-CHAIN6: hakrawler crawls → linkfinder extrage endpoint-uri din JS
		// JS files descoperite de crawler → endpoints ascunse, rute interne, API paths
		linkOut := filepath.Join(outDir, scanID8+"_hakrawler_links.txt")
		return fmt.Sprintf(
			`cat %s | hakrawler`+
				` -depth 3 -subs -u -insecure`+
				` 2>/dev/null | anew %s`+"\n"+
				`# OPT-CHAIN6: JS files din hakrawler → linkfinder endpoint extraction`+"\n"+
				`cat %s 2>/dev/null | grep '\.js$' | sort -u | head -20 | while read jsurl; do`+"\n"+
				`  python3 /opt/LinkFinder/linkfinder.py -i "$jsurl" -o cli 2>/dev/null`+"\n"+
				`done 2>/dev/null | grep -E '^/' | sort -u | while read path; do`+"\n"+
				`  echo "https://%s$path"`+"\n"+
				`done | anew %s`+"\n"+
				`# Noile endpoint-uri → nuclei exposure scan`+"\n"+
				`NEW_PATHS=$(cat %s 2>/dev/null | grep -v -F -f %s | head -20)`+"\n"+
				`[[ -n "$NEW_PATHS" ]] && echo "$NEW_PATHS"`+
				` | nuclei -t exposures/ -severity medium,high,critical -silent 2>/dev/null`+
				` | tee %s || true`,
			liveFile, urlsFile,
			urlsFile, target, urlsFile,
			linkOut, urlsFile,
			filepath.Join(outDir, scanID8+"_hakrawler_nuclei.txt"),
		)

	case "gospider":
		// OPT-CHAIN7: gospider crawl → secretfinder pe JS files găsite
		// gospider descoperă mai multe JS decât katana pe SPAs — cross-validate secrets
		gospiderOut := filepath.Join(outDir, scanID8+"_gospider")
		secretOut   := filepath.Join(outDir, scanID8+"_gospider_secrets.txt")
		return fmt.Sprintf(
			`gospider -S %s`+
				` -t 5 -c 10 -d 3`+
				` --sitemap --robots --json`+
				` -o %s`+
				` 2>/dev/null | jq -r '.output?' 2>/dev/null | grep '^http' | anew %s`+"\n"+
				`# OPT-CHAIN7: JS files din gospider → secretfinder`+"\n"+
				`cat %s 2>/dev/null | grep -E '\.js(\?|$)' | sort -u | head -20 | while read jsurl; do`+"\n"+
				`  python3 /opt/SecretFinder/SecretFinder.py -i "$jsurl" -o cli 2>/dev/null`+"\n"+
				`done | tee %s`+"\n"+
				`# Secret găsit → notify instant`+"\n"+
				`[[ -s %s ]] &&`+
				` printf "SECRET in JS (gospider) on %s:\n$(head -3 %s)"` +
				` | notify -silent 2>/dev/null || true`,
			liveFile, gospiderOut, urlsFile,
			urlsFile, secretOut,
			secretOut, target, secretOut,
		)

	case "gf":
		// Optimization 2: gf filters URLs by pattern THEN pipes to specialized tools.
		// dalfox receives only XSS-candidate URLs (not all URLs) → 80% less work.
		// kxss finds reflected params fast before dalfox deep-tests.
		// anew deduplicates across all pattern outputs.
		xssOut    := filepath.Join(outDir, scanID8+"_gf_xss.txt")
		sqliOut   := filepath.Join(outDir, scanID8+"_gf_sqli.txt")
		ssrfOut   := filepath.Join(outDir, scanID8+"_gf_ssrf.txt")
		redirOut  := filepath.Join(outDir, scanID8+"_gf_redirect.txt")
		otherOuts := filepath.Join(outDir, scanID8+"_gf_other.txt")
		dalfoxOut := filepath.Join(outDir, scanID8+"_dalfox.txt")
		kxssOut   := filepath.Join(outDir, scanID8+"_kxss.txt")

		return fmt.Sprintf(
			// Pattern extraction
			`cat %s | gf xss  | anew %s 2>/dev/null;`+
			`cat %s | gf sqli | anew %s 2>/dev/null;`+
			`cat %s | gf ssrf | anew %s 2>/dev/null;`+
			`cat %s | gf redirect | anew %s 2>/dev/null;`+
			// kxss: fast reflected param check on XSS candidates
			`cat %s | kxss 2>/dev/null | grep -v 'Filtered' | tee %s;`+
			// dalfox: deep XSS test ONLY on gf xss output (not all URLs)
			`cat %s | dalfox pipe --silence --skip-bav --timeout 10 2>/dev/null | tee -a %s;`+
			// Merge remaining patterns for other tools
			`cat %s %s %s | sort -u | tee %s`,
			urlsFile, xssOut,
			urlsFile, sqliOut,
			urlsFile, ssrfOut,
			urlsFile, redirOut,
			xssOut, kxssOut,
			xssOut, dalfoxOut,
			sqliOut, ssrfOut, redirOut, otherOuts,
		)

	// ─── Phase 3: Scanning ────────────────────────────────────────────────────

	case "nuclei":
		// Optimization 3: Tech-aware nuclei execution.
		// httpx outputs JSON with tech detection. We parse it to run targeted templates.
		// WordPress detected → run wordpress tags. Apache → apache/webserver tags.
		// Falls back to generic scan if no tech data available.
		// This reduces template count from 9k+ to relevant subset per target.
		nucleiOut := filepath.Join(outDir, scanID8+"_nuclei.json")
		return fmt.Sprintf(
			`# Tech-aware nuclei: extract tech from httpx JSON and target templates`+"\n"+
			`TECH_TAGS=""`+"\n"+
			`if [[ -f %s ]]; then`+"\n"+
			`  TECH=$(cat %s | jq -r '.tech[]?' 2>/dev/null | tr '[:upper:]' '[:lower:]' | sort -u)`+"\n"+
			`  echo "$TECH" | grep -qi "wordpress" && TECH_TAGS="$TECH_TAGS,wordpress"`+"\n"+
			`  echo "$TECH" | grep -qi "apache"    && TECH_TAGS="$TECH_TAGS,apache"`+"\n"+
			`  echo "$TECH" | grep -qi "nginx"     && TECH_TAGS="$TECH_TAGS,nginx"`+"\n"+
			`  echo "$TECH" | grep -qi "php"       && TECH_TAGS="$TECH_TAGS,php"`+"\n"+
			`  echo "$TECH" | grep -qi "spring"    && TECH_TAGS="$TECH_TAGS,springboot,spring"`+"\n"+
			`  echo "$TECH" | grep -qi "node\|express" && TECH_TAGS="$TECH_TAGS,node.js"`+"\n"+
			`  echo "$TECH" | grep -qi "drupal"    && TECH_TAGS="$TECH_TAGS,drupal"`+"\n"+
			`  echo "$TECH" | grep -qi "jira"      && TECH_TAGS="$TECH_TAGS,jira"`+"\n"+
			`  echo "$TECH" | grep -qi "jenkins"   && TECH_TAGS="$TECH_TAGS,jenkins"`+"\n"+
			`fi`+"\n"+
			`# Always include: cves, exposures, misconfigs, takeovers`+"\n"+
			`BASE_TAGS="cve,exposure,misconfiguration,takeover,default-login"`+"\n"+
			`ALL_TAGS="${BASE_TAGS}${TECH_TAGS}"`+"\n"+
			`nuclei -l %s`+
			` -tags "$ALL_TAGS"`+
			` -exclude-tags dos,intrusive`+
			` -rate-limit 50`+
			` -bulk-size 25`+
			` -concurrency 10`+
			` -severity medium,high,critical`+
			` -timeout 10`+
			` -retries 1`+
			` -silent`+
			` -json-export %s`+
			` 2>&1`,
			liveJSON, liveJSON,
			liveFile, nucleiOut,
		)

	case "ffuf":
		return fmt.Sprintf(
			`ffuf `+
				`-u https://%s/FUZZ `+
				`-w /opt/wordlists/raft-medium.txt `+
				`-mc 200,201,204,301,302,307,401,403,405 `+
				`-fc 404 `+
				`-rate 100 `+
				`-timeout 10 `+
				`-recursion -recursion-depth 2 `+
				`-se `+
				`-json `+
				`-o %s `+
				`2>&1`,
			target, filepath.Join(outDir, scanID8+"_ffuf.json"),
		)

	case "wfuzz":
		// OPT: wfuzz uses custom wordlist built from historical URLs (ffuf-custom).
		// Falls back to common.txt if custom wordlist not yet available.
		customWL := filepath.Join(outDir, scanID8+"_custom_wordlist.txt")
		wfuzzOut := filepath.Join(outDir, scanID8+"_wfuzz.json")
		return fmt.Sprintf(
			`WL=%s`+"\n"+
				`[[ ! -f "$WL" ]] || [[ ! -s "$WL" ]] && WL="/opt/wordlists/common.txt"`+"\n"+
				`wfuzz -u https://%s/FUZZ`+
				` -w "$WL"`+
				` --hc 404,429`+
				` -t 50`+
				` -f %s,json`+
				` 2>/dev/null`,
			customWL, target, wfuzzOut,
		)

	case "nikto":
		// OPT: nikto runs on ALL live hosts from httpx, not single hardcoded target.
		// Parallel: 3 hosts at a time via xargs.
		return fmt.Sprintf(
			`cat %s | xargs -P 3 -I{} nikto`+
				` -h {}`+
				` -Format json`+
				` -output %s`+
				` -Tuning x6`+
				` -maxtime 120s`+
				` -nointeractive`+
				` 2>/dev/null || true`,
			liveFile,
			filepath.Join(outDir, scanID8+"_nikto.json"),
		)

	case "403fuzzer":
		return fmt.Sprintf(
			`python3 /opt/bbounty-tools/403fuzzer/403fuzzer.py `+
				`-u https://%s/admin `+
				`-t 10 `+
				`2>&1 | tee %s`,
			target, filepath.Join(outDir, scanID8+"_403fuzzer.txt"),
		)

	case "nomore403":
		return fmt.Sprintf(
			`nomore403 --url https://%s/admin --verbose 2>&1 | tee %s`,
			target, filepath.Join(outDir, scanID8+"_nomore403.txt"),
		)

	case "graphw00f":
		// OPT: graphw00f tests ALL discovered GraphQL paths from httpx/katana.
		// OPT-API4: GraphQL confirmed → kiterunner (API routes) + vulnapi + graphql-cop chain.
		gqlOut    := filepath.Join(outDir, scanID8+"_graphw00f.txt")
		gqlCopOut := filepath.Join(outDir, scanID8+"_graphql_cop.json")
		return fmt.Sprintf(
			`GQL_URLS=$(cat %s 2>/dev/null`+
				` | grep -i "graphql\|/query\|/gql\|/graphiql" | head -10)`+"\n"+
				`[[ -z "$GQL_URLS" ]] && GQL_URLS="https://%s/graphql https://%s/api/graphql https://%s/v1/graphql"`+"\n"+
				`echo "$GQL_URLS" | tr ' ' '\n' | while read gurl; do`+"\n"+
				`  graphw00f -t "$gurl" -d -f 2>/dev/null`+"\n"+
				`done | tee %s`+"\n"+
				`# OPT-API4: GraphQL confirmed → chain kiterunner + vulnapi + graphql-cop`+"\n"+
				`GQL_HOST=$(grep -oP 'https?://[^/]+' %s 2>/dev/null | head -1)`+"\n"+
				`if [[ -n "$GQL_HOST" ]]; then`+"\n"+
				`  # kiterunner: discover more API routes on same host`+"\n"+
				`  command -v kr &>/dev/null && echo "$GQL_HOST" | kr scan -`+
				`  -A=apiroutes-210328:20000 -x 5 -j 10`+
				`  --fail-status-codes 400,401,404,403,501,502`+
				`  --timeout 30s 2>/dev/null`+
				`  | grep -oP 'https?://[^\s]+' | anew %s || true`+"\n"+
				`  # vulnapi: OWASP API Top 10 on confirmed GraphQL host`+"\n"+
				`  command -v vulnapi &>/dev/null && vulnapi scan curl "$GQL_HOST/graphql" --quiet 2>/dev/null || true`+"\n"+
				`  # graphql-cop: full audit`+"\n"+
				`  command -v graphql-cop &>/dev/null && graphql-cop --target "$GQL_HOST/graphql" --output json 2>/dev/null | tee %s || true`+"\n"+
				`fi`,
			urlsFile,
			target, target, target,
			gqlOut,
			gqlOut,
			urlsFile,
			gqlCopOut,
		)

	// ─── Phase 4: Exploitation ────────────────────────────────────────────────

	case "commix":
		// OPT: commix gets exact OS injection URLs from nuclei/gf output.
		// Not hardcoded ?id=1 — actual injectable endpoints discovered earlier.
		commixOut := filepath.Join(outDir, scanID8+"_commix")
		gfOther   := filepath.Join(outDir, scanID8+"_gf_other.txt")
		return fmt.Sprintf(
			`# Try nuclei-confirmed command injection URLs first`+"\n"+
				`CMD_URL=$(cat %s 2>/dev/null`+
				` | jq -r 'select(.info.tags[]? == "rce" or .info.tags[]? == "command-injection")`+
				` | .matched-at' 2>/dev/null | head -3)`+"\n"+
				`if [[ -z "$CMD_URL" ]]; then`+"\n"+
				`  # Fallback: gf rce/redirect patterns`+"\n"+
				`  CMD_URL=$(cat %s 2>/dev/null | grep -E '(cmd|exec|command|ping|id)=' | head -3)`+"\n"+
				`fi`+"\n"+
				`if [[ -n "$CMD_URL" ]]; then`+"\n"+
				`  echo "$CMD_URL" | while read u; do`+"\n"+
				`    python3 /opt/commix/commix.py --url="$u"`+
				`    --level=2 --output-dir=%s --batch 2>/dev/null`+"\n"+
				`  done`+"\n"+
				`else`+"\n"+
				`  python3 /opt/commix/commix.py`+
				`  --url="https://%s/?cmd=id"`+
				`  --level=1 --output-dir=%s --batch 2>/dev/null`+"\n"+
				`fi`,
			filepath.Join(outDir, scanID8+"_nuclei.json"),
			gfOther, commixOut,
			target, commixOut,
		)

	case "corsy":
		return fmt.Sprintf(
			`python3 /opt/bbounty-tools/Corsy/corsy.py `+
				`-i %s `+
				`-t 10 `+
				`-o %s `+
				`2>&1`,
			liveFile, filepath.Join(outDir, scanID8+"_corsy.json"),
		)

	case "crlfuzz":
		// OPT: crlfuzz runs on gf-filtered URLs (params), not just root /.
		// CRLF injection is parameter-based — root path is usually not vulnerable.
		gfXss := filepath.Join(outDir, scanID8+"_gf_xss.txt")
		return fmt.Sprintf(
			`# Use gf xss URLs as they often overlap with CRLF-injectable params`+"\n"+
				`if [[ -f %s ]] && [[ -s %s ]]; then`+"\n"+
				`  cat %s | head -30 | crlfuzz pipe -c 15 -s 2>/dev/null | tee %s`+"\n"+
				`else`+"\n"+
				`  crlfuzz -u https://%s/ -c 25 -s 2>/dev/null | tee %s`+"\n"+
				`fi`,
			gfXss, gfXss,
			gfXss, filepath.Join(outDir, scanID8+"_crlfuzz.txt"),
			target, filepath.Join(outDir, scanID8+"_crlfuzz.txt"),
		)

	case "ssrfmap":
		reqFile := filepath.Join(outDir, scanID8+"_ssrf_req.txt")
		// Write a sample request file first
		writeReqCmd := fmt.Sprintf(
			`printf 'GET /?url=SSRF_URL HTTP/1.1\r\nHost: %s\r\nUser-Agent: Mozilla/5.0\r\n\r\n' > %s`,
			target, reqFile,
		)
		return writeReqCmd + " && " + fmt.Sprintf(
			`python3 /opt/ssrfmap/ssrfmap.py -r %s -p url -m readfiles 2>&1 | tee %s`,
			reqFile, filepath.Join(outDir, scanID8+"_ssrfmap.txt"),
		)

	case "smuggler":
		return fmt.Sprintf(
			`python3 /opt/smuggler/smuggler.py `+
				`-u https://%s/ `+
				`-t 5 `+
				`--log %s `+
				`2>&1`,
			target, filepath.Join(outDir, scanID8+"_smuggler.txt"),
		)

	case "jwt-tool":
		// OPT: Extract real JWT tokens from httpx JSON response headers.
		// jwt-tool gets actual tokens from Authorization/Cookie headers — not fake ones.
		jwtOut := filepath.Join(outDir, scanID8+"_jwt.txt")
		return fmt.Sprintf(
			`# Extract real JWTs from httpx JSON output`+"\n"+
				`JWT=$(cat %s 2>/dev/null`+
				` | jq -r '.response_headers // {} | to_entries[]`+
				` | select(.key | test("authorization|set-cookie"; "i"))`+
				` | .value' 2>/dev/null`+
				` | grep -oP 'eyJ[A-Za-z0-9_-]+\.eyJ[A-Za-z0-9_-]+\.[A-Za-z0-9_-]+'`+
				` | head -3)`+"\n"+
				`if [[ -n "$JWT" ]]; then`+"\n"+
				`  echo "$JWT" | while read token; do`+"\n"+
				`    python3 /opt/jwt-tool/jwt_tool.py "$token"`+
				`    -t https://%s/ -M at 2>/dev/null`+"\n"+
				`  done | tee %s`+"\n"+
				`else`+"\n"+
				`  echo "[jwt-tool] No JWT found in httpx headers — testing endpoints for JWT"` +"\n"+
				`  python3 /opt/jwt-tool/jwt_tool.py`+
				`  -t https://%s/ -M pb 2>/dev/null | tee %s`+"\n"+
				`fi`,
			liveJSON, target, jwtOut,
			target, jwtOut,
		)

	case "race-the-web":
		// OPT: race-the-web gets real POST endpoints from arjun/katana discovery.
		// Not hardcoded /api/redeem — actual endpoints that accept POST requests.
		cfgFile  := filepath.Join(outDir, scanID8+"_race.toml")
		raceOut  := filepath.Join(outDir, scanID8+"_race.txt")
		arjunOut := filepath.Join(outDir, scanID8+"_arjun.json")
		return fmt.Sprintf(
			`# Extract POST endpoints from arjun discovery or katana`+"\n"+
				`RACE_URL=$(cat %s 2>/dev/null`+
				` | jq -r '.[] | select(.method == "POST" or (.params | length) > 0) | .url'`+
				` 2>/dev/null | head -1)`+"\n"+
				`[[ -z "$RACE_URL" ]] && RACE_URL=$(grep -i "redeem\|coupon\|payment\|transfer\|vote\|like"` +
				` %s 2>/dev/null | grep '^http' | head -1)`+"\n"+
				`[[ -z "$RACE_URL" ]] && RACE_URL="https://%s/api/redeem"`+"\n"+
				`cat > %s << RACEEOF`+"\n"+
				`[[requests]]`+"\n"+
				`url = "$RACE_URL"`+"\n"+
				`method = "POST"`+"\n"+
				`body = '{"code":"RACE10"}'`+"\n"+
				`count = 20`+"\n"+
				`RACEEOF`+"\n"+
				`race-the-web -config %s 2>&1 | tee %s`,
			arjunOut, urlsFile, target,
			cfgFile, cfgFile, raceOut,
		)

	// ── BBounty Live Agent ────────────────────────────────────────────────────
	// Spawns ultra_agent.py with all pipeline context injected as env vars.
	// The agent runs 10 parallel bug bounty modules and POSTs findings back
	// to the orchestrator via orchestrator_client.py automatically.
	case "nomore403-smart":
		// OPT2: Extract actual 401/403 URLs from httpx JSON, test bypass on each.
		// Much more effective than hardcoded /admin path.
		return fmt.Sprintf(
			`cat %s 2>/dev/null `+
				`| jq -r 'select(.status_code == 401 or .status_code == 403) | .url' 2>/dev/null `+
				`| head -20 `+
				`| while read url; do`+
				`  nomore403 --url "$url" --verbose 2>/dev/null;`+
				`  byp4xx "$url" 2>/dev/null || true;`+
				`done | tee %s`,
			liveJSON,
			filepath.Join(outDir, scanID8+"_403bypass.txt"),
		)

	case "sqlmap-targeted":
		// OPT3: Extract exact SQLi URL+param from nuclei/gf output, pass to sqlmap.
		// Avoids sqlmap crawling — it already knows the vulnerable endpoint.
		return fmt.Sprintf(
			`# Extract SQLi URLs from nuclei JSON`+"\n"+
			`SQLI_URL=$(cat %s 2>/dev/null | jq -r 'select(.info.tags[]? == "sqli" or .info.id | test("sql")) | .matched-at' 2>/dev/null | head -1)`+"\n"+
			`# Fallback: use gf sqli output`+"\n"+
			`[[ -z "$SQLI_URL" ]] && SQLI_URL=$(cat %s 2>/dev/null | head -1)`+"\n"+
			`if [[ -n "$SQLI_URL" ]]; then`+"\n"+
			`  sqlmap -u "$SQLI_URL" --batch --random-agent --level=2 --risk=2`+
			`  --output-dir=%s --dbs --timeout=30 2>&1 | tee %s`+"\n"+
			`fi`,
			filepath.Join(outDir, scanID8+"_nuclei.json"),
			filepath.Join(outDir, scanID8+"_gf_sqli.txt"),
			filepath.Join(outDir, scanID8+"_sqlmap"),
			filepath.Join(outDir, scanID8+"_sqlmap_targeted.txt"),
		)

	case "trufflehog-js":
		// OPT4: Run trufflehog on JS files discovered by crawlers.
		// Finds secrets in live JS bundles (not just git repos).
		return fmt.Sprintf(
			`grep '\.js' %s 2>/dev/null | grep '^http' | sort -u | head -30 `+
				`| while read jsurl; do`+
				`  trufflehog filesystem <(curl -sf --max-time 10 "$jsurl" 2>/dev/null)`+
				`  --no-verification --json 2>/dev/null;`+
				`done | tee %s`,
			urlsFile,
			filepath.Join(outDir, scanID8+"_trufflehog_js.json"),
		)

	case "nuclei-paths":
		// OPT5: Run nuclei on new paths discovered by ffuf/wfuzz.
		// Targets misconfigs on non-obvious endpoints (backups, admin panels, etc.)
		return fmt.Sprintf(
			`# Extract new paths from ffuf JSON`+"\n"+
			`cat %s 2>/dev/null | jq -r '.results[]? | select(.status == 200 or .status == 301) | .url' 2>/dev/null`+
			` | head -50 | tee %s`+"\n"+
			`nuclei -l %s`+
			` -tags exposure,misconfiguration,default-login,backup`+
			` -severity medium,high,critical`+
			` -rate-limit 30`+
			` -silent`+
			` -json-export %s`+
			` 2>&1`,
			filepath.Join(outDir, scanID8+"_ffuf.json"),
			filepath.Join(outDir, scanID8+"_ffuf_paths.txt"),
			filepath.Join(outDir, scanID8+"_ffuf_paths.txt"),
			filepath.Join(outDir, scanID8+"_nuclei_paths.json"),
		)

	// ── OPT-NEW1: subzy takeover confirmed → notify instant ───────────────────
	case "subzy":
		subzyOut := filepath.Join(outDir, scanID8+"_takeover.txt")
		return fmt.Sprintf(
			`subzy run --targets %s --hide-fails --verify 2>/dev/null | tee %s`+"\n"+
				`TAKEOVER=$(grep -i "vulnerable\|VULNERABLE" %s 2>/dev/null | head -5)`+"\n"+
				`if [[ -n "$TAKEOVER" ]]; then`+"\n"+
				`  printf "TAKEOVER CONFIRMED on %s:\n$TAKEOVER" | notify -silent 2>/dev/null || true`+"\n"+
				`fi`,
			subsFile, subzyOut, subzyOut, target,
		)

	// ── OPT-NEW2: trufflehog secret → notify instant ──────────────────────────
	case "trufflehog":
		truffOut := filepath.Join(outDir, scanID8+"_trufflehog.json")
		return fmt.Sprintf(
			`trufflehog git https://%s --json --no-verification 2>/dev/null | tee %s`+"\n"+
				`SECRET=$(cat %s 2>/dev/null | jq -r '.DetectorName + ": " + (.SourceMetadata.Data.Git.file // "?")' 2>/dev/null | head -3)`+"\n"+
				`if [[ -n "$SECRET" ]]; then`+"\n"+
				`  printf "SECRET FOUND on %s:\n$SECRET" | notify -silent 2>/dev/null || true`+"\n"+
				`fi`,
			target, truffOut, truffOut, target,
		)

	// ── OPT-NEW3: httpx → arjun parameter discovery → gf → dalfox ────────────
	// OPT-CHAIN2: arjun params → vulnapi (API endpoints cu parametri = OWASP risk)
	case "arjun":
		arjunOut    := filepath.Join(outDir, scanID8+"_arjun.json")
		arjunParams := filepath.Join(outDir, scanID8+"_arjun_urls.txt")
		arjunXSS    := filepath.Join(outDir, scanID8+"_arjun_xss.txt")
		return fmt.Sprintf(
			`# arjun discovers hidden parameters on live hosts`+"\n"+
				`cat %s | head -20 | while read url; do`+"\n"+
				`  arjun -u "$url" -m GET POST --stable -oJ %s 2>/dev/null || true`+"\n"+
				`done`+"\n"+
				`# Extract discovered param URLs → feed into gf + dalfox`+"\n"+
				`cat %s 2>/dev/null`+
				`  | jq -r '.[] | .url + "?" + (.params | keys | join("=FUZZ&")) + "=FUZZ"' 2>/dev/null`+
				`  | grep '^http' | anew %s`+"\n"+
				`# Quick dalfox pass on arjun-discovered params`+"\n"+
				`cat %s | head -10 | dalfox pipe --silence --skip-bav --timeout 10 2>/dev/null`+
				`  | tee %s`+"\n"+
				`# OPT-CHAIN2: endpoints cu multi-param → vulnapi OWASP API check`+"\n"+
				`# Logica: dacă arjun găsește 3+ parametri = endpoint API bogat = risc OWASP ridicat`+"\n"+
				`RICH_ENDPOINTS=$(cat %s 2>/dev/null`+
				`  | jq -r '.[] | select(.params | length >= 3) | .url' 2>/dev/null | head -5)`+"\n"+
				`if [[ -n "$RICH_ENDPOINTS" ]] && command -v vulnapi &>/dev/null; then`+"\n"+
				`  echo "$RICH_ENDPOINTS" | while read ep; do`+"\n"+
				`    vulnapi scan curl "$ep" --quiet 2>/dev/null | tee -a %s || true`+"\n"+
				`  done`+"\n"+
				`fi`,
			liveFile, arjunOut,
			arjunOut, arjunParams,
			arjunParams, arjunXSS,
			arjunOut,
			filepath.Join(outDir, scanID8+"_vulnapi_params.txt"),
		)

	// ── OPT-NEW4: alterx permutations → puredns → new live hosts ─────────────
	case "alterx":
		alterxOut  := filepath.Join(outDir, scanID8+"_alterx.txt")
		alterxLive := filepath.Join(outDir, scanID8+"_alterx_live.txt")
		return fmt.Sprintf(
			`# alterx generates subdomain permutations (dev, staging, api-v2, etc.)`+"\n"+
				`cat %s | alterx -silent 2>/dev/null | tee %s`+"\n"+
				`# puredns resolves only real ones (filters NXDOMAIN)`+"\n"+
				`if command -v puredns &>/dev/null && [[ -f /opt/resolvers.txt ]]; then`+"\n"+
				`  cat %s | puredns resolve --resolvers /opt/resolvers.txt --rate-limit 3000 --silent 2>/dev/null`+
				`  | anew %s`+"\n"+
				`  anew %s < %s`+"\n"+
				`else`+"\n"+
				`  cat %s | httpx -silent | anew %s`+"\n"+
				`fi`,
			subsFile, alterxOut,
			alterxOut, alterxLive,
			subsFile, alterxLive,
			alterxOut, alterxLive,
		)

	// ── OPT-NEW5: nmap service version → searchsploit CVE lookup ──────────────
	case "nmap":
		nmapOut    := filepath.Join(outDir, scanID8+"_nmap.xml")
		nmapTxt    := filepath.Join(outDir, scanID8+"_nmap.txt")
		sploutOut  := filepath.Join(outDir, scanID8+"_searchsploit.txt")
		return fmt.Sprintf(
			`nmap -sV -sC --open -T4 -iL %s -oX %s -oN %s 2>&1`+"\n"+
				`# Extract service+version strings → searchsploit`+"\n"+
				`if command -v searchsploit &>/dev/null; then`+"\n"+
				`  grep -oP '(?<=Service Info: ).*|(?<=\d/tcp\s+open\s+\S+\s).*' %s 2>/dev/null`+
				`  | sort -u | head -20`+
				`  | while read svc; do`+
				`    searchsploit --colour "$svc" 2>/dev/null | grep -v "No Results";`+
				`  done | tee %s`+"\n"+
				`fi`,
			liveFile, nmapOut, nmapTxt,
			nmapTxt, sploutOut,
		)

	// ── OPT-NEW6: nuclei Critical 7/7 gates → bountyplz auto-submit ───────────
	case "bountyplz":
		reportMD := filepath.Join("/tmp", "bbounty-report-"+scanID8+".md")
		return fmt.Sprintf(
			`# Only auto-submit if: report exists + BOUNTYPLZ_LIVE=1 + BOUNTYPLZ_PLATFORM set`+"\n"+
				`PLATFORM="${BOUNTYPLZ_PLATFORM:-}"` +"\n"+
				`LIVE="${BOUNTYPLZ_LIVE:-0}"` +"\n"+
				`if [[ -z "$PLATFORM" ]]; then`+"\n"+
				`  echo "[bountyplz] Skipped: set BOUNTYPLZ_PLATFORM=hackerone|bugcrowd"`+"\n"+
				`  exit 0`+"\n"+
				`fi`+"\n"+
				`if [[ ! -f %s ]]; then`+"\n"+
				`  echo "[bountyplz] No report found at %s — run report-writing phase first"`+"\n"+
				`  exit 0`+"\n"+
				`fi`+"\n"+
				`# Count Critical/High findings in report`+"\n"+
				`CRIT=$(grep -c "Critical\|critical" %s 2>/dev/null || echo 0)`+"\n"+
				`if [[ "$CRIT" -eq 0 ]]; then`+"\n"+
				`  echo "[bountyplz] No Critical findings — skipping auto-submit"`+"\n"+
				`  exit 0`+"\n"+
				`fi`+"\n"+
				`if [[ "$LIVE" == "1" ]]; then`+"\n"+
				`  bountyplz "$PLATFORM" -t %s 2>&1 | tee %s`+"\n"+
				`else`+"\n"+
				`  bountyplz "$PLATFORM" -t %s --dry-run 2>&1 | tee %s`+"\n"+
				`  echo "[bountyplz] DRY-RUN — set BOUNTYPLZ_LIVE=1 to submit for real"`+"\n"+
				`fi`,
			reportMD, reportMD, reportMD,
			reportMD, filepath.Join(outDir, scanID8+"_bountyplz.txt"),
			reportMD, filepath.Join(outDir, scanID8+"_bountyplz_dryrun.txt"),
		)

	case "nuclei-waf-bypass":
		// OPT6: WAF detected → nuclei with bypass-specific tags.
		// Uses header manipulation, encoding bypasses, chunked transfer.
		return fmt.Sprintf(
			`nuclei -l %s`+
				` -tags waf-bypass,bypass`+
				` -severity medium,high,critical`+
				` -H "X-Forwarded-For: 127.0.0.1"`+
				` -H "X-Real-IP: 127.0.0.1"`+
				` -H "X-Originating-IP: 127.0.0.1"`+
				` -rate-limit 20`+
				` -silent`+
				` -json-export %s`+
				` 2>&1`,
			liveFile,
			filepath.Join(outDir, scanID8+"_nuclei_waf.json"),
		)

	case "ssrfmap-targeted":
		// OPT7: Extract exact SSRF URL from nuclei JSON → ssrfmap.
		return fmt.Sprintf(
			`SSRF_URL=$(cat %s 2>/dev/null`+
				` | jq -r 'select(.info.tags[]? == "ssrf" or (.info.id | test("ssrf"))) | .matched-at' 2>/dev/null`+
				` | head -1)`+"\n"+
				`[[ -z "$SSRF_URL" ]] && SSRF_URL=$(cat %s | gf ssrf 2>/dev/null | head -1)`+"\n"+
				`if [[ -n "$SSRF_URL" ]]; then`+"\n"+
				`  PARAM=$(echo "$SSRF_URL" | grep -oP '[?&]\K[^=]+(?==http)' | head -1)`+"\n"+
				`  printf "GET $SSRF_URL HTTP/1.1\r\nHost: %s\r\n\r\n" > %s`+"\n"+
				`  python3 /opt/ssrfmap/ssrfmap.py -r %s -p "${PARAM:-url}" -m readfiles 2>&1 | tee %s`+"\n"+
				`fi`,
			filepath.Join(outDir, scanID8+"_nuclei.json"),
			urlsFile, target,
			filepath.Join(outDir, scanID8+"_ssrf_req.txt"),
			filepath.Join(outDir, scanID8+"_ssrf_req.txt"),
			filepath.Join(outDir, scanID8+"_ssrfmap_targeted.txt"),
		)

	case "smuggler-targeted":
		// OPT8: CRLF found → test HTTP request smuggling on same host.
		// CRLF and smuggling often co-exist on same misconfigured proxy.
		return fmt.Sprintf(
			`CRLF_HOST=$(cat %s 2>/dev/null | head -5 | grep -oP 'https?://[^/]+' | head -1)`+"\n"+
				`[[ -z "$CRLF_HOST" ]] && CRLF_HOST="https://%s"`+"\n"+
				`python3 /opt/smuggler/smuggler.py -u "$CRLF_HOST/" -t 5 --log %s 2>&1`,
			filepath.Join(outDir, scanID8+"_crlfuzz.txt"),
			target,
			filepath.Join(outDir, scanID8+"_smuggler_targeted.txt"),
		)

	case "ffuf-custom":
		// OPT9: Use discovered historical paths as custom ffuf wordlist.
		// Much more targeted than raft-medium.txt — these paths existed before.
		customWordlist := filepath.Join(outDir, scanID8+"_custom_wordlist.txt")
		return fmt.Sprintf(
			`# Build custom wordlist from discovered URLs`+"\n"+
				`cat %s 2>/dev/null | grep '^http' | grep -oP '(?<=/)([^?#/]+)' | sort -u | head -500 > %s`+"\n"+
				`# Merge with common paths`+"\n"+
				`cat /usr/share/wordlists/dirb/common.txt 2>/dev/null | anew %s`+"\n"+
				`# Run ffuf with custom wordlist`+"\n"+
				`ffuf -u https://%s/FUZZ -w %s -mc 200,201,301,302,401,403`+
				` -fc 404 -rate 80 -timeout 10 -se -json -o %s 2>&1`,
			urlsFile, customWordlist, customWordlist,
			target, customWordlist,
			filepath.Join(outDir, scanID8+"_ffuf_custom.json"),
		)

	case "notify-xss":
		// OPT10: XSS confirmed → instant Telegram/Slack alert via notify.
		nucleiOut := filepath.Join(outDir, scanID8+"_nuclei.json")
		dalfoxOut := filepath.Join(outDir, scanID8+"_dalfox.txt")
		alertsOut := filepath.Join(outDir, scanID8+"_xss_alerts.txt")
		return fmt.Sprintf(
			`XSS_URL=$(cat %s 2>/dev/null | jq -r 'select(.info.tags[]? == "xss") | "XSS: " + .matched-at' 2>/dev/null | head -3)`+"\n"+
				`if [[ -n "$XSS_URL" ]]; then`+"\n"+
				`  printf "XSS CONFIRMED on %s:\n$XSS_URL" | notify -silent 2>/dev/null`+"\n"+
				`fi`+"\n"+
				`DALFOX=$(cat %s 2>/dev/null | grep "POC" | head -3)`+"\n"+
				`[[ -n "$DALFOX" ]] && printf "XSS dalfox PoC:\n$DALFOX" | notify -silent 2>/dev/null`+"\n"+
				`printf "%s\n$XSS_URL\n$DALFOX" | tee %s`,
			nucleiOut, target, dalfoxOut, target, alertsOut,
		)

	case "bbounty-agent":
		agentScript := os.Getenv("BBOUNTY_AGENT_SCRIPT")
	if agentScript == "" {
		// Try common locations in order
		candidates := []string{
			"/opt/bbounty-pro/apps/agents/specialist_agents/ultra_agent.py",
			"./apps/agents/specialist_agents/ultra_agent.py",
			"../agents/specialist_agents/ultra_agent.py",
		}
		for _, c := range candidates {
			if _, err := os.Stat(c); err == nil {
				agentScript = c
				break
			}
		}
	}
	if agentScript == "" {
		return "echo '[bbounty-agent] agent script not found — set BBOUNTY_AGENT_SCRIPT env var'"
	}
		agentOut    := filepath.Join(outDir, scanID8+"_bbounty_agent.txt")
		// Env vars are injected by pipeline.go shell() before exec.
		// Here we just build the command — SCAN_ID, BBOUNTY_TARGET, BBOUNTY_API
		// are already in the subprocess environment.
		return fmt.Sprintf(
			`python3 %s --target %s --mode full --scope "%s" 2>&1 | tee %s`,
			agentScript, target,
			strings.Join(ctx.Scope, ","),
			agentOut,
		)

	// ── osmedeus ─────────────────────────────────────────────────────────────
	case "osmedeus":
		// osmedeus is a full recon framework — run with target domain.
		// Serial tool: has its own internal parallelism.
		osmedeusOut := filepath.Join(outDir, scanID8+"_osmedeus")
		return fmt.Sprintf(
			`if command -v osmedeus &>/dev/null; then`+"\n"+
				`  osmedeus scan -t %s --output %s 2>/dev/null || true`+"\n"+
				`  find %s -name "*.txt" 2>/dev/null | xargs cat | grep '^http' | anew %s`+"\n"+
				`else`+"\n"+
				`  echo "[osmedeus] not installed — skipping" | tee %s/skip.txt`+"\n"+
				`fi`,
			target, osmedeusOut, osmedeusOut, urlsFile, osmedeusOut,
		)

	// ── nuclei-ai ────────────────────────────────────────────────────────────
	case "nuclei-ai":
		// nuclei-ai uses AI-generated templates for unknown vulnerabilities.
		// Runs after standard nuclei — targets only high-value live hosts.
		nucleiAIOut := filepath.Join(outDir, scanID8+"_nuclei_ai.json")
		return fmt.Sprintf(
			`nuclei -l %s`+
				` -ai`+
				` -severity high,critical`+
				` -rate-limit 20`+
				` -silent`+
				` -json-export %s 2>/dev/null || true`,
			liveFile, nucleiAIOut,
		)

	// ── ffuf-vhost ───────────────────────────────────────────────────────────
	case "ffuf-vhost":
		// Virtual host discovery via Host header fuzzing.
		// Uses subdomain wordlist from SecLists.
		vhostOut := filepath.Join(outDir, scanID8+"_vhost.json")
		vhostWL  := "/usr/share/seclists/Discovery/DNS/subdomains-top1million-5000.txt"
		return fmt.Sprintf(
			`[[ ! -f %s ]] && exit 0`+"\n"+
				`BASELINE=$(curl -sf --max-time 5 -o /dev/null -w '%%{size_body}' "https://%s/" 2>/dev/null)`+"\n"+
				`ffuf -u "https://%s/" -H "Host: FUZZ.%s"`+
				` -w %s`+
				` -mc 200,301,302,401,403`+
				` -fs "$BASELINE"`+
				` -t 40 -timeout 10`+
				` -silent -json -o %s 2>/dev/null || true`,
			vhostWL,
			target, target, target,
			vhostWL, vhostOut,
		)

	// ── linkfinder ───────────────────────────────────────────────────────────
	case "linkfinder":
		// linkfinder extracts endpoints from JS files discovered by katana.
		// Finds internal APIs, hidden routes, hardcoded paths.
		linkOut := filepath.Join(outDir, scanID8+"_linkfinder.txt")
		return fmt.Sprintf(
			`cat %s 2>/dev/null | grep '\.js' | grep '^http' | sort -u | head -30`+"\n"+
				`| while read jsurl; do`+"\n"+
				`  python3 /opt/LinkFinder/linkfinder.py -i "$jsurl" -o cli 2>/dev/null`+"\n"+
				`done | grep -E '^/' | sort -u | anew %s`+"\n"+
				`# Convert relative paths to absolute URLs`+"\n"+
				`cat %s | sed "s|^|https://%s|" | anew %s`,
			urlsFile, linkOut,
			linkOut, target, urlsFile,
		)

	// ── secretfinder ─────────────────────────────────────────────────────────
	case "secretfinder":
		// secretfinder regex-scans JS for secrets — complements 48-pattern scan.
		// Uses different regex set: focuses on API keys, tokens, credentials.
		secretOut := filepath.Join(outDir, scanID8+"_secretfinder.txt")
		return fmt.Sprintf(
			`cat %s 2>/dev/null | grep '\.js' | grep '^http' | head -20`+"\n"+
				`| while read jsurl; do`+"\n"+
				`  python3 /opt/SecretFinder/SecretFinder.py -i "$jsurl" -o cli 2>/dev/null`+"\n"+
				`done | tee %s`+"\n"+
				`# Notify on secrets found`+"\n"+
				`[[ -s %s ]] && printf "SECRETS in JS on %s\n$(head -5 %s)" | notify -silent 2>/dev/null || true`,
			urlsFile, secretOut,
			secretOut, target, secretOut,
		)

	// ── paramspider ──────────────────────────────────────────────────────────
	case "paramspider":
		// paramspider discovers parameters from web archives.
		// OPT-CHAIN11: paramspider URLs → gf patterns → dalfox XSS direct
		// Mai eficient decât a trece prin urlsFile general — direct pe params suspecti
		paramOut   := filepath.Join(outDir, scanID8+"_paramspider.txt")
		paramXSS   := filepath.Join(outDir, scanID8+"_param_xss.txt")
		paramSQLi  := filepath.Join(outDir, scanID8+"_param_sqli.txt")
		return fmt.Sprintf(
			`paramspider -d %s --quiet 2>/dev/null`+
				` | grep '^http' | anew %s`+"\n"+
				`paramspider -d %s --subs --quiet 2>/dev/null`+
				` | grep '^http' | anew %s`+"\n"+
				`# OPT-CHAIN11: paramspider URLs → gf → dalfox + sqlmap direct`+"\n"+
				`cat %s 2>/dev/null | gf xss 2>/dev/null | anew %s`+"\n"+
				`cat %s 2>/dev/null | gf sqli 2>/dev/null | anew %s`+"\n"+
				`# dalfox pe XSS candidates`+"\n"+
				`[[ -s %s ]] && cat %s | head -15`+
				` | dalfox pipe --silence --skip-bav --timeout 10 2>/dev/null || true`+"\n"+
				`# sqlmap pe SQLi candidates`+"\n"+
				`[[ -s %s ]] && SQLI_URL=$(head -1 %s) &&`+
				` sqlmap -u "$SQLI_URL" --batch --level=1 --risk=1 --timeout=20`+
				` --output-dir=%s 2>/dev/null || true`,
			target, paramOut,
			target, urlsFile,
			paramOut, paramXSS,
			paramOut, paramSQLi,
			paramXSS, paramXSS,
			paramSQLi, paramSQLi,
			filepath.Join(outDir, scanID8+"_param_sqlmap"),
		)

	// ── freq ─────────────────────────────────────────────────────────────────
	case "freq":
		// freq analyzes URL path frequency to find interesting endpoints.
		// High-frequency paths = likely important, low-freq = potentially hidden.
		freqOut := filepath.Join(outDir, scanID8+"_freq.txt")
		return fmt.Sprintf(
			`cat %s 2>/dev/null | grep '^http'`+
				` | grep -oP '(?<=/)([^?#/]+)'`+
				` | sort | uniq -c | sort -rn`+
				` | head -50 | tee %s`,
			urlsFile, freqOut,
		)

	// ── swaggerspy ───────────────────────────────────────────────────────────
	case "swaggerspy":
		// swaggerspy discovers exposed Swagger/OpenAPI docs.
		// OPT-API2: spec found → feed to astra (injection test) + apifuzzer (fuzzing)
		//           + kiterunner (route bruteforce from spec context)
		swaggerOut := filepath.Join(outDir, scanID8+"_swagger.txt")
		astraOut   := filepath.Join(outDir, scanID8+"_astra.json")
		fuzzOut    := filepath.Join(outDir, scanID8+"_apifuzzer")
		return fmt.Sprintf(
			`swaggerspy --url https://%s 2>/dev/null | tee %s`+"\n"+
				`for path in /swagger.json /api-docs /openapi.json /v2/api-docs /swagger-ui.html /api/swagger.json /api/openapi.json; do`+"\n"+
				`  CODE=$(curl -sf --max-time 5 -o /dev/null -w '%%{http_code}' "https://%s$path" 2>/dev/null)`+"\n"+
				`  [[ "$CODE" == "200" ]] && echo "SWAGGER: https://%s$path" | tee -a %s`+"\n"+
				`done`+"\n"+
				`# OPT-API2: chain spec → astra → apifuzzer → kiterunner`+"\n"+
				`SPEC_URL=$(grep -oP 'https?://[^\s]+\.(json|yaml)' %s 2>/dev/null | head -1)`+"\n"+
				`if [[ -n "$SPEC_URL" ]]; then`+"\n"+
				`  # Astra: REST API injection testing on spec`+"\n"+
				`  command -v astra &>/dev/null && astra -t "$SPEC_URL" -o %s 2>/dev/null || true`+"\n"+
				`  # APIFuzzer: fuzz parameters from spec`+"\n"+
				`  command -v APIFuzzer &>/dev/null && APIFuzzer -s "$SPEC_URL" --report_dir %s -l WARNING 2>/dev/null || true`+"\n"+
				`  # kiterunner: bruteforce API routes from same host`+"\n"+
				`  SPEC_HOST=$(echo "$SPEC_URL" | grep -oP 'https?://[^/]+')`+"\n"+
				`  command -v kr &>/dev/null && echo "$SPEC_HOST" | kr scan -`+
				`  -A=apiroutes-210328:20000 -x 5 -j 10`+
				`  --fail-status-codes 400,401,404,403,501,502`+
				`  --timeout 30s 2>/dev/null`+
				`  | grep -oP 'https?://[^\s]+' | anew %s || true`+"\n"+
				`fi`,
			target, swaggerOut,
			target, target, swaggerOut,
			swaggerOut,
			astraOut,
			fuzzOut,
			urlsFile,
		)

	// ── leaksearch ───────────────────────────────────────────────────────────
	case "leaksearch":
		// leaksearch finds leaked credentials in paste sites and breach data.
		// Useful for identifying compromised accounts on target domain.
		leakOut := filepath.Join(outDir, scanID8+"_leaksearch.txt")
		return fmt.Sprintf(
			`leaksearch -q %s 2>/dev/null | tee %s || true`,
			target, leakOut,
		)

	// ── porch-pirate ─────────────────────────────────────────────────────────
	case "porch-pirate":
		// porch-pirate searches Postman workspaces for leaked API keys/tokens.
		// OPT-CHAIN12: Postman collections conțin endpoint-uri reale → kiterunner
		pirateOut  := filepath.Join(outDir, scanID8+"_postman.txt")
		pirateURLs := filepath.Join(outDir, scanID8+"_postman_urls.txt")
		return fmt.Sprintf(
			`porch-pirate -s %s 2>/dev/null | tee %s`+"\n"+
				`# Notify pe secrete găsite`+"\n"+
				`POSTMAN_SECRETS=$(grep -iE 'key|token|secret|password|api' %s 2>/dev/null | head -5)`+"\n"+
				`[[ -n "$POSTMAN_SECRETS" ]] &&`+
				` printf "POSTMAN LEAK on %s:\n$POSTMAN_SECRETS" | notify -silent 2>/dev/null || true`+"\n"+
				`# OPT-CHAIN12: extrage URL-uri din Postman collections → kiterunner`+"\n"+
				`grep -oP 'https?://[^\s"]+' %s 2>/dev/null`+
				` | grep -v 'postman\|swagger\|docs' | sort -u | tee %s`+"\n"+
				`if [[ -s %s ]] && command -v kr &>/dev/null; then`+"\n"+
				`  # Hosturi din Postman → kiterunner (endpoint-uri reale din documentație internă)`+"\n"+
				`  cat %s | grep -oP 'https?://[^/]+' | sort -u | head -5`+
				`  | kr scan - -A=apiroutes-210328:20000 -x 5 -j 10`+
				`  --fail-status-codes 400,401,404,403,501,502`+
				`  --timeout 30s 2>/dev/null`+
				`  | grep -oP 'https?://[^\s]+' | anew %s || true`+"\n"+
				`  # Feed Postman URLs direct în nuclei API scan`+"\n"+
				`  cat %s | head -10 | nuclei`+
				`  -t exposures/ -t vulnerabilities/generic/`+
				`  -severity medium,high,critical -silent 2>/dev/null || true`+"\n"+
				`fi`,
			target, pirateOut,
			pirateOut, target,
			pirateOut, pirateURLs,
			pirateURLs,
			pirateURLs, urlsFile,
			pirateURLs,
		)

	// ── metagoofil ───────────────────────────────────────────────────────────
	case "metagoofil":
		// metagoofil extrage metadata din documente publice.
		// OPT-CHAIN10: usernames extrase → hydra brute force pe SSH/FTP descoperite
		metagoofOut  := filepath.Join(outDir, scanID8+"_metagoofil")
		usernameList := filepath.Join(outDir, scanID8+"_usernames.txt")
		return fmt.Sprintf(
			`metagoofil -d %s -t pdf,doc,docx,xls,xlsx,ppt,pptx`+
				` -l 20 -o %s 2>/dev/null || true`+"\n"+
				`# OPT-CHAIN10: extrage usernames din metadata → hydra brute force`+"\n"+
				`find %s -name "*.txt" 2>/dev/null | xargs grep -hiE '^Author:|Creator:|Last.*Author' 2>/dev/null`+
				` | grep -oP '[\w\.\-]+@[\w\.\-]+|(?<=: )[\w\.\-]+' | sort -u | tee %s`+"\n"+
				`if [[ -s %s ]]; then`+"\n"+
				`  # SSH hosts din naabu`+"\n"+
				`  SSH_HOSTS=$(cat %s 2>/dev/null | jq -r 'select(.port==22) | .ip' 2>/dev/null | head -3)`+"\n"+
				`  if [[ -n "$SSH_HOSTS" ]] && command -v hydra &>/dev/null; then`+"\n"+
				`    echo "$SSH_HOSTS" | while read h; do`+"\n"+
				`      hydra -L %s -P /opt/wordlists/passwords-top50.txt`+
				`      -t 4 -f -q ssh://$h 2>/dev/null | tee -a %s || true`+"\n"+
				`    done`+"\n"+
				`  fi`+"\n"+
				`fi`,
			target, metagoofOut,
			metagoofOut, usernameList,
			usernameList,
			filepath.Join(outDir, scanID8+"_naabu.json"),
			usernameList,
			filepath.Join(outDir, scanID8+"_hydra_meta.txt"),
		)

	// ── emailfinder ──────────────────────────────────────────────────────────
	case "emailfinder":
		// emailfinder discovers email addresses for the target domain.
		// Useful for identifying admin contacts and potential targets for reset flows.
		emailOut := filepath.Join(outDir, scanID8+"_emails.txt")
		return fmt.Sprintf(
			`emailfinder -d %s 2>/dev/null | tee %s || true`,
			target, emailOut,
		)

	// ── mantra ───────────────────────────────────────────────────────────────
	case "mantra":
		// mantra finds secrets in HTTP responses (not just JS files).
		// Checks response bodies of all live endpoints for exposed credentials.
		mantraOut := filepath.Join(outDir, scanID8+"_mantra.txt")
		return fmt.Sprintf(
			`cat %s 2>/dev/null | head -20`+
				` | mantra 2>/dev/null | tee %s || true`,
			liveFile, mantraOut,
		)

	// ── chaos-client ─────────────────────────────────────────────────────────
	case "chaos-client":
		// chaos-client fetches subdomains from ProjectDiscovery Chaos dataset.
		// Requires PDCP_API_KEY env var — skips gracefully if not set.
		chaosOut := filepath.Join(outDir, scanID8+"_chaos.txt")
		return fmt.Sprintf(
			`if [[ -z "${PDCP_API_KEY}" ]]; then`+"\n"+
				`  echo "[chaos] PDCP_API_KEY not set — skipping" | tee %s`+"\n"+
				`else`+"\n"+
				`  chaos -d %s -silent 2>/dev/null | anew %s | anew %s`+"\n"+
				`fi`,
			chaosOut, target, chaosOut, subsFile,
		)

	// ── msftrecon ────────────────────────────────────────────────────────────
	case "msftrecon":
		// msftrecon enumerates Microsoft 365 / Azure AD tenant info.
		// Useful only for targets using M365 — skips gracefully otherwise.
		msftOut := filepath.Join(outDir, scanID8+"_msftrecon.txt")
		return fmt.Sprintf(
			`msftrecon -d %s 2>/dev/null | tee %s || true`,
			target, msftOut,
		)

	// ── MINOR FIX: gowitness ────────────────────────────────────────────────
	case "gowitness":
		// gowitness screenshots live hosts — uses liveFile (validated by httpx).
		// Similar to aquatone but more reliable on headless servers.
		gowitOut := filepath.Join(outDir, scanID8+"_gowitness")
		return fmt.Sprintf(
			`gowitness file -f %s`+
				` --screenshot-path %s`+
				` --timeout 10`+
				` --threads 5 2>/dev/null || true`,
			liveFile, gowitOut,
		)

	// ── MINOR FIX: ppmap ────────────────────────────────────────────────────
	case "ppmap":
		// ppmap tests prototype pollution — uses discovered URLs with params.
		// Targets JS-heavy apps where prototype pollution is common.
		ppmapOut := filepath.Join(outDir, scanID8+"_ppmap.txt")
		return fmt.Sprintf(
			`cat %s 2>/dev/null | grep -E '\.js|\?' | head -20`+
				` | ppmap 2>/dev/null | tee %s`,
			urlsFile, ppmapOut,
		)

	// ── CRITICAL FIX 1: sqlmap ───────────────────────────────────────────────
	case "sqlmap":
		// Receives exact SQLi URL from nuclei/gf — not generic target.
		// Uses gf sqli output as primary source, falls back to target.
		sqliFile := filepath.Join(outDir, scanID8+"_gf_sqli.txt")
		sqlmapDir := filepath.Join(outDir, scanID8+"_sqlmap")
		return fmt.Sprintf(
			`URL=$(cat %s 2>/dev/null | head -1)`+"\n"+
				`[[ -z "$URL" ]] && URL="https://%s/"`+"\n"+
				`sqlmap -u "$URL"`+
				` --batch --random-agent --level=2 --risk=2`+
				` --dbs --timeout=30 --threads=4`+
				` --output-dir=%s 2>/dev/null`+
				` | tee %s`,
			sqliFile, target,
			sqlmapDir,
			filepath.Join(outDir, scanID8+"_sqlmap.txt"),
		)

	// ── CRITICAL FIX 2: ghauri ──────────────────────────────────────────────
	case "ghauri":
		// ghauri is faster than sqlmap for initial confirmation.
		// Runs on gf sqli URLs — same source as sqlmap-targeted.
		sqliFile := filepath.Join(outDir, scanID8+"_gf_sqli.txt")
		return fmt.Sprintf(
			`URL=$(cat %s 2>/dev/null | head -1)`+"\n"+
				`[[ -z "$URL" ]] && URL="https://%s/"`+"\n"+
				`ghauri -u "$URL"`+
				` --batch --dbs --level=2`+
				` --output-dir=%s 2>/dev/null`+
				` | tee %s`,
			sqliFile, target,
			filepath.Join(outDir, scanID8+"_ghauri"),
			filepath.Join(outDir, scanID8+"_ghauri.txt"),
		)

	// ── CRITICAL FIX 3: feroxbuster ─────────────────────────────────────────
	case "feroxbuster":
		// feroxbuster runs on ALL live hosts with custom wordlist.
		// OPT-CHAIN9: feroxbuster /api* paths → astra injection test pe endpoint-uri reale
		customWL := filepath.Join(outDir, scanID8+"_custom_wordlist.txt")
		feroxOut := filepath.Join(outDir, scanID8+"_feroxbuster.json")
		return fmt.Sprintf(
			`WL=%s`+"\n"+
				`[[ ! -s "$WL" ]] && WL="/opt/wordlists/raft-medium-directories.txt" 2>/dev/null || true`+"\n"+
				`[[ ! -s "$WL" ]] && WL="/usr/share/seclists/Discovery/Web-Content/raft-medium-directories.txt"`+"\n"+
				`[[ ! -s "$WL" ]] && WL="/usr/share/wordlists/dirb/common.txt"`+"\n"+
				`cat %s | head -10 | while read url; do`+"\n"+
				`  feroxbuster --url "$url" --wordlist "$WL"`+
				`  --threads 50 --timeout 10 --silent`+
				`  --status-codes 200,201,301,302,403,401`+
				`  --output %s 2>/dev/null`+"\n"+
				`done`+"\n"+
				`# OPT-CHAIN9: feroxbuster /api* paths → astra REST injection + nuclei`+"\n"+
				`API_PATHS=$(cat %s 2>/dev/null`+
				` | jq -r 'select(.status==200) | .url' 2>/dev/null`+
				` | grep -iE '/api|/v[0-9]|/rest|/admin' | head -10)`+"\n"+
				`if [[ -n "$API_PATHS" ]]; then`+"\n"+
				`  # Feed API paths into URL pool for gf + nuclei`+"\n"+
				`  echo "$API_PATHS" | anew %s`+"\n"+
				`  # astra: injection test pe API paths cu 200 status`+"\n"+
				`  if command -v astra &>/dev/null; then`+"\n"+
				`    echo "$API_PATHS" | head -3 | while read api_path; do`+"\n"+
				`      astra -t "$api_path" 2>/dev/null | tee -a %s || true`+"\n"+
				`    done`+"\n"+
				`  fi`+"\n"+
				`  # nuclei: exposure + misconfiguration pe paths noi`+"\n"+
				`  echo "$API_PATHS" | nuclei`+
				`  -t exposures/ -t misconfiguration/`+
				`  -severity medium,high,critical -silent 2>/dev/null`+
				`  | tee -a %s || true`+"\n"+
				`fi`,
			customWL, liveFile, feroxOut,
			feroxOut,
			urlsFile,
			filepath.Join(outDir, scanID8+"_ferox_astra.txt"),
			filepath.Join(outDir, scanID8+"_ferox_nuclei.txt"),
		)

	// ── CRITICAL FIX 4: katana ──────────────────────────────────────────────
	case "katana":
		// katana crawls live hosts with JS parsing enabled.
		// OPT-API1: katana discovered paths → kiterunner (API routes from real endpoints)
		// Output feeds into gf, dalfox, trufflehog-js, kiterunner.
		katanaOut := filepath.Join(outDir, scanID8+"_katana.txt")
		return fmt.Sprintf(
			`cat %s | katana`+
				` -jc -jsl -d 3`+
				` -ef woff,css,png,svg,jpg,woff2,jpeg,gif,svg`+
				` -silent -rate-limit 150`+
				` -timeout 10`+
				` -o %s 2>/dev/null`+
				` && cat %s | anew %s`+"\n"+
				`# OPT-API1: extract unique API base URLs from katana → kiterunner route discovery`+"\n"+
				`cat %s 2>/dev/null | grep -oP 'https?://[^/]+' | sort -u > %s`+"\n"+
				`if command -v kr &>/dev/null && [[ -s %s ]]; then`+"\n"+
				`  kr scan %s -A=apiroutes-210328:10000 -x 3 -j 10`+
				`  --fail-status-codes 400,401,404,403,501,502,426,411`+
				`  --timeout 30s 2>/dev/null`+
				`  | grep -oP 'https?://[^\s]+' | anew %s`+"\n"+
				`fi`,
			liveFile, katanaOut,
			katanaOut, urlsFile,
			katanaOut,
			filepath.Join(outDir, scanID8+"_api_hosts.txt"),
			filepath.Join(outDir, scanID8+"_api_hosts.txt"),
			filepath.Join(outDir, scanID8+"_api_hosts.txt"),
			urlsFile,
		)

	// ── CRITICAL FIX 5: waybackurls ─────────────────────────────────────────
	case "waybackurls":
		// waybackurls + gau combined, deduplicated with anew.
		// Output feeds urlsFile for gf, dalfox, ffuf-custom.
		return fmt.Sprintf(
			`echo %s | waybackurls 2>/dev/null | anew %s`+"\n"+
				`gau %s --subs --blacklist ttf,woff,svg,png,jpg,gif,css 2>/dev/null`+
				` | anew %s`,
			target, urlsFile,
			target, urlsFile,
		)

	// ── CRITICAL FIX 6: dnsx ────────────────────────────────────────────────
	case "dnsx":
		// dnsx resolves subdomains + detects CNAME chains.
		// OPT-CHAIN8: CNAME records → subzy takeover check imediat
		dnxOut   := filepath.Join(outDir, scanID8+"_dnsx.json")
		cnameOut := filepath.Join(outDir, scanID8+"_cnames.txt")
		return fmt.Sprintf(
			`cat %s | dnsx`+
				` -silent -resp -a -cname -mx -ns`+
				` -rate-limit 500`+
				` -json -o %s 2>/dev/null`+"\n"+
				`# OPT-CHAIN8: extrage CNAME-uri → subzy takeover scan imediat`+"\n"+
				`cat %s 2>/dev/null`+
				` | jq -r 'select(.cname != null) | .host' 2>/dev/null`+
				` | tee %s`+"\n"+
				`if [[ -s %s ]] && command -v subzy &>/dev/null; then`+"\n"+
				`  subzy run --targets %s --hide-fails --verify 2>/dev/null`+
				`  | tee -a %s`+"\n"+
				`  TAKEOVER=$(grep -i "VULNERABLE" %s 2>/dev/null | head -3)`+"\n"+
				`  [[ -n "$TAKEOVER" ]] &&`+
				`  printf "CNAME TAKEOVER on %s:\n$TAKEOVER" | notify -silent 2>/dev/null || true`+"\n"+
				`fi`,
			subsFile, dnxOut,
			dnxOut, cnameOut,
			cnameOut, cnameOut,
			filepath.Join(outDir, scanID8+"_takeover.txt"),
			filepath.Join(outDir, scanID8+"_takeover.txt"),
			target,
		)

	// ── CRITICAL FIX 7: wpscan ──────────────────────────────────────────────
	case "wpscan":
		// wpscan runs only when WordPress is detected by httpx/whatweb.
		// Uses aggressive mode for plugin/theme vulnerability detection.
		wpscanOut := filepath.Join(outDir, scanID8+"_wpscan.json")
		return fmt.Sprintf(
			`# Find WordPress hosts from httpx tech detection`+"\n"+
				`WP_HOSTS=$(cat %s 2>/dev/null`+
				` | jq -r 'select(.tech[]? | ascii_downcase | test("wordpress")) | .url'`+
				` 2>/dev/null | head -5)`+"\n"+
				`[[ -z "$WP_HOSTS" ]] && WP_HOSTS="https://%s"`+"\n"+
				`echo "$WP_HOSTS" | while read wp_url; do`+"\n"+
				`  wpscan --url "$wp_url"`+
				`  --enumerate vp,vt,u1-5,dbe`+
				`  --plugins-detection aggressive`+
				`  --format json --output %s`+
				`  --no-banner 2>/dev/null`+"\n"+
				`done`,
			liveJSON, target, wpscanOut,
		)

	// ── CRITICAL FIX 8: hydra ───────────────────────────────────────────────
	case "hydra":
		// hydra targets services discovered by naabu/nmap.
		// Uses detected service type: SSH/FTP/HTTP based on port.
		hydraOut := filepath.Join(outDir, scanID8+"_hydra.txt")
		return fmt.Sprintf(
			`# Detect open services from naabu output`+"\n"+
				`SSH_HOSTS=$(cat %s 2>/dev/null | jq -r 'select(.port==22) | .ip' 2>/dev/null | head -3)`+"\n"+
				`FTP_HOSTS=$(cat %s 2>/dev/null | jq -r 'select(.port==21) | .ip' 2>/dev/null | head -3)`+"\n"+
				`# SSH brute force`+"\n"+
				`if [[ -n "$SSH_HOSTS" ]]; then`+"\n"+
				`  echo "$SSH_HOSTS" | while read h; do`+"\n"+
				`    hydra -L /opt/wordlists/users.txt -P /opt/wordlists/passwords-top50.txt`+
				`    -t 4 -f -q ssh://$h 2>/dev/null | tee -a %s`+"\n"+
				`  done`+"\n"+
				`fi`+"\n"+
				`# FTP brute force`+"\n"+
				`if [[ -n "$FTP_HOSTS" ]]; then`+"\n"+
				`  echo "$FTP_HOSTS" | while read h; do`+"\n"+
				`    hydra -L /opt/wordlists/users.txt -P /opt/wordlists/passwords-top50.txt`+
				`    -t 4 -f -q ftp://$h 2>/dev/null | tee -a %s`+"\n"+
				`  done`+"\n"+
				`fi`,
			filepath.Join(outDir, scanID8+"_naabu.json"),
			filepath.Join(outDir, scanID8+"_naabu.json"),
			hydraOut, hydraOut,
		)

	// ── CRITICAL FIX 9: tplmap ──────────────────────────────────────────────
	case "tplmap":
		// tplmap tests SSTI — receives gf ssrf/redirect URLs (template param candidates).
		// SSTI often appears in same parameters as SSRF/open redirect.
		tplmapOut := filepath.Join(outDir, scanID8+"_tplmap.txt")
		ssrfFile  := filepath.Join(outDir, scanID8+"_gf_ssrf.txt")
		return fmt.Sprintf(
			`# Use gf ssrf URLs as SSTI candidates (template params overlap with SSRF)`+"\n"+
				`SSTI_URL=$(cat %s 2>/dev/null | head -3)`+"\n"+
				`[[ -z "$SSTI_URL" ]] && SSTI_URL=$(cat %s 2>/dev/null | head -3)`+"\n"+
				`[[ -z "$SSTI_URL" ]] && SSTI_URL="https://%s/"`+"\n"+
				`echo "$SSTI_URL" | while read u; do`+"\n"+
				`  python3 /opt/tplmap/tplmap.py -u "$u"`+
				`  --level 5 --technique RSET 2>/dev/null | tee -a %s`+"\n"+
				`done`,
			ssrfFile, urlsFile, target, tplmapOut,
		)

	// ── CRITICAL FIX 10: xsstrike ────────────────────────────────────────────
	case "xsstrike":
		// xsstrike deep-tests XSS — receives gf xss URLs (not all URLs).
		// More thorough than dalfox for DOM-based and blind XSS.
		xssFile   := filepath.Join(outDir, scanID8+"_gf_xss.txt")
		xsstrikeOut := filepath.Join(outDir, scanID8+"_xsstrike.txt")
		return fmt.Sprintf(
			`cat %s 2>/dev/null | head -10 | while read u; do`+"\n"+
				`  python3 /opt/XSStrike/xsstrike.py`+
				`  --url "$u" --blind`+
				`  --timeout 10 --skip-dom 2>/dev/null | tee -a %s`+"\n"+
				`done`,
			xssFile, xsstrikeOut,
		)

	// ── CRITICAL FIX 11: graphql-cop ─────────────────────────────────────────
	case "graphql-cop":
		// graphql-cop audits GraphQL security — receives endpoints from graphw00f.
		// Tests: introspection, batching, field suggestions, DoS vectors.
		gqlCopOut := filepath.Join(outDir, scanID8+"_graphql_cop.json")
		graphw00fOut := filepath.Join(outDir, scanID8+"_graphw00f.txt")
		return fmt.Sprintf(
			`# Extract confirmed GraphQL endpoints from graphw00f output`+"\n"+
				`GQL_URL=$(grep -oP 'https?://[^\s]+' %s 2>/dev/null | head -3)`+"\n"+
				`[[ -z "$GQL_URL" ]] && GQL_URL="https://%s/graphql"`+"\n"+
				`echo "$GQL_URL" | while read gurl; do`+"\n"+
				`  graphql-cop --target "$gurl" --output json 2>/dev/null | tee -a %s`+"\n"+
				`done`,
			graphw00fOut, target, gqlCopOut,
		)

	// ── CRITICAL FIX 12: zap ────────────────────────────────────────────────
	case "zap":
		// ZAP active scan on live hosts — daemon mode for CI/automation.
		// Uses API mode for automation-friendly output.
		zapOut := filepath.Join(outDir, scanID8+"_zap.json")
		return fmt.Sprintf(
			`ZAP_URL=$(cat %s | head -1)`+"\n"+
				`[[ -z "$ZAP_URL" ]] && ZAP_URL="https://%s"`+"\n"+
				`if command -v zap.sh &>/dev/null || command -v zaproxy &>/dev/null; then`+"\n"+
				`  ZAP_BIN=$(command -v zap.sh 2>/dev/null || command -v zaproxy)`+"\n"+
				`  "$ZAP_BIN" -cmd -quickurl "$ZAP_URL"`+
				`  -quickout %s -quickprogress 2>/dev/null || true`+"\n"+
				`else`+"\n"+
				`  echo "[zap] not installed — skipping" | tee %s`+"\n"+
				`fi`,
			liveFile, target, zapOut, zapOut,
		)

	// ── CRITICAL FIX 13: reconftw ────────────────────────────────────────────
	case "reconftw":
		// reconftw is a full recon orchestrator — use its own pipeline.
		// -d flag required, -o for output, --quiet for automation.
		// Only runs in reconftw-deep profile (Timeout: 7200).
		reconOut := filepath.Join(outDir, scanID8+"_reconftw")
		return fmt.Sprintf(
			`if command -v reconftw &>/dev/null || [[ -f /opt/reconftw/reconftw.sh ]]; then`+"\n"+
				`  RECON_BIN=$(command -v reconftw 2>/dev/null || echo "/opt/reconftw/reconftw.sh")`+"\n"+
				`  "$RECON_BIN" -d %s -o %s --quiet 2>/dev/null || true`+"\n"+
				`  # Feed reconftw discovered URLs back into pipeline`+"\n"+
				`  find %s -name "*.txt" -exec cat {} \; 2>/dev/null`+
				`  | grep '^http' | anew %s`+"\n"+
				`else`+"\n"+
				`  echo "[reconftw] not installed" | tee %s/reconftw_skip.txt`+"\n"+
				`fi`,
			target, reconOut, reconOut, urlsFile, reconOut,
		)

	// ── CRITICAL FIX 14: openredirex ─────────────────────────────────────────
	case "openredirex":
		// openredirex tests open redirects — receives gf redirect URLs.
		// Not all URLs — only those with redirect-candidate parameters.
		redirFile  := filepath.Join(outDir, scanID8+"_gf_redirect.txt")
		redirOut   := filepath.Join(outDir, scanID8+"_openredirex.txt")
		return fmt.Sprintf(
			`if [[ -f %s ]] && [[ -s %s ]]; then`+"\n"+
				`  cat %s | openredirex 2>/dev/null | tee %s`+"\n"+
				`else`+"\n"+
				`  # Fallback: extract redirect params from all URLs`+"\n"+
				`  cat %s | grep -E '(redirect|return|url|next|to)=' 2>/dev/null`+
				`  | head -20 | openredirex 2>/dev/null | tee %s`+"\n"+
				`fi`,
			redirFile, redirFile,
			redirFile, redirOut,
			urlsFile, redirOut,
		)

	// ── API-TOOL-1: kiterunner ────────────────────────────────────────────────
	// OPT-CHAIN3: kiterunner routes → nuclei + dalfox + sqlmap
	// Rute API descoperite sunt cele mai valoroase suprafețe de atac
	case "kiterunner":
		krOut     := filepath.Join(outDir, scanID8+"_kiterunner.txt")
		krNuclei  := filepath.Join(outDir, scanID8+"_kr_nuclei.json")
		return fmt.Sprintf(
			`if command -v kr &>/dev/null; then`+"\n"+
				`  cat %s | head -20 | kr scan -`+
				`  -A=apiroutes-210328:20000`+
				`  -x 5 -j 20`+
				`  --fail-status-codes 400,401,404,403,501,502,426,411`+
				`  --timeout 30s`+
				`  -o text`+
				`  2>/dev/null | tee %s`+"\n"+
				`  # Feed discovered API paths back into URL pool`+"\n"+
				`  grep -oP 'https?://[^\s]+' %s 2>/dev/null | anew %s`+"\n"+
				`  # OPT-CHAIN3a: kiterunner routes → nuclei api + exposure templates`+"\n"+
				`  KR_URLS=$(grep -oP 'https?://[^\s]+' %s 2>/dev/null | head -20)`+"\n"+
				`  if [[ -n "$KR_URLS" ]]; then`+"\n"+
				`    echo "$KR_URLS" | nuclei`+
				`    -t exposures/ -t vulnerabilities/generic/`+
				`    -severity medium,high,critical`+
				`    -silent -json -o %s 2>/dev/null || true`+"\n"+
				`    # OPT-CHAIN3b: kiterunner routes cu params → dalfox XSS scan`+"\n"+
				`    echo "$KR_URLS" | grep '?' | head -10`+
				`    | dalfox pipe --silence --skip-bav --timeout 10 2>/dev/null || true`+"\n"+
				`    # OPT-CHAIN3c: kiterunner routes cu id/search/query params → sqlmap`+"\n"+
				`    SQLI_TARGETS=$(echo "$KR_URLS" | grep -E 'id=|query=|search=|q=' | head -3)`+"\n"+
				`    [[ -n "$SQLI_TARGETS" ]] && echo "$SQLI_TARGETS" | while read u; do`+"\n"+
				`      sqlmap -u "$u" --batch --level=1 --risk=1 --timeout=20 --threads=3`+
				`      --dbs --output-dir=%s 2>/dev/null || true`+"\n"+
				`    done`+"\n"+
				`  fi`+"\n"+
				`else`+"\n"+
				`  echo "[kiterunner] not installed — go install github.com/assetnote/kiterunner/cmd/kr@latest"`+"\n"+
				`fi`,
			liveFile, krOut,
			krOut, urlsFile,
			krOut,
			krNuclei,
			filepath.Join(outDir, scanID8+"_kr_sqlmap"),
		)

	// ── API-TOOL-2: vulnapi ────────────────────────────────────────────────────
	// OPT-CHAIN4: vulnapi OWASP finding → notify Telegram instant
	case "vulnapi":
		vulnapiOut := filepath.Join(outDir, scanID8+"_vulnapi.json")
		return fmt.Sprintf(
			`if command -v vulnapi &>/dev/null; then`+"\n"+
				`  cat %s | grep -E '/api|/v[0-9]|/graphql|/rest' | head -10 | while read url; do`+"\n"+
				`    vulnapi scan curl "$url"`+
				`    --output %s 2>/dev/null || true`+"\n"+
				`  done`+"\n"+
				`  [[ ! -s %s ]] && vulnapi scan curl https://%s/api --output %s 2>/dev/null || true`+"\n"+
				`  # OPT-CHAIN4: OWASP API finding → notify instant`+"\n"+
				`  OWASP_HITS=$(cat %s 2>/dev/null | jq -r '.issues[]? | "[" + .severity + "] " + .id + ": " + .name' 2>/dev/null | grep -i "high\|critical" | head -5)`+"\n"+
				`  if [[ -n "$OWASP_HITS" ]]; then`+"\n"+
				`    printf "OWASP API VULN on %s:\n$OWASP_HITS" | notify -silent 2>/dev/null || true`+"\n"+
				`    echo "[vulnapi→notify] Alert sent: $OWASP_HITS"`+"\n"+
				`  fi`+"\n"+
				`else`+"\n"+
				`  echo "[vulnapi] not installed — go install github.com/cerberauth/vulnapi@latest"`+"\n"+
				`fi`,
			liveFile, vulnapiOut,
			vulnapiOut, target, vulnapiOut,
			vulnapiOut,
			target,
		)

	// ── API-TOOL-3: Astra ─────────────────────────────────────────────────────
	// OPT-CHAIN5: astra confirmed SQLi → sqlmap targeted on exact endpoint
	case "astra":
		astraOut := filepath.Join(outDir, scanID8+"_astra.json")
		swaggerSpec := filepath.Join(outDir, scanID8+"_swagger.txt")
		return fmt.Sprintf(
			`if command -v astra &>/dev/null || [[ -f /opt/astra/app.py ]]; then`+"\n"+
				`  ASTRA_BIN=$(command -v astra 2>/dev/null || echo "python3 /opt/astra/app.py")`+"\n"+
				`  if [[ -s %s ]]; then`+"\n"+
				`    SPEC_URL=$(grep -oP 'https?://[^\s]+\.(json|yaml)' %s | head -1)`+"\n"+
				`    [[ -n "$SPEC_URL" ]] && "$ASTRA_BIN" -t "$SPEC_URL" -o %s 2>/dev/null || true`+"\n"+
				`  else`+"\n"+
				`    "$ASTRA_BIN" -t https://%s -o %s 2>/dev/null || true`+"\n"+
				`  fi`+"\n"+
				`  # OPT-CHAIN5: astra confirms SQLi → sqlmap exact endpoint`+"\n"+
				`  SQLI_URL=$(cat %s 2>/dev/null | jq -r '.vulnerabilities[]? | select(.type | test("sql|injection";"i")) | .url' 2>/dev/null | head -3)`+"\n"+
				`  if [[ -n "$SQLI_URL" ]]; then`+"\n"+
				`    echo "[astra→sqlmap] SQLi confirmed at $SQLI_URL — running sqlmap"`+"\n"+
				`    echo "$SQLI_URL" | while read sqli_url; do`+"\n"+
				`      sqlmap -u "$sqli_url" --batch --level=2 --risk=2`+
				`      --dbs --timeout=30 --threads=4`+
				`      --output-dir=%s 2>/dev/null | tee -a %s || true`+"\n"+
				`    done`+"\n"+
				`    # Notify on confirmed SQLi`+"\n"+
				`    printf "SQLi CONFIRMED by Astra on %s:\n$SQLI_URL" | notify -silent 2>/dev/null || true`+"\n"+
				`  fi`+"\n"+
				`else`+"\n"+
				`  echo "[astra] not installed — pip3 install astra --break-system-packages"`+"\n"+
				`fi`,
			swaggerSpec, swaggerSpec, astraOut,
			target, astraOut,
			astraOut,
			filepath.Join(outDir, scanID8+"_astra_sqlmap"),
			filepath.Join(outDir, scanID8+"_astra_sqlmap.txt"),
			target,
		)

	// ── API-TOOL-4: APIFuzzer ─────────────────────────────────────────────────
	// HTTP API fuzzer — generates malicious payloads from OpenAPI/Swagger specs.
	// Finds injection, boundary value, and logic errors in API parameters.
	case "apifuzzer":
		apiFuzzOut := filepath.Join(outDir, scanID8+"_apifuzzer.json")
		return fmt.Sprintf(
			`if command -v APIFuzzer &>/dev/null || command -v apifuzzer &>/dev/null; then`+"\n"+
				`  FUZZ_BIN=$(command -v APIFuzzer 2>/dev/null || command -v apifuzzer)`+"\n"+
				`  # Find OpenAPI spec from swaggerspy output or common paths`+"\n"+
				`  SPEC_URL=$(curl -sf --max-time 5 "https://%s/openapi.json" -o /dev/null -w "%%{http_code}" 2>/dev/null)`+"\n"+
				`  if [[ "$SPEC_URL" == "200" ]]; then`+"\n"+
				`    "$FUZZ_BIN" -s "https://%s/openapi.json"`+
				`    --report_dir %s`+
				`    -l WARNING 2>/dev/null | tee %s`+"\n"+
				`  else`+"\n"+
				`    echo "[apifuzzer] No OpenAPI spec found at /openapi.json — trying /swagger.json"`+"\n"+
				`    "$FUZZ_BIN" -s "https://%s/swagger.json"`+
				`    --report_dir %s`+
				`    -l WARNING 2>/dev/null | tee %s || true`+"\n"+
				`  fi`+"\n"+
				`else`+"\n"+
				`  echo "[apifuzzer] not installed — run: pip3 install APIFuzzer --break-system-packages"`+"\n"+
				`fi`,
			target, target,
			apiFuzzOut, apiFuzzOut,
			target, apiFuzzOut, apiFuzzOut,
		)

	// ── API-TOOL-5: gotestwaf ─────────────────────────────────────────────────
	// WAF bypass testing for APIs — tests if WAF correctly blocks API attacks.
	// Finds WAF misconfigurations that allow SQL injection, XSS, RCE through API.
	// Useful after wafw00f detects a WAF.
	case "gotestwaf":
		gtwOut := filepath.Join(outDir, scanID8+"_gotestwaf")
		return fmt.Sprintf(
			`if command -v gotestwaf &>/dev/null; then`+"\n"+
				`  gotestwaf`+
				`  --url https://%s`+
				`  --output %s`+
				`  --format json`+
				`  --skipWAFBlockHTTPCodes 400`+
				`  --timeout 30`+
				`  --quiet 2>/dev/null || true`+"\n"+
				`else`+"\n"+
				`  echo "[gotestwaf] not installed — run: go install github.com/wallarm/gotestwaf@latest"`+"\n"+
				`fi`,
			target, gtwOut,
		)

	// ── cariddi ──────────────────────────────────────────────────────────────
	// All-in-one crawler: endpoints + secrets + API keys + juicy files + errors.
	// OPT-CHAIN13: cariddi output → feed endpoints în urlsFile + secrets → notify
	//              + juicy files (backup, config) → nuclei
	//              + errors detected → triage AI
	case "cariddi":
		cariddiOut     := filepath.Join(outDir, scanID8+"_cariddi.json")
		cariddiSecrets := filepath.Join(outDir, scanID8+"_cariddi_secrets.txt")
		cariddiFiles   := filepath.Join(outDir, scanID8+"_cariddi_files.txt")
		cariddiErrors  := filepath.Join(outDir, scanID8+"_cariddi_errors.txt")
		return fmt.Sprintf(
			`if command -v cariddi &>/dev/null; then`+"\n"+
				`  # Run cariddi cu toate flagurile: secrets + endpoints + errors + juicy files`+"\n"+
				`  cat %s | cariddi`+
				`  -s`+            // secrets
				`  -e`+            // juicy endpoints
				`  -err`+          // error hunting
				`  -info`+         // info disclosure
				`  -ext 2`+        // juicy file extensions (level 2: backup, config, db)
				`  -intensive`+    // crawl subdomains too
				`  -c 30`+         // concurrency
				`  -t 10`+         // timeout
				`  -rua`+          // random user agent
				`  -json`+         // JSON output
				`  2>/dev/null | tee %s`+"\n"+
				`  # ── OPT-CHAIN13a: endpoints descoperite → urlsFile ──`+"\n"+
				`  cat %s 2>/dev/null | jq -r 'select(.tag=="endpoint") | .match' 2>/dev/null`+
				`  | grep '^http' | anew %s`+"\n"+
				`  # ── OPT-CHAIN13b: secrets găsite → notify instant ──`+"\n"+
				`  cat %s 2>/dev/null | jq -r 'select(.tag=="secret") | "[\(.name)] \(.match)"' 2>/dev/null`+
				`  | head -10 | tee %s`+"\n"+
				`  [[ -s %s ]] &&`+
				`  printf "CARIDDI SECRETS on %s:\n$(head -3 %s)"` +
				`  | notify -silent 2>/dev/null || true`+"\n"+
				`  # ── OPT-CHAIN13c: juicy files (backup, .sql, .env, .git) → nuclei ──`+"\n"+
				`  cat %s 2>/dev/null | jq -r 'select(.tag=="extension") | .match' 2>/dev/null`+
				`  | grep -iE '\.(sql|bak|backup|env|git|tar|zip|conf|config|xml|json)' | head -20`+
				`  | tee %s`+"\n"+
				`  [[ -s %s ]] && cat %s | nuclei`+
				`  -t exposures/ -t misconfiguration/`+
				`  -severity medium,high,critical -silent 2>/dev/null || true`+"\n"+
				`  # ── OPT-CHAIN13d: errors detected → colectate pentru AI triage ──`+"\n"+
				`  cat %s 2>/dev/null | jq -r 'select(.tag=="error") | .match' 2>/dev/null`+
				`  | head -20 | tee %s`+"\n"+
				`else`+"\n"+
				`  echo "[cariddi] not installed — go install github.com/edoardottt/cariddi/cmd/cariddi@latest"`+"\n"+
				`fi`,
			liveFile, cariddiOut,
			cariddiOut, urlsFile,
			cariddiOut, cariddiSecrets,
			cariddiSecrets, target, cariddiSecrets,
			cariddiOut,
			cariddiFiles,
			cariddiFiles, cariddiFiles,
			cariddiOut, cariddiErrors,
		)

	default:
		// OPT11: nuclei-cve-{tag} — tech-specific CVE templates.
		// Injected by conditions.go when httpx/whatweb detects a specific tech.
		// e.g. nuclei-cve-apache → nuclei with tags=apache,cve
		if strings.HasPrefix(tool.ID, "nuclei-cve-") {
			techTag := strings.TrimPrefix(tool.ID, "nuclei-cve-")
			return fmt.Sprintf(
				`nuclei -l %s`+
					` -tags "%s,cve"`+
					` -exclude-tags dos,intrusive`+
					` -severity medium,high,critical`+
					` -rate-limit 30`+
					` -silent`+
					` -json-export %s`+
					` 2>&1`,
				liveFile, techTag,
				filepath.Join(outDir, scanID8+"_nuclei_cve_"+techTag+".json"),
			)
		}
		// Fallback: run binary with target
		return fmt.Sprintf("%s %s 2>&1", tool.BinaryPath, target)
	}
}

// ScopeFilter wraps a command with a grep filter to enforce scope boundaries.
// Applied to tools that may discover out-of-scope assets.
//
// IMPORTANT: This is a *post-hoc* filter on stdout. It does NOT prevent the
// tool from contacting out-of-scope hosts — it only suppresses them from
// being piped to the next phase. For real per-URL gating, the pipeline calls
// roe.Gate.FilterURLs() on tool output before feeding it to subsequent tools.
func ScopeFilter(cmd string, scope []string) string {
	scope = SafeScope(scope)
	if len(scope) == 0 {
		return cmd
	}
	// Build grep pattern: "\.example\.com|\.example2\.com"
	patterns := make([]string, 0, len(scope))
	for _, s := range scope {
		s = strings.TrimPrefix(s, "*.")
		if cidrRe.MatchString(s) {
			// CIDR ranges can't be grepped meaningfully — skip; the ROE gate
			// handles IP-range scoping at scan-start.
			continue
		}
		s = strings.ReplaceAll(s, ".", `\.`)
		patterns = append(patterns, s)
	}
	if len(patterns) == 0 {
		return cmd
	}
	grepPat := strings.Join(patterns, "|")
	return fmt.Sprintf(`(%s) | grep -E '%s'`, cmd, grepPat)
}
