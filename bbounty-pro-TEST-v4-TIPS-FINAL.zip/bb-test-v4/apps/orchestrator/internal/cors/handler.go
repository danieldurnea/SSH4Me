package cors

import (
	"context"
	"encoding/json"
	"net/http"
	"time"

	"github.com/rs/zerolog/log"
)

// Handler wraps the Engine with HTTP API endpoints.
type Handler struct {
	engine *Engine
}

func NewHandler() *Handler {
	return &Handler{engine: New()}
}

// HandleScan runs CORS tests against a list of URLs.
// POST /api/v1/cors/scan
// Body: {"urls": ["https://target.com/api", ...], "timeout_seconds": 30}
func (h *Handler) HandleScan(w http.ResponseWriter, r *http.Request) {
	var req ScanRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, `{"error":"invalid request body"}`, http.StatusBadRequest)
		return
	}

	if len(req.URLs) == 0 {
		http.Error(w, `{"error":"urls required"}`, http.StatusBadRequest)
		return
	}

	timeout := req.Timeout
	if timeout <= 0 || timeout > 300 {
		timeout = 60
	}

	ctx, cancel := context.WithTimeout(r.Context(), time.Duration(timeout)*time.Second)
	defer cancel()

	start := time.Now()
	log.Info().Int("urls", len(req.URLs)).Msg("[cors] scan started")

	findings := h.engine.TestTargets(ctx, req.URLs)

	resp := ScanResponse{
		Scanned:  len(req.URLs),
		Findings: findings,
		Duration: time.Since(start).Round(time.Millisecond).String(),
	}

	log.Info().
		Int("findings", len(findings)).
		Str("duration", resp.Duration).
		Msg("[cors] scan complete")

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(resp)
}

// HandleScanSingle runs CORS tests against a single URL (GET convenience).
// GET /api/v1/cors/scan?url=https://target.com
func (h *Handler) HandleScanSingle(w http.ResponseWriter, r *http.Request) {
	url := r.URL.Query().Get("url")
	if url == "" {
		http.Error(w, `{"error":"url query param required"}`, http.StatusBadRequest)
		return
	}

	ctx, cancel := context.WithTimeout(r.Context(), 30*time.Second)
	defer cancel()

	findings := h.engine.TestURL(ctx, url)

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(ScanResponse{
		Scanned:  1,
		Findings: findings,
	})
}
