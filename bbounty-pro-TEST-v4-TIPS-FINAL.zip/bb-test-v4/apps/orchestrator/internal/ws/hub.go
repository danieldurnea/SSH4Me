package ws

import (
	"context"
	"net/http"
	"os"
	"strings"
	"sync"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/go-chi/chi/v5"
	"github.com/gorilla/websocket"
	"github.com/rs/zerolog/log"
)

// allowedOrigin is resolved once at startup.
// In production set FRONTEND_URL=https://your-vps-ip:3000.
// Empty means "allow localhost only" — never open to all origins.
var allowedOrigin = func() string {
	if u := os.Getenv("FRONTEND_URL"); u != "" {
		return u
	}
	return "" // resolved per-request to localhost variants
}()

var upgrader = websocket.Upgrader{
	ReadBufferSize:  1024,
	WriteBufferSize: 16 * 1024,
	CheckOrigin: func(r *http.Request) bool {
		origin := r.Header.Get("Origin")
		if origin == "" {
			// No Origin header — same-origin request or non-browser client; allow.
			return true
		}
		if allowedOrigin != "" {
			return origin == allowedOrigin
		}
		// Fallback: allow any localhost/127.x origin regardless of port.
		return strings.HasPrefix(origin, "http://localhost") ||
			strings.HasPrefix(origin, "https://localhost") ||
			strings.HasPrefix(origin, "http://127.") ||
			strings.HasPrefix(origin, "https://127.")
	},
}

// client is a single WebSocket connection.
type client struct {
	conn    *websocket.Conn
	scanID  string
	channel string
	send    chan []byte
	once    sync.Once // ensures done is closed exactly once
	done    chan struct{}
}

func (c *client) close() {
	c.once.Do(func() { close(c.done) })
}

// Hub manages all active WebSocket connections with Redis pub/sub fanout.
type Hub struct {
	redis   *cache.Client
	clients map[string]map[*client]bool // "scanID:channel" → set
	mu      sync.RWMutex

	register   chan *client
	unregister chan *client
	broadcast  chan broadcastMsg
}

type broadcastMsg struct {
	key  string
	data []byte
}

// NewHub creates a Hub. Call Run() in a goroutine.
func NewHub(r *cache.Client) *Hub {
	return &Hub{
		redis:      r,
		clients:    make(map[string]map[*client]bool),
		register:   make(chan *client, 256),
		unregister: make(chan *client, 256),
		broadcast:  make(chan broadcastMsg, 8192),
	}
}

// Run is the central event loop — single goroutine owns the clients map.
func (h *Hub) Run() {
	ticker := time.NewTicker(30 * time.Second)
	defer ticker.Stop()

	for {
		select {
		case c := <-h.register:
			key := clientKey(c.scanID, c.channel)
			if h.clients[key] == nil {
				h.clients[key] = make(map[*client]bool)
			}
			h.clients[key][c] = true

		case c := <-h.unregister:
			key := clientKey(c.scanID, c.channel)
			if clients, ok := h.clients[key]; ok {
				delete(clients, c)
				c.close()
				if len(clients) == 0 {
					delete(h.clients, key)
				}
			}

		case msg := <-h.broadcast:
			if clients, ok := h.clients[msg.key]; ok {
				for c := range clients {
					select {
					case c.send <- msg.data:
					default:
						// Slow client: drop oldest, insert newest (non-blocking).
						select {
						case <-c.send:
							c.send <- msg.data
						default:
						}
					}
				}
			}

		case <-ticker.C:
			ping := []byte(`{"type":"ping"}`)
			for _, clients := range h.clients {
				for c := range clients {
					select {
					case c.send <- ping:
					default:
					}
				}
			}
		}
	}
}

// BroadcastTerminal sends raw terminal bytes to a specific tool's watchers.
func (h *Hub) BroadcastTerminal(scanID, toolID string, data []byte) {
	d := make([]byte, len(data))
	copy(d, data) // copy before async send
	h.broadcast <- broadcastMsg{key: clientKey(scanID, "terminal:"+toolID), data: d}
}

// BroadcastStats sends live stats JSON to stat subscribers.
func (h *Hub) BroadcastStats(scanID string, data []byte) {
	h.broadcast <- broadcastMsg{key: clientKey(scanID, "stats"), data: data}
}

// BroadcastPipeline sends pipeline events to pipeline subscribers.
func (h *Hub) BroadcastPipeline(scanID string, data []byte) {
	h.broadcast <- broadcastMsg{key: clientKey(scanID, "pipeline"), data: data}
}

// HandleTerminal upgrades to WebSocket for a specific tool's live terminal.
func (h *Hub) HandleTerminal(w http.ResponseWriter, r *http.Request) {
	scanID := chi.URLParam(r, "scanID")
	toolID := chi.URLParam(r, "toolID")
	h.serveWS(w, r, scanID, "terminal:"+toolID)
}

// HandleStats upgrades to WebSocket for live stats.
func (h *Hub) HandleStats(w http.ResponseWriter, r *http.Request) {
	h.serveWS(w, r, chi.URLParam(r, "scanID"), "stats")
}

// HandlePipeline upgrades to WebSocket for pipeline phase events.
func (h *Hub) HandlePipeline(w http.ResponseWriter, r *http.Request) {
	h.serveWS(w, r, chi.URLParam(r, "scanID"), "pipeline")
}

func (h *Hub) serveWS(w http.ResponseWriter, r *http.Request, scanID, channel string) {
	conn, err := upgrader.Upgrade(w, r, nil)
	if err != nil {
		log.Error().Err(err).Msg("ws upgrade failed")
		return
	}
	c := &client{
		conn:    conn,
		scanID:  scanID,
		channel: channel,
		send:    make(chan []byte, 512),
		done:    make(chan struct{}),
	}
	h.register <- c
	go c.writePump(h)
	go c.readPump(h)
}

func (c *client) writePump(h *Hub) {
	defer func() {
		h.unregister <- c
		c.conn.Close()
	}()
	for {
		select {
		case msg, ok := <-c.send:
			c.conn.SetWriteDeadline(time.Now().Add(10 * time.Second))
			if !ok {
				c.conn.WriteMessage(websocket.CloseMessage, []byte{})
				return
			}
			if err := c.conn.WriteMessage(websocket.BinaryMessage, msg); err != nil {
				return
			}
		case <-c.done:
			return
		}
	}
}

func (c *client) readPump(h *Hub) {
	defer func() {
		h.unregister <- c
		c.conn.Close()
	}()
	c.conn.SetReadLimit(512)
	c.conn.SetReadDeadline(time.Now().Add(60 * time.Second))
	c.conn.SetPongHandler(func(string) error {
		c.conn.SetReadDeadline(time.Now().Add(60 * time.Second))
		return nil
	})
	for {
		if _, _, err := c.conn.ReadMessage(); err != nil {
			if !websocket.IsCloseError(err, websocket.CloseGoingAway, websocket.CloseNormalClosure) {
				log.Debug().Err(err).Msg("ws read error")
			}
			return
		}
	}
}

// RedisSubscribe subscribes to Redis channels for multi-instance fanout.
func (h *Hub) RedisSubscribe(ctx context.Context, pattern string) {
	pubsub := h.redis.Raw().PSubscribe(ctx, pattern)
	defer pubsub.Close()
	for msg := range pubsub.Channel() {
		h.broadcast <- broadcastMsg{key: msg.Channel, data: []byte(msg.Payload)}
	}
}

func clientKey(scanID, channel string) string { return scanID + ":" + channel }
