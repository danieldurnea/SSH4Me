// Package findings — Postgres background sync.
//
// PARTIAL IMPLEMENTATION DISCLAIMER:
// - Background goroutine syncs Redis findings → Postgres every 5 min
// - Uses ON CONFLICT to avoid duplicates
// - NO transactional consistency — if Postgres write fails, Redis stays
// - NO migration handling — assumes init.sql has been applied
// - NO indexing strategy beyond what init.sql provides
// - NO archival of old findings (>90 days should be cold-stored)

package findings

import (
	"context"
	"encoding/json"
	"time"

	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/rs/zerolog/log"
)

// PostgresSync writes findings from Redis to Postgres on a schedule.
type PostgresSync struct {
	store    *Store
	db       *pgxpool.Pool
	interval time.Duration
}

func NewPostgresSync(store *Store, db *pgxpool.Pool) *PostgresSync {
	return &PostgresSync{
		store:    store,
		db:       db,
		interval: 5 * time.Minute,
	}
}

// Run starts the sync loop. Blocks until ctx is cancelled.
func (s *PostgresSync) Run(ctx context.Context) {
	if s.db == nil {
		log.Warn().Msg("findings: no Postgres pool — sync disabled")
		return
	}
	ticker := time.NewTicker(s.interval)
	defer ticker.Stop()

	log.Info().Dur("interval", s.interval).Msg("findings: Postgres sync started")

	for {
		select {
		case <-ctx.Done():
			return
		case <-ticker.C:
			if err := s.syncOnce(ctx); err != nil {
				log.Error().Err(err).Msg("findings: sync failed")
			}
		}
	}
}

// syncOnce iterates all scan keys in Redis and persists findings to Postgres.
//
// LIMITATION: O(N) scan of all keys with prefix `findings:scan:*`.
// For large datasets, switch to a queue pattern (push finding ID to a Redis
// list when written, drain the list in this worker).
func (s *PostgresSync) syncOnce(ctx context.Context) error {
	cursor := uint64(0)
	totalSynced := 0

	for {
		keys, nextCursor, err := s.store.cache.Raw().Scan(ctx, cursor, "findings:scan:*", 100).Result()
		if err != nil {
			return err
		}

		for _, key := range keys {
			scanID := key[len("findings:scan:"):]
			ids, err := s.store.cache.Raw().ZRange(ctx, key, 0, -1).Result()
			if err != nil {
				continue
			}
			for _, id := range ids {
				var f Finding
				if err := s.store.cache.GetJSON(ctx, "finding:item:"+id, &f); err != nil {
					continue
				}
				if err := s.upsertFinding(ctx, &f, scanID); err == nil {
					totalSynced++
				}
			}
		}

		cursor = nextCursor
		if cursor == 0 {
			break
		}
	}

	if totalSynced > 0 {
		log.Info().Int("count", totalSynced).Msg("findings: synced to Postgres")
	}
	return nil
}

func (s *PostgresSync) upsertFinding(ctx context.Context, f *Finding, scanID string) error {
	tags, _ := json.Marshal(f.Tags)
	_, err := s.db.Exec(ctx, `
		INSERT INTO findings (
			finding_uuid, scan_id, title, url, severity, category,
			parameter, payload, response, status, cvss, cvss_vector,
			source, ai_analysis, tags, created_at, updated_at
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17)
		ON CONFLICT (finding_uuid) DO UPDATE SET
			status = EXCLUDED.status,
			cvss = EXCLUDED.cvss,
			ai_analysis = EXCLUDED.ai_analysis,
			updated_at = NOW()
	`,
		f.ID, scanID, f.Title, f.URL, string(f.Severity), f.Category,
		f.Parameter, f.Payload, f.Response, string(f.Status),
		f.CVSS, f.CVSSVector, f.Source, f.AIAnalysis, tags,
		f.CreatedAt, f.UpdatedAt,
	)
	return err
}

// Stats returns count of findings in Postgres (for health checks).
func (s *PostgresSync) Stats(ctx context.Context) (int64, error) {
	if s.db == nil {
		return 0, nil
	}
	var count int64
	err := s.db.QueryRow(ctx, "SELECT COUNT(*) FROM findings").Scan(&count)
	return count, err
}
