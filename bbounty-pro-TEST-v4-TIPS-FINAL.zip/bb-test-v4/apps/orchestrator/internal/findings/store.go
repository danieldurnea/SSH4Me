package findings

import (
	"context"
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/go-chi/chi/v5"
	"github.com/google/uuid"
	"github.com/redis/go-redis/v9"
	"github.com/rs/zerolog/log"
)

// ── Types ─────────────────────────────────────────────────────────────────────

type Severity     string
type FindingStatus string

const (
	SeverityCritical Severity = "critical"
	SeverityHigh     Severity = "high"
	SeverityMedium   Severity = "medium"
	SeverityLow      Severity = "low"
	SeverityInfo     Severity = "info"
)

const (
	StatusNew       FindingStatus = "new"
	StatusConfirmed FindingStatus = "confirmed"
	StatusDuplicate FindingStatus = "duplicate"
	StatusInvalid   FindingStatus = "invalid"
	StatusResolved  FindingStatus = "resolved"
)

// Finding is the canonical vulnerability finding model.
type Finding struct {
	ID         string        `json:"id"`
	ScanID     string        `json:"scan_id"`
	Title      string        `json:"title"`
	URL        string        `json:"url"`
	Severity   Severity      `json:"severity"`
	Category   string        `json:"category"`
	Parameter  string        `json:"parameter,omitempty"`
	Payload    string        `json:"payload,omitempty"`
	Response   string        `json:"response,omitempty"`
	Status     FindingStatus `json:"status"`
	CVSS       *float64      `json:"cvss,omitempty"`
	CVSSVector string        `json:"cvss_vector,omitempty"`
	CreatedAt  time.Time     `json:"created_at"`
	UpdatedAt  time.Time     `json:"updated_at"`
	Source     string        `json:"source"`
	AIAnalysis string        `json:"ai_analysis,omitempty"`
	Tags       []string      `json:"tags,omitempty"`
}

// ── Store ─────────────────────────────────────────────────────────────────────

// Store persists findings in Redis with 72h TTL.
// In production, sync to PostgreSQL via a background writer for durability.
type Store struct {
	cache  *cache.Client
	onSave []func(*Finding) // optional callbacks fired after Save
}

// ctxKeyUserID is the context key for the authenticated user ID.
// Set by the auth middleware on every authenticated request.
type ctxKey string
const ctxKeyUserID ctxKey = "userID"

func NewStore(c *cache.Client) *Store { return &Store{cache: c} }

// OnSave registers a callback invoked (asynchronously, fire-and-forget)
// after every successful Save. Used by main.go to wire notify/auditlog
// without creating circular package dependencies.
func (s *Store) OnSave(cb func(*Finding)) {
	s.onSave = append(s.onSave, cb)
}

func itemKey(id string) string     { return "finding:item:" + id }
func scanKey(scanID string) string { return "findings:scan:" + scanID }

// Save persists a finding and indexes it by scan ID.
func (s *Store) Save(ctx context.Context, f *Finding) error {
	if f.ID == "" {
		f.ID = uuid.New().String()
	}
	now := time.Now()
	f.UpdatedAt = now
	if f.CreatedAt.IsZero() {
		f.CreatedAt = now
	}

	if err := s.cache.SetJSON(ctx, itemKey(f.ID), f, 72*time.Hour); err != nil {
		return err
	}

	if err := s.cache.Raw().ZAdd(ctx, scanKey(f.ScanID), redis.Z{
		Score:  float64(f.CreatedAt.UnixMilli()),
		Member: f.ID,
	}).Err(); err != nil {
		return err
	}

	// Fire post-save hooks asynchronously — never block the caller.
	for _, cb := range s.onSave {
		go func(fn func(*Finding)) {
			defer func() {
				if r := recover(); r != nil {
					log.Error().Interface("panic", r).Msg("findings: OnSave callback panicked")
				}
			}()
			fn(f)
		}(cb)
	}
	return nil
}

// ListByScan returns all findings for a scan, newest first.
func (s *Store) ListByScan(ctx context.Context, scanID string) ([]*Finding, error) {
	ids, err := s.cache.Raw().ZRevRange(ctx, scanKey(scanID), 0, -1).Result()
	if err != nil || len(ids) == 0 {
		return []*Finding{}, nil
	}
	out := make([]*Finding, 0, len(ids))
	for _, id := range ids {
		var f Finding
		if err := s.cache.GetJSON(ctx, itemKey(id), &f); err != nil {
			log.Warn().Str("id", id).Msg("findings: cache miss — orphaned index entry")
			continue
		}
		out = append(out, &f)
	}
	return out, nil
}

// Get fetches a single finding by ID.
func (s *Store) Get(ctx context.Context, id string) (*Finding, error) {
	var f Finding
	return &f, s.cache.GetJSON(ctx, itemKey(id), &f)
}

// Update applies partial updates to a finding.
func (s *Store) Update(ctx context.Context, id string, updates map[string]any) (*Finding, error) {
	f, err := s.Get(ctx, id)
	if err != nil {
		return nil, err
	}
	if v, ok := updates["title"].(string);       ok { f.Title = v }
	if v, ok := updates["status"].(string);      ok { f.Status = FindingStatus(v) }
	if v, ok := updates["severity"].(string);    ok { f.Severity = Severity(v) }
	if v, ok := updates["ai_analysis"].(string); ok { f.AIAnalysis = v }
	if v, ok := updates["cvss"].(float64);       ok { f.CVSS = &v }
	if v, ok := updates["cvss_vector"].(string); ok { f.CVSSVector = v }
	f.UpdatedAt = time.Now()
	return f, s.cache.SetJSON(ctx, itemKey(id), f, 72*time.Hour)
}

// Delete removes a finding and its scan index entry.
func (s *Store) Delete(ctx context.Context, id, scanID string) error {
	pipe := s.cache.Raw().Pipeline()
	pipe.Del(ctx, itemKey(id))
	if scanID != "" {
		pipe.ZRem(ctx, scanKey(scanID), id)
	}
	_, err := pipe.Exec(ctx)
	return err
}

// ── HTTP Handlers ─────────────────────────────────────────────────────────────

func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(v)
}

func writeErr(w http.ResponseWriter, status int, msg string) {
	writeJSON(w, status, map[string]string{"error": msg})
}

func (s *Store) HandleList(w http.ResponseWriter, r *http.Request) {
	scanID := chi.URLParam(r, "scanID")

	// Ownership check — user can only see their own scans
	if userID := r.Context().Value(ctxKeyUserID); userID != nil {
		ownerKey := "scan:owner:" + scanID
		owner, err := s.cache.Raw().Get(r.Context(), ownerKey).Result()
		if err == nil && owner != "" && owner != fmt.Sprintf("%v", userID) {
			writeErr(w, http.StatusForbidden, "access denied — scan belongs to another user")
			return
		}
	}

	list, err := s.ListByScan(r.Context(), scanID)
	if err != nil {
		writeErr(w, http.StatusInternalServerError, "failed to load findings")
		return
	}
	if sev := r.URL.Query().Get("severity"); sev != "" {
		var filtered []*Finding
		for _, f := range list {
			if string(f.Severity) == sev {
				filtered = append(filtered, f)
			}
		}
		list = filtered
	}
	if list == nil {
		list = []*Finding{}
	}
	writeJSON(w, http.StatusOK, list)
}

func (s *Store) HandleCreate(w http.ResponseWriter, r *http.Request) {
	var f Finding
	if err := json.NewDecoder(r.Body).Decode(&f); err != nil {
		writeErr(w, http.StatusBadRequest, "invalid body")
		return
	}
	if f.Title == "" || f.URL == "" {
		writeErr(w, http.StatusBadRequest, "title and url are required")
		return
	}
	if f.Status == ""   { f.Status = StatusNew }
	if f.Severity == "" { f.Severity = SeverityMedium }

	if err := s.Save(r.Context(), &f); err != nil {
		log.Error().Err(err).Msg("finding: save failed")
		writeErr(w, http.StatusInternalServerError, "save failed")
		return
	}
	writeJSON(w, http.StatusCreated, f)
}

func (s *Store) HandleUpdate(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")
	var updates map[string]any
	if err := json.NewDecoder(r.Body).Decode(&updates); err != nil {
		writeErr(w, http.StatusBadRequest, "invalid body")
		return
	}
	f, err := s.Update(r.Context(), id, updates)
	if err != nil {
		writeErr(w, http.StatusInternalServerError, "update failed")
		return
	}
	writeJSON(w, http.StatusOK, f)
}

func (s *Store) HandleDelete(w http.ResponseWriter, r *http.Request) {
	id := chi.URLParam(r, "id")
	scanID := r.URL.Query().Get("scan_id")
	if err := s.Delete(r.Context(), id, scanID); err != nil {
		writeErr(w, http.StatusInternalServerError, "delete failed")
		return
	}
	w.WriteHeader(http.StatusNoContent)
}
