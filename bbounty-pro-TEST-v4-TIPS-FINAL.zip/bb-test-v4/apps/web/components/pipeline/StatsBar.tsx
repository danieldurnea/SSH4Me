"use client";

import { useEffect, useRef } from "react";
import { cn } from "@/lib/utils";

interface Stats {
  subs: number;
  live: number;
  urls: number;
  vulns: number;
  elapsed: number;
}

interface Props {
  stats: Stats;
}

const STAT_DEFS = [
  { key: "subs" as const,  label: "SUBS",  color: "#00e5cc", desc: "Subdomains found" },
  { key: "live" as const,  label: "LIVE",  color: "#7c6aff", desc: "Live hosts confirmed" },
  { key: "urls" as const,  label: "URLS",  color: "#ff9b3a", desc: "URLs discovered" },
  { key: "vulns" as const, label: "VULNS", color: "#ff3a5c", desc: "Vulnerabilities found" },
];

export function StatsBar({ stats }: Props) {
  return (
    <div className="flex items-stretch border-b border-[#1a2a32] bg-[#080c0e]">
      {STAT_DEFS.map(({ key, label, color, desc }) => (
        <StatCell
          key={key}
          label={label}
          value={stats[key]}
          color={color}
          desc={desc}
          prev={0}
        />
      ))}

      {/* Elapsed time */}
      <div className="flex items-center px-6 ml-auto border-l border-[#1a2a32]">
        <div className="text-center">
          <div className="text-[10px] text-[#2a5a6a] tracking-widest mb-0.5">ELAPSED</div>
          <div className="text-sm font-bold text-[#4a8a9a] tabular-nums">
            {formatElapsed(stats.elapsed)}
          </div>
        </div>
      </div>
    </div>
  );
}

function StatCell({
  label, value, color, desc,
}: {
  label: string;
  value: number;
  color: string;
  desc: string;
  prev: number;
}) {
  const prevRef = useRef(value);
  const isNew = value > prevRef.current;

  useEffect(() => {
    if (isNew) {
      const t = setTimeout(() => { prevRef.current = value; }, 600);
      return () => clearTimeout(t);
    }
  }, [value, isNew]);

  return (
    <div
      className={cn(
        "flex-1 flex flex-col items-center justify-center py-2 px-4",
        "border-r border-[#1a2a32] relative overflow-hidden",
        "transition-all duration-300",
      )}
      title={desc}
    >
      {/* Flash overlay when value increases */}
      {isNew && (
        <div
          className="absolute inset-0 opacity-10 animate-[flash_0.4s_ease-out]"
          style={{ background: color }}
        />
      )}

      <div className="text-[10px] tracking-[0.25em] text-[#2a5a6a] mb-0.5">{label}</div>
      <div
        className="text-2xl font-black tabular-nums leading-none"
        style={{ color }}
      >
        {value.toLocaleString()}
      </div>

      {/* Mini bar indicator */}
      <div className="w-full mt-1.5 h-px">
        <div
          className="h-full transition-all duration-500"
          style={{
            width: value > 0 ? "100%" : "0%",
            background: `linear-gradient(90deg, ${color}00, ${color}, ${color}00)`,
          }}
        />
      </div>
    </div>
  );
}

function formatElapsed(seconds: number): string {
  if (seconds < 60) return `${Math.floor(seconds)}s`;
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  if (m < 60) return `${m}m ${s}s`;
  const h = Math.floor(m / 60);
  return `${h}h ${m % 60}m`;
}
