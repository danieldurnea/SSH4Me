"use client";

import { useState } from "react";
import { cn } from "@/lib/utils";
import { GitCompare, TrendingUp, TrendingDown, Plus, Minus, AlertTriangle, CheckCircle, Activity } from "lucide-react";
import useSWR from "swr";

const fetcher = (url: string) =>
  fetch(url, {
    headers: { Authorization: `Bearer ${localStorage.getItem("access_token") ?? ""}` },
  }).then(r => r.json());

interface ScanDiff {
  target: string;
  old_scan_id: string;
  new_scan_id: string;
  generated_at: string;
  period: string;
  summary: string;
  alert_level: "none" | "info" | "warning" | "critical";
  has_new_crits: boolean;
  subdomains: {
    new: string[];
    disappeared: string[];
    stable: number;
    total_old: number;
    total_new: number;
  };
  hosts: {
    new: { url: string; status_code: number; tech: string[] }[];
    went_down: string[];
    stable: number;
  };
  findings: {
    new: { id: string; title: string; url: string; severity: string; category: string }[];
    fixed: { title: string; url: string; severity: string }[];
    still_open: { title: string }[];
    severity_up: { finding: any; old_severity: string; new_severity: string }[];
  };
  ports: {
    newly_open: Record<string, number[]>;
    newly_closed: Record<string, number[]>;
  };
  tech: {
    newly_detected: Record<string, string[]>;
    removed: Record<string, string[]>;
  };
}

const SEV_COLOR: Record<string, string> = {
  critical: "#ff3a5c",
  high:     "#ff9b3a",
  medium:   "#ffcc3a",
  low:      "#7c6aff",
  info:     "#4a8a9a",
};

const ALERT_META = {
  none:     { color: "#2a4a5a", icon: CheckCircle, label: "No changes" },
  info:     { color: "#00e5cc", icon: Activity,    label: "New assets" },
  warning:  { color: "#ff9b3a", icon: AlertTriangle, label: "New highs" },
  critical: { color: "#ff3a5c", icon: AlertTriangle, label: "New criticals!" },
};

interface Props {
  target?: string;
  scanID?: string | null;
}

export function DiffViewer({ target, scanID }: Props) {
  const queryTarget = target || "";
  const { data: diff, isLoading, error } = useSWR<ScanDiff>(
    queryTarget ? `/api/v1/diff/latest?target=${encodeURIComponent(queryTarget)}` : null,
    fetcher,
    { refreshInterval: 30000 }
  );

  const [section, setSection] = useState<"findings" | "subs" | "hosts" | "ports" | "tech">("findings");

  if (!queryTarget) {
    return (
      <div className="flex items-center justify-center h-64 text-[#2a4a5a] text-sm">
        Set a target to see historical diff
      </div>
    );
  }

  if (isLoading) {
    return (
      <div className="flex items-center gap-3 p-6 text-[#4a8a9a] text-sm">
        <GitCompare size={16} className="animate-spin" />
        Loading diff...
      </div>
    );
  }

  if (error || !diff) {
    return (
      <div className="flex flex-col items-center justify-center h-64 text-[#2a4a5a] text-sm">
        <GitCompare size={32} className="mb-3 opacity-20" />
        <div>No comparison data yet</div>
        <div className="text-[11px] mt-1">Need at least 2 completed scans for this target</div>
      </div>
    );
  }

  const alertMeta = ALERT_META[diff.alert_level] || ALERT_META.none;
  const AlertIcon = alertMeta.icon;

  const sections = [
    { key: "findings" as const, label: "Findings", count: diff.findings.new.length, color: "#ff3a5c" },
    { key: "subs" as const,     label: "Subdomains", count: diff.subdomains.new.length, color: "#00e5cc" },
    { key: "hosts" as const,    label: "Hosts", count: diff.hosts.new.length, color: "#7c6aff" },
    { key: "ports" as const,    label: "Ports", count: Object.keys(diff.ports.newly_open ?? {}).length, color: "#ff9b3a" },
    { key: "tech" as const,     label: "Tech", count: Object.keys(diff.tech.newly_detected ?? {}).length, color: "#54b35f" },
  ];

  return (
    <div className="flex flex-col h-full">
      {/* Alert banner */}
      <div
        className={cn(
          "flex items-center gap-3 px-5 py-3 border-b text-xs font-semibold",
          diff.alert_level === "critical" ? "bg-[#1f0a0e] border-[#ff3a5c]/30" :
          diff.alert_level === "warning"  ? "bg-[#1f150a] border-[#ff9b3a]/30" :
          diff.alert_level === "info"     ? "bg-[#0a1f19] border-[#00e5cc]/20" :
                                            "border-[#1a2a32]"
        )}
      >
        <AlertIcon size={14} style={{ color: alertMeta.color }} />
        <span style={{ color: alertMeta.color }}>{alertMeta.label}</span>
        <span className="text-[#2a4a5a]">—</span>
        <span className="text-[#4a6a7a]">{diff.summary}</span>
        <span className="ml-auto text-[#2a4a5a] font-normal">{diff.period} ago → now</span>
      </div>

      {/* Section tabs */}
      <div className="flex border-b border-[#1a2a32] bg-[#0a1015] overflow-x-auto">
        {sections.map(s => (
          <button
            key={s.key}
            onClick={() => setSection(s.key)}
            className={cn(
              "flex items-center gap-1.5 px-4 py-2.5 text-[10px] font-semibold tracking-widest whitespace-nowrap",
              "border-b-2 -mb-px transition-all",
              section === s.key
                ? "border-current text-current"
                : "border-transparent text-[#2a4a5a] hover:text-[#4a8a9a]"
            )}
            style={{ color: section === s.key ? s.color : undefined }}
          >
            {s.label}
            {s.count > 0 && (
              <span
                className="px-1.5 py-0.5 rounded-full text-[9px] font-bold"
                style={{ background: s.color + "20", color: s.color }}
              >
                +{s.count}
              </span>
            )}
          </button>
        ))}
      </div>

      {/* Section content */}
      <div className="flex-1 overflow-y-auto p-4">
        {/* Findings diff */}
        {section === "findings" && (
          <div className="space-y-4">
            {diff.findings.new.length > 0 && (
              <DiffSection title="New Findings" icon={Plus} color="#ff3a5c" count={diff.findings.new.length}>
                {diff.findings.new.map((f, i) => (
                  <div key={i} className="flex items-start gap-3 py-2 border-b border-[#0f1e28] last:border-0">
                    <span
                      className="text-[10px] font-bold px-1.5 py-0.5 rounded flex-shrink-0"
                      style={{ color: SEV_COLOR[f.severity] || "#4a6a7a", background: SEV_COLOR[f.severity] + "15" }}
                    >
                      {f.severity.toUpperCase()}
                    </span>
                    <div>
                      <div className="text-xs font-semibold text-[#c8d8e0]">{f.title}</div>
                      <div className="text-[10px] text-[#2a7a9a] font-mono truncate">{f.url}</div>
                    </div>
                    <span className="text-[10px] text-[#2a4a5a] ml-auto flex-shrink-0">{f.category}</span>
                  </div>
                ))}
              </DiffSection>
            )}

            {diff.findings.fixed.length > 0 && (
              <DiffSection title="Fixed / Resolved" icon={CheckCircle} color="#54b35f" count={diff.findings.fixed.length}>
                {diff.findings.fixed.map((f, i) => (
                  <div key={i} className="flex items-center gap-2 py-1.5 text-[11px]">
                    <span className="text-[#54b35f]">✓</span>
                    <span className="text-[#4a6a7a] line-through">{f.title}</span>
                  </div>
                ))}
              </DiffSection>
            )}

            {diff.findings.severity_up.length > 0 && (
              <DiffSection title="Severity Escalations" icon={TrendingUp} color="#ff9b3a" count={diff.findings.severity_up.length}>
                {diff.findings.severity_up.map((c, i) => (
                  <div key={i} className="flex items-center gap-2 py-1.5 text-[11px]">
                    <span style={{ color: SEV_COLOR[c.old_severity] }}>{c.old_severity}</span>
                    <span className="text-[#2a4a5a]">→</span>
                    <span style={{ color: SEV_COLOR[c.new_severity] }}>{c.new_severity}</span>
                    <span className="text-[#4a6a7a] truncate">{c.finding.title}</span>
                  </div>
                ))}
              </DiffSection>
            )}

            {diff.findings.new.length === 0 && diff.findings.fixed.length === 0 && (
              <div className="text-center py-8 text-[#2a4a5a] text-sm">
                No findings changes since last scan
              </div>
            )}
          </div>
        )}

        {/* Subdomains diff */}
        {section === "subs" && (
          <div className="space-y-4">
            <div className="grid grid-cols-3 gap-3 mb-4">
              {[
                { label: "Total (prev)", value: diff.subdomains.total_old, color: "#4a6a7a" },
                { label: "Total (now)",  value: diff.subdomains.total_new, color: "#00e5cc" },
                { label: "Stable",       value: diff.subdomains.stable,    color: "#2a9a7a" },
              ].map(s => (
                <div key={s.label} className="bg-[#0a1820] border border-[#1a2a32] rounded-lg p-3 text-center">
                  <div className="text-[10px] text-[#2a5a6a] mb-1">{s.label}</div>
                  <div className="text-xl font-bold" style={{ color: s.color }}>{s.value}</div>
                </div>
              ))}
            </div>

            {diff.subdomains.new.length > 0 && (
              <DiffSection title="New Subdomains" icon={Plus} color="#00e5cc" count={diff.subdomains.new.length}>
                <div className="grid grid-cols-2 gap-1">
                  {diff.subdomains.new.map(s => (
                    <div key={s} className="text-[11px] text-[#2a9a7a] font-mono py-0.5">{s}</div>
                  ))}
                </div>
              </DiffSection>
            )}

            {diff.subdomains.disappeared.length > 0 && (
              <DiffSection title="Disappeared" icon={Minus} color="#ff3a5c" count={diff.subdomains.disappeared.length}>
                <div className="grid grid-cols-2 gap-1">
                  {diff.subdomains.disappeared.map(s => (
                    <div key={s} className="text-[11px] text-[#4a3a3a] font-mono line-through py-0.5">{s}</div>
                  ))}
                </div>
              </DiffSection>
            )}
          </div>
        )}

        {/* Hosts diff */}
        {section === "hosts" && (
          <div className="space-y-4">
            {diff.hosts.new.length > 0 && (
              <DiffSection title="Newly Live" icon={Plus} color="#7c6aff" count={diff.hosts.new.length}>
                {diff.hosts.new.map((h, i) => (
                  <div key={i} className="flex items-center gap-2 py-1.5 text-[11px]">
                    <span className="text-[#00e5cc]">{h.status_code}</span>
                    <span className="text-[#7c6aff] font-mono">{h.url}</span>
                    <div className="flex gap-1 ml-auto">
                      {h.tech?.slice(0, 3).map(t => (
                        <span key={t} className="text-[9px] px-1 rounded bg-[#0a1820] border border-[#1a2a32] text-[#2a5a6a]">{t}</span>
                      ))}
                    </div>
                  </div>
                ))}
              </DiffSection>
            )}

            {diff.hosts.went_down.length > 0 && (
              <DiffSection title="Went Offline" icon={Minus} color="#ff3a5c" count={diff.hosts.went_down.length}>
                {diff.hosts.went_down.map((url, i) => (
                  <div key={i} className="text-[11px] text-[#4a3a3a] font-mono line-through py-0.5">{url}</div>
                ))}
              </DiffSection>
            )}
          </div>
        )}

        {/* Ports diff */}
        {section === "ports" && (
          <div className="space-y-4">
            {Object.entries(diff.ports.newly_open ?? {}).map(([host, ports]) => (
              <div key={host} className="border border-[#ff9b3a]/20 rounded-lg p-3">
                <div className="text-[11px] font-mono text-[#4a8a9a] mb-2">{host}</div>
                <div className="flex flex-wrap gap-1">
                  {ports.map(p => (
                    <span key={p} className="text-[10px] px-2 py-0.5 rounded bg-[#ff9b3a]/10 border border-[#ff9b3a]/30 text-[#ff9b3a] font-bold">
                      {p}
                    </span>
                  ))}
                </div>
              </div>
            ))}
            {Object.keys(diff.ports.newly_open ?? {}).length === 0 && (
              <div className="text-center py-8 text-[#2a4a5a] text-sm">No port changes</div>
            )}
          </div>
        )}

        {/* Tech diff */}
        {section === "tech" && (
          <div className="space-y-3">
            {Object.entries(diff.tech.newly_detected ?? {}).map(([host, techs]) => (
              <div key={host} className="border border-[#54b35f]/20 rounded-lg p-3">
                <div className="text-[11px] font-mono text-[#4a8a9a] mb-2">{host}</div>
                <div className="flex flex-wrap gap-1">
                  {techs.map(t => (
                    <span key={t} className="text-[10px] px-2 py-0.5 rounded bg-[#54b35f]/10 border border-[#54b35f]/30 text-[#54b35f]">
                      {t}
                    </span>
                  ))}
                </div>
              </div>
            ))}
            {Object.keys(diff.tech.newly_detected ?? {}).length === 0 && (
              <div className="text-center py-8 text-[#2a4a5a] text-sm">No technology changes</div>
            )}
          </div>
        )}
      </div>
    </div>
  );
}

function DiffSection({
  title, icon: Icon, color, count, children,
}: {
  title: string;
  icon: any;
  color: string;
  count: number;
  children: React.ReactNode;
}) {
  return (
    <div className="border rounded-lg overflow-hidden" style={{ borderColor: color + "25" }}>
      <div
        className="flex items-center gap-2 px-4 py-2.5 text-[10px] font-bold tracking-widest"
        style={{ background: color + "10", color }}
      >
        <Icon size={12} />
        {title}
        <span className="ml-auto">{count}</span>
      </div>
      <div className="px-4 py-3">{children}</div>
    </div>
  );
}
