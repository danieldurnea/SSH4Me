"use client";

import { useState, useMemo } from "react";
import { cn } from "@/lib/utils";
import { Info, Check, Play, Search, SlidersHorizontal } from "lucide-react";
import useSWR from "swr";
import type { Tool } from "@bbounty/shared-types";

const fetcher = (url: string) => fetch(url).then(r => r.json());

const PHASE_META: Record<string, { label: string; color: string; bg: string }> = {
  recon:         { label: "Recon",        color: "#00e5cc", bg: "#0a1f1e" },
  enumeration:   { label: "Enumeration",  color: "#7c6aff", bg: "#120e1f" },
  scanning:      { label: "Scanning",     color: "#ff9b3a", bg: "#1f150a" },
  exploitation:  { label: "Exploitation", color: "#ff3a5c", bg: "#1f0a0e" },
  reporting:     { label: "Reporting",    color: "#54b35f", bg: "#0a1f0e" },
};

const ROI_LABEL: Record<number, { label: string; color: string }> = {
  1: { label: "LOW",      color: "#4a6a7a" },
  2: { label: "MEDIUM",   color: "#ff9b3a" },
  3: { label: "HIGH",     color: "#7c6aff" },
  4: { label: "CRITICAL", color: "#ff3a5c" },
};

export function ToolGrid() {
  const { data: tools = [], isLoading } = useSWR<Tool[]>("/api/v1/tools", fetcher);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [filter, setFilter] = useState("");
  const [phaseFilter, setPhaseFilter] = useState<string | null>(null);
  const [infoTool, setInfoTool] = useState<Tool | null>(null);
  const [copiedCmd, setCopiedCmd] = useState<string | null>(null);

  const filtered = useMemo(() => {
    return tools.filter(t => {
      const matchText =
        !filter ||
        t.name.toLowerCase().includes(filter.toLowerCase()) ||
        t.description.toLowerCase().includes(filter.toLowerCase()) ||
        t.tags.some(tag => tag.includes(filter.toLowerCase()));
      const matchPhase = !phaseFilter || t.phase === phaseFilter;
      return matchText && matchPhase;
    });
  }, [tools, filter, phaseFilter]);

  const byPhase = useMemo(() => {
    const groups: Record<string, Tool[]> = {};
    for (const t of filtered) {
      if (!groups[t.phase]) groups[t.phase] = [];
      groups[t.phase].push(t);
    }
    return groups;
  }, [filtered]);

  const toggleTool = (id: string) =>
    setSelected(prev => {
      const next = new Set(prev);
      next.has(id) ? next.delete(id) : next.add(id);
      return next;
    });

  const selectAll = () => setSelected(new Set(tools.map(t => t.id)));
  const selectNone = () => setSelected(new Set());

  const copyInstall = (cmd: string, toolId: string) => {
    navigator.clipboard.writeText(cmd);
    setCopiedCmd(toolId);
    setTimeout(() => setCopiedCmd(null), 2000);
  };

  const runSingle = async (toolId: string) => {
    await fetch(`/api/v1/tools/${toolId}/run`, { method: "POST" });
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center h-full text-[#2a4a5a] text-sm">
        Loading tool registry...
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      {/* Toolbar */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-[#1a2a32] bg-[#0a1015]">
        {/* Search */}
        <div className="relative flex-1 max-w-xs">
          <Search
            size={13}
            className="absolute left-3 top-1/2 -translate-y-1/2 text-[#2a5a6a]"
          />
          <input
            value={filter}
            onChange={e => setFilter(e.target.value)}
            placeholder="Search tools..."
            className="w-full pl-8 pr-3 py-2 bg-[#080c0e] border border-[#1a2a32] rounded-lg text-xs text-[#c8d8e0] placeholder-[#2a4a5a] focus:outline-none focus:border-[#00e5cc]/30"
          />
        </div>

        {/* Phase filters */}
        <div className="flex gap-1">
          {Object.entries(PHASE_META).map(([id, { label, color }]) => (
            <button
              key={id}
              onClick={() => setPhaseFilter(phaseFilter === id ? null : id)}
              className={cn(
                "px-3 py-1.5 rounded text-[10px] font-semibold tracking-wide border transition-all",
                phaseFilter === id
                  ? "border-current bg-current/10"
                  : "border-[#1a2a32] text-[#2a4a5a] hover:border-[#2a4a5a]"
              )}
              style={{ color: phaseFilter === id ? color : undefined }}
            >
              {label}
            </button>
          ))}
        </div>

        {/* Bulk select */}
        <div className="flex items-center gap-2 border-l border-[#1a2a32] pl-3 ml-auto">
          <span className="text-[10px] text-[#2a5a6a]">
            {selected.size}/{tools.length} selected
          </span>
          <button
            onClick={selectAll}
            className="text-[10px] text-[#2a7a6a] hover:text-[#00e5cc] transition-colors"
          >
            All
          </button>
          <span className="text-[#1a2a32]">·</span>
          <button
            onClick={selectNone}
            className="text-[10px] text-[#4a3a3a] hover:text-[#ff9b3a] transition-colors"
          >
            None
          </button>
        </div>
      </div>

      {/* Tool grid by phase */}
      <div className="flex-1 overflow-y-auto p-4 space-y-6">
        {Object.entries(byPhase).map(([phase, phaseTools]) => {
          const meta = PHASE_META[phase] || { label: phase, color: "#4a6a7a", bg: "#0a1015" };
          return (
            <div key={phase}>
              <div className="flex items-center gap-2 mb-3">
                <div
                  className="w-2 h-2 rounded-full"
                  style={{ background: meta.color }}
                />
                <span
                  className="text-[10px] font-bold tracking-[0.2em] uppercase"
                  style={{ color: meta.color }}
                >
                  {meta.label}
                </span>
                <span className="text-[10px] text-[#2a4a5a]">
                  — {phaseTools.length} tools
                </span>
                <div className="flex-1 h-px bg-[#1a2a32] ml-2" />
              </div>

              <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-2">
                {phaseTools.map(tool => (
                  <ToolCard
                    key={tool.id}
                    tool={tool}
                    isSelected={selected.has(tool.id)}
                    onToggle={() => toggleTool(tool.id)}
                    onInfo={() => setInfoTool(tool)}
                    onRun={() => runSingle(tool.id)}
                    meta={meta}
                  />
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Info popup */}
      {infoTool && (
        <ToolInfoPopup
          tool={infoTool}
          onClose={() => setInfoTool(null)}
          copiedCmd={copiedCmd}
          onCopy={copyInstall}
        />
      )}
    </div>
  );
}

// Individual tool card
function ToolCard({
  tool, isSelected, onToggle, onInfo, onRun, meta,
}: {
  tool: Tool;
  isSelected: boolean;
  onToggle: () => void;
  onInfo: () => void;
  onRun: () => void;
  meta: { color: string; bg: string };
}) {
  const roi = ROI_LABEL[tool.roi] || ROI_LABEL[2];

  return (
    <div
      className={cn(
        "group relative rounded-lg border p-3 cursor-pointer",
        "transition-all duration-150",
        isSelected
          ? "border-current/40 bg-current/5"
          : "border-[#1a2a32] bg-[#0a1015] hover:border-[#2a4a5a]"
      )}
      style={{ color: isSelected ? meta.color : undefined }}
      onClick={onToggle}
    >
      {/* Checkbox */}
      <div className="flex items-start justify-between mb-2">
        <div
          className={cn(
            "w-4 h-4 rounded border flex items-center justify-center flex-shrink-0",
            "transition-all duration-150",
            isSelected
              ? "border-current bg-current"
              : "border-[#2a4a5a] group-hover:border-[#4a8a9a]"
          )}
        >
          {isSelected && (
            <Check size={10} className="text-[#080c0e]" strokeWidth={3} />
          )}
        </div>

        <div className="flex items-center gap-1">
          {/* ROI badge */}
          <span
            className="text-[9px] font-bold px-1.5 py-0.5 rounded border"
            style={{
              color: roi.color,
              borderColor: roi.color + "40",
              background: roi.color + "10",
            }}
          >
            {roi.label}
          </span>
        </div>
      </div>

      {/* Tool name + description */}
      <div className="text-xs font-bold text-[#c8d8e0] mb-0.5 group-hover:text-white">
        {tool.name}
      </div>
      <div className="text-[10px] text-[#2a5a6a] leading-relaxed line-clamp-2">
        {tool.description}
      </div>

      {/* Tags */}
      <div className="flex flex-wrap gap-1 mt-2">
        {tool.tags.slice(0, 3).map(tag => (
          <span
            key={tag}
            className="text-[9px] px-1 py-0.5 rounded bg-[#0a1820] border border-[#1a2a32] text-[#2a5a6a]"
          >
            {tag}
          </span>
        ))}
      </div>

      {/* Hover actions */}
      <div
        className={cn(
          "absolute top-2 right-2 flex gap-1",
          "opacity-0 group-hover:opacity-100 transition-opacity duration-150"
        )}
        onClick={e => e.stopPropagation()}
      >
        <button
          onClick={onInfo}
          className="p-1 rounded bg-[#0a1820] border border-[#1a2a32] text-[#4a8a9a] hover:text-[#00e5cc] transition-colors"
          title="Tool info + install"
        >
          <Info size={11} />
        </button>
        <button
          onClick={onRun}
          className="p-1 rounded bg-[#0a1820] border border-[#1a2a32] text-[#4a8a9a] hover:text-[#00e5cc] transition-colors"
          title="Run this tool now"
        >
          <Play size={11} />
        </button>
      </div>
    </div>
  );
}

// Tool info popup
function ToolInfoPopup({
  tool, onClose, copiedCmd, onCopy,
}: {
  tool: Tool;
  onClose: () => void;
  copiedCmd: string | null;
  onCopy: (cmd: string, id: string) => void;
}) {
  const roi = ROI_LABEL[tool.roi] || ROI_LABEL[2];
  const meta = PHASE_META[tool.phase] || { color: "#4a6a7a" };

  return (
    <div
      className="fixed inset-0 z-40 flex items-center justify-center bg-black/60"
      onClick={onClose}
    >
      <div
        className="w-full max-w-md mx-4 bg-[#0a1015] border border-[#1a2a32] rounded-xl overflow-hidden shadow-2xl"
        onClick={e => e.stopPropagation()}
      >
        <div className="flex items-center gap-3 px-5 py-3 border-b border-[#1a2a32] bg-[#080c0e]">
          <span className="text-sm font-bold text-[#c8d8e0]">{tool.name}</span>
          <span
            className="text-[10px] font-bold px-2 py-0.5 rounded border"
            style={{ color: roi.color, borderColor: roi.color + "40", background: roi.color + "10" }}
          >
            ROI: {roi.label}
          </span>
          <span
            className="text-[10px] font-semibold ml-auto"
            style={{ color: meta.color }}
          >
            {tool.phase.toUpperCase()}
          </span>
          <button onClick={onClose} className="text-[#2a5a6a] hover:text-[#ff3a5c] ml-2">
            <Info size={14} />
          </button>
        </div>

        <div className="p-5 space-y-4">
          <p className="text-xs text-[#8ab4c4] leading-relaxed">{tool.description}</p>

          {/* Install command */}
          <div>
            <div className="text-[10px] text-[#4a6a7a] tracking-widest mb-1.5">INSTALL</div>
            <div className="relative">
              <pre className="text-[11px] text-[#00e5cc] bg-[#080c0e] border border-[#1a2a32] rounded-lg p-3 overflow-x-auto whitespace-pre-wrap break-all font-mono">
                {tool.install_cmd}
              </pre>
              <button
                onClick={() => onCopy(tool.install_cmd, tool.id)}
                className="absolute top-2 right-2 text-[10px] px-2 py-1 rounded border border-[#1a2a32] text-[#2a5a6a] hover:text-[#00e5cc] transition-colors"
              >
                {copiedCmd === tool.id ? "Copied!" : "Copy"}
              </button>
            </div>
          </div>

          {/* Key flags */}
          {tool.flags?.length > 0 && (
            <div>
              <div className="text-[10px] text-[#4a6a7a] tracking-widest mb-1.5">KEY FLAGS</div>
              <div className="space-y-1">
                {tool.flags.slice(0, 6).map(f => (
                  <div key={f.name} className="flex items-baseline gap-2 text-[11px]">
                    <code className="text-[#7c6aff] font-mono">{f.name}</code>
                    <span className="text-[#2a5a6a]">{f.description}</span>
                    {f.default && (
                      <span className="text-[#1a4a3a] ml-auto">default: {f.default}</span>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Parallel execution badge */}
          <div className="flex items-center gap-3 text-[10px]">
            <span
              className={cn(
                "px-2 py-1 rounded border",
                tool.parallel
                  ? "border-[#1a4a3a] text-[#2a9a7a] bg-[#0a1f19]"
                  : "border-[#4a3a1a] text-[#9a7a2a] bg-[#1f1a0a]"
              )}
            >
              {tool.parallel ? "⚡ Parallel safe" : "⏱ Serial execution"}
            </span>
            <span className="border border-[#1a2a32] px-2 py-1 rounded text-[#2a5a6a]">
              Timeout: {tool.timeout || 300}s
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}
