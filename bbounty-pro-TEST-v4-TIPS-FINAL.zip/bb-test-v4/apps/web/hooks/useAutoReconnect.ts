"use client";
import { useEffect, useRef, useState, useCallback } from "react";

// Item #21: WebSocket auto-reconnect with exponential backoff.
//
// LIMITATION: In-memory only. Doesn't sync state across tabs.
// If you reload the page during a scan, history is lost (use SWR for events).

export type WSStatus = "connecting" | "open" | "closing" | "closed" | "error";

export interface UseAutoReconnectOptions {
  url: string | null;
  protocols?: string | string[];
  onMessage?: (data: any) => void;
  onOpen?: () => void;
  onClose?: () => void;
  maxRetries?: number;
  initialDelay?: number;
}

export function useAutoReconnect(opts: UseAutoReconnectOptions) {
  const [status, setStatus] = useState<WSStatus>("closed");
  const [attempts, setAttempts] = useState(0);
  const wsRef = useRef<WebSocket | null>(null);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const maxRetries = opts.maxRetries ?? 10;
  const initialDelay = opts.initialDelay ?? 1000;

  const connect = useCallback(() => {
    if (!opts.url) return;
    if (wsRef.current?.readyState === WebSocket.OPEN) return;

    setStatus("connecting");
    const ws = new WebSocket(opts.url, opts.protocols);
    wsRef.current = ws;

    ws.onopen = () => {
      setStatus("open");
      setAttempts(0);
      opts.onOpen?.();
    };

    ws.onmessage = (event) => {
      try {
        const data = typeof event.data === "string"
          ? JSON.parse(event.data)
          : event.data; // ArrayBuffer/Blob
        opts.onMessage?.(data);
      } catch {
        opts.onMessage?.(event.data);
      }
    };

    ws.onerror = () => setStatus("error");

    ws.onclose = () => {
      setStatus("closed");
      opts.onClose?.();
      if (attempts < maxRetries) {
        // Exponential backoff: 1s, 2s, 4s, 8s, ... capped at 30s
        const delay = Math.min(initialDelay * 2 ** attempts, 30000);
        timerRef.current = setTimeout(() => {
          setAttempts(a => a + 1);
          connect();
        }, delay);
      }
    };
  }, [opts.url, attempts, maxRetries, initialDelay]);

  const disconnect = useCallback(() => {
    if (timerRef.current) clearTimeout(timerRef.current);
    if (wsRef.current) {
      setStatus("closing");
      wsRef.current.close();
    }
  }, []);

  const send = useCallback((data: string | ArrayBuffer | Blob) => {
    if (wsRef.current?.readyState === WebSocket.OPEN) {
      wsRef.current.send(data);
      return true;
    }
    return false;
  }, []);

  useEffect(() => {
    connect();
    return () => {
      if (timerRef.current) clearTimeout(timerRef.current);
      wsRef.current?.close();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [opts.url]);

  return { status, attempts, send, disconnect, reconnect: connect };
}
