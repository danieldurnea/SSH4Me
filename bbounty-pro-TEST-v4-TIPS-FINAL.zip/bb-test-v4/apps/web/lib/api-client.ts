// BBounty Pro — API client (no-auth mode)

export class APIError extends Error {
  constructor(message: string, public status: number) {
    super(message);
    this.name = "APIError";
  }
}

class APIClient {
  async request<T>(path: string, init: RequestInit = {}): Promise<T> {
    const res = await fetch(path, {
      ...init,
      headers: {
        "Content-Type": "application/json",
        "X-Request-ID": typeof crypto !== "undefined" ? crypto.randomUUID() : "",
        ...(init.headers ?? {}),
      },
    });

    if (!res.ok) {
      const body = await res.json().catch(() => ({}));
      throw new APIError((body as any).error ?? `HTTP ${res.status}`, res.status);
    }
    if (res.status === 204) return undefined as T;
    return res.json();
  }

  get<T>(path: string)              { return this.request<T>(path, { method: "GET" }); }
  delete<T>(path: string)           { return this.request<T>(path, { method: "DELETE" }); }
  post<T>(path: string, body?: unknown) {
    return this.request<T>(path, { method: "POST", body: body ? JSON.stringify(body) : undefined });
  }
  put<T>(path: string, body?: unknown) {
    return this.request<T>(path, { method: "PUT", body: body ? JSON.stringify(body) : undefined });
  }
}

export const api = new APIClient();

export const scanAPI = {
  start: (data: unknown)   => api.post<{ scan_id: string; ws_url: string }>("/api/v1/scan/start", data),
  stop:  (scanID: string)  => api.post(`/api/v1/scan/stop?scan_id=${scanID}`),
  pause: (scanID: string)  => api.post(`/api/v1/scan/pause?scan_id=${scanID}`),
  status:(scanID: string)  => api.get(`/api/v1/scan/status/${scanID}`),
};

export const findingsAPI = {
  list:   (scanID: string)          => api.get<unknown[]>(`/api/v1/findings/${scanID}`),
  create: (data: unknown)           => api.post("/api/v1/findings", data),
  update: (id: string, d: unknown)  => api.put(`/api/v1/findings/${id}`, d),
  delete: (id: string)              => api.delete(`/api/v1/findings/${id}`),
  analyze:(id: string)              => api.post(`/api/v1/findings/${id}/analyze`),
  exportMarkdown: (scanID: string)  => `/api/v1/findings/${scanID}/export?format=markdown`,
  exportJSON:     (scanID: string)  => `/api/v1/findings/${scanID}/export?format=json`,
};

export const skillsAPI = {
  list: ()                                 => api.get<unknown[]>("/api/v1/skills"),
  get:  (id: string)                       => api.get(`/api/v1/skills/${id}`),
  execute:(id: string, target: string)     => api.post(`/api/v1/skills/${id}/execute`, { target }),
};

export const roeAPI = {
  validate: (data: unknown) => api.post("/api/v1/roe/validate", data),
};

export const aiAPI = {
  chat:         (data: unknown) => api.post("/api/v1/ai/chat", data),
  reportReview: (data: unknown) => api.post("/api/v1/ai/report-review", data),
};
