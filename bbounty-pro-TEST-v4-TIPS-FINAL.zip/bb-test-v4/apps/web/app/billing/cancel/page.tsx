"use client";

import { useRouter } from "next/navigation";
import { XCircle, ArrowLeft, RotateCcw } from "lucide-react";

export default function BillingCancelPage() {
  const router = useRouter();

  return (
    <div className="min-h-screen bg-[#080c0e] flex items-center justify-center p-6">
      <div
        className="max-w-md w-full rounded-xl border p-8 text-center"
        style={{ background: "#0c1820", borderColor: "#ff3a5c44" }}
      >
        {/* Icon */}
        <div
          className="w-16 h-16 rounded-full flex items-center justify-center mx-auto mb-6"
          style={{ background: "#ff3a5c11" }}
        >
          <XCircle size={32} style={{ color: "#ff3a5c" }} />
        </div>

        {/* Title */}
        <h1 className="font-mono font-black text-2xl tracking-widest mb-2" style={{ color: "#ff3a5c" }}>
          CANCELLED
        </h1>
        <p className="font-mono text-sm text-[#4a6a7a] mb-8">
          Payment was not completed. Your current plan is unchanged.
        </p>

        {/* Actions */}
        <div className="flex flex-col gap-3">
          <button
            onClick={() => router.push("/billing")}
            className="flex items-center justify-center gap-2 w-full py-3 rounded font-mono text-sm font-bold tracking-widest transition-all"
            style={{ background: "#00e5cc", color: "#080c0e" }}
          >
            <RotateCcw size={14} />
            TRY AGAIN
          </button>
          <button
            onClick={() => router.push("/")}
            className="flex items-center justify-center gap-2 w-full py-3 rounded font-mono text-sm font-bold tracking-widest border transition-colors hover:bg-[#1a2a32]"
            style={{ borderColor: "#1a2a32", color: "#4a6a7a" }}
          >
            <ArrowLeft size={14} />
            BACK TO DASHBOARD
          </button>
        </div>
      </div>
    </div>
  );
}
