# BBounty Pro v3.3 — Known Issues & Architectural Debt

## Fixed in this build (v3.3-zen)

| # | Bug | Where | Fix |
|---|-----|-------|-----|
| 1 | `PasswordHash json:"-"` → all logins fail | `auth/manager.go` | Renamed tag, added `redact()` helper, all HTTP handlers sanitise |
| 2 | Unused imports break compile | `tools/registry.go`, `skills/registry.go`, `agent/checkpoint.go` | Removed |
| 3 | `_ = redis.Nil` dead shim + unused redis import | `findings/postgres_sync.go` | Removed |
| 4 | Phantom `@radix-ui/react-badge` dep | `web/package.json` | Removed |
| 5 | JSX in `.ts` file | `hooks/useAuth.ts` | Renamed to `.tsx` |
| 6 | `ScanRequest`, `ScanStartResponse` missing from shared-types | `packages/shared-types/index.ts` | Added |
| 7 | `store.ts` missing interface methods + implicit `any` params | `lib/store.ts` | Full typed rewrite |
| 8 | `target` interpolated into bash without validation | `tools/executor.go` | Added `SafeTarget()` + `SafeScope()` strict validators |
| 9 | `ScopeFilter` passed unsanitised scope entries | `tools/executor.go` | Uses `SafeScope()` now; CIDR entries skipped gracefully |
| 10 | `phases[].runFn` field never read | `agent/pipeline.go` | Removed dead field |
| 11 | `parseStats()` defined, never called | `agent/pipeline.go` | Removed |
| 12 | `os.MkdirAll` error silently ignored | `agent/pipeline.go` | Now logged + falls back to `/tmp` |
| 13 | Pipeline skipped on empty `BuildCommand` | `agent/pipeline.go` | Now broadcasts `tool_skipped` event |
| 14 | `filterOutputsInScope` wired into pipeline loop | `agent/pipeline.go` | Now runs `roe.Gate.CheckURL` on tool output files between phases |
| 15 | `roe.CheckURL` / `FilterURLs` defined but never called | `roe/recheck.go` | Now wired via `filterOutputsInScope` |
| 16 | `checkRefreshRate` defined but never wired | `auth/refresh_limit.go` | Wired into `Refresh()` |
| 17 | `GenerateInvite` ignores `rand.Read` error | `auth/manager.go` | Error now propagates |
| 18 | CSRF `rand.Read` error silently ignored | `auth/cookies.go` | Now returns 500 instead of issuing weak token |
| 19 | `ws.CheckOrigin` always returns true | `ws/hub.go` | Restricted to `FRONTEND_URL` env var; falls back to localhost |
| 20 | `aiEnrichAsync` comment/doc misleading | `priority/scorer.go` | Clarified |
| 21 | CSS `*.d.ts` missing | `web/types/css.d.ts` | Added — fixes `tsc --noEmit` for xterm CSS dynamic import |

## Remaining architectural debt (not fixed — documented)

### Partially-implemented modules (wired for compilation, not wired into main.go)

These modules exist and compile but are **not started** by `cmd/server/main.go`.
They need explicit wiring if you want them active:

| Module | What it does | Wire-up needed |
|--------|-------------|----------------|
| `internal/auditlog` | Redis pub/sub → Postgres audit trail | `go logger.Run(ctx)` in main.go; pass `pgxpool` |
| `internal/health` | `/livez` + `/readyz` probes | Mount `checker.HandleLive` + `checker.HandleReady` routes |
| `internal/metrics` | Prometheus-compatible `/metrics` endpoint | Mount `metrics.HandleMetrics` route |
| `internal/notify` | Slack/Discord/Telegram webhooks | `notify.New()` in main.go; call from diff engine |
| `internal/findings/postgres_sync.go` | Redis → Postgres sync loop | `go syncer.Run(ctx)` in main.go |
| `internal/findings/stream.go` | SSE stream of findings | Mount `stream.Handle` route |
| `internal/auth/cookies.go` | HttpOnly cookie auth | Use `MiddlewareWithCookies` instead of `Middleware` |
| `internal/agent/checkpoint.go` | Redis-backed scan resume | Call `checkpointStore.Save()` on each phase transition |
| `internal/ai/fallback.go` | Cache-backed AI fallback | Use `NewCachedClient(primary, cache)` instead of raw `Client` |
| `internal/ai/zen_proxy.go` | HTTP → Python AI proxy | Used by ZenProxy routes; wire in main.go if desired |
| `internal/config/constants.go` | Centralised TTL constants | Replace magic numbers in other packages |

### Adaptive rate-limiter is still effectively dead

`internal/ratelimit/adaptive.go` has a Token Bucket + stats collector, but the
pipeline shells out to bash and never observes HTTP response codes. The adaptive
back-off logic can't fire. To fix properly:

- Replace the bash executor with an HTTP-aware tool runner (e.g. httpx output
  is already JSONL — parse status codes from it).
- Call `RecordResponse(host, statusCode)` when 429 is seen in httpx output.
- Currently the limiter is constructed in main.go but `RecordResponse` is never
  called from the pipeline.

### `internal/tools/durnea_framework.go`

474 lines of static methodology metadata with zero importers. Compile-clean
dead code. Can be deleted unless you plan to use it for UI display.

### auth TOCTOU race on first-user promotion

`isFirstUser()` does a non-atomic check-then-set. Under concurrent first
registration (very unlikely on a private VPS), two users could simultaneously
become admin. Low priority for private deployments.

### PostgreSQL is optional but sync is not automatic

If you provide `DATABASE_URL`, findings are stored in Redis **and** Postgres.
But `PostgresSync.Run()` must be started manually in main.go. Without it,
Postgres stays empty even if the pool connects.

## VPS first-run checklist

```
# 1. Copy env template
cp .env.example .env
# Edit: ANTHROPIC_API_KEY, JWT_SECRET (>=32 chars), FRONTEND_URL, REDIS_URL

# 2. Start infra
docker compose up -d postgres redis

# 3. Build orchestrator
cd apps/orchestrator && go build -o ../../dist/orchestrator ./cmd/server
# (Requires Go 1.23+)

# 4. Build frontend
cd apps/web && npm install && npm run build

# 5. Start AI proxy
cd apps/ai-proxy && pip install -r requirements.txt && uvicorn main:app --port 8001

# 6. Start orchestrator
./dist/orchestrator

# 7. Start frontend
cd apps/web && npm start
```

## Environment variables

| Variable | Default | Required |
|----------|---------|----------|
| `ANTHROPIC_API_KEY` | — | Yes (AI proxy) |
| `JWT_SECRET` | — | Yes (≥32 chars) |
| `REDIS_URL` | `redis://localhost:6379` | Yes |
| `DATABASE_URL` | — | No (Redis-only mode if absent) |
| `FRONTEND_URL` | `http://localhost:3000` | Recommended (WS origin check) |
| `AI_PROXY_URL` | `http://ai-proxy:8001` | Yes for AI features |
| `ANTHROPIC_MODEL` | `claude-sonnet-4-5` | No |
| `ENV` | `development` | Set to `production` for Secure cookies |
| `PORT` | `8080` | No |
