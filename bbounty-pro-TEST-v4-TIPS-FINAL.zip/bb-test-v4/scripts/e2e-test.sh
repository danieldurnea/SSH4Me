#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════════
#  BBounty Pro v3.3-zen — End-to-End Test Script
#
#  Target: testphp.vulnweb.com (authorized test target by Acunetix)
#  Profile: quick (6-9 min total)
#
#  Run AFTER preflight-check.sh passes.
#  Usage: bash scripts/e2e-test.sh
#
#  What this validates:
#  1. Orchestrator accepts and processes a scan request
#  2. All Phase 1 tools execute without crashing
#  3. Findings are stored in Redis
#  4. AI proxy analyzes at least one finding
#  5. WebSocket events broadcast correctly
#  6. Scan completes with status "done"
# ═══════════════════════════════════════════════════════════════════════════════

set -euo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

TARGET="testphp.vulnweb.com"
PROFILE="quick"
API="http://127.0.0.1:${PORT:-8080}/api/v1"
MAX_WAIT=600  # 10 minutes max for quick profile

PASS=0; FAIL=0

ok()   { echo -e "${GREEN}  ✓${NC} $*"; ((PASS++)); }
fail() { echo -e "${RED}  ✗${NC} $*"; ((FAIL++)); }
step() { echo -e "\n${BOLD}${CYAN}━━━ $* ━━━${NC}"; }
info() { echo -e "  ${CYAN}→${NC} $*"; }

echo -e "${BOLD}${GREEN}"
echo "  ██████╗ ██████╗  ██████╗ "
echo "  ██╔══██╗██╔══██╗██╔═══██╗"
echo "  ██████╔╝██████╔╝██║   ██║"
echo "  ██╔══██╗██╔══██╗██║   ██║"
echo "  ██████╔╝██████╔╝╚██████╔╝"
echo "  ╚═════╝ ╚═════╝  ╚═════╝ "
echo -e "${NC}"
echo -e "  ${BOLD}End-to-End Test | Target: $TARGET | Profile: $PROFILE${NC}"
echo -e "  ${YELLOW}Authorized test target (Acunetix)${NC}"
echo ""

# ── STEP 1: Platform health ───────────────────────────────────────────────────
step "Platform Health"

# Orchestrator health
HTTP_CODE=$(curl -sf --max-time 5 -o /dev/null -w '%{http_code}' "$API/../health" 2>/dev/null || echo "000")
[[ "$HTTP_CODE" == "200" ]] && ok "Orchestrator: /health → 200" || fail "Orchestrator not responding (HTTP $HTTP_CODE)"

# Redis
redis-cli ping 2>/dev/null | grep -q PONG && ok "Redis: OK" || fail "Redis: not responding"

# AI proxy
AI_CODE=$(curl -sf --max-time 5 -o /dev/null -w '%{http_code}' "http://127.0.0.1:${AI_PORT:-8081}/health" 2>/dev/null || echo "000")
[[ "$AI_CODE" == "200" ]] && ok "AI proxy: OK" || fail "AI proxy not responding"

# ── STEP 2: Auth flow ─────────────────────────────────────────────────────────
step "Auth Flow"

# Register test user (may already exist)
REG=$(curl -sf --max-time 5 -X POST "$API/../auth/register" \
    -H "Content-Type: application/json" \
    -d '{"username":"e2e_test","password":"TestPass123!","email":"e2e@test.local"}' \
    2>/dev/null || echo "{}")
info "Register: $(echo $REG | jq -r '.error // "ok"' 2>/dev/null)"

# Login
LOGIN=$(curl -sf --max-time 5 -X POST "$API/../auth/login" \
    -H "Content-Type: application/json" \
    -d '{"username":"e2e_test","password":"TestPass123!"}' \
    -c /tmp/bbounty_e2e_cookies.txt \
    2>/dev/null || echo "{}")

if echo "$LOGIN" | grep -q "access_token\|user"; then
    ok "Login: successful"
    TOKEN=$(echo "$LOGIN" | jq -r '.access_token // ""' 2>/dev/null)
else
    fail "Login: failed — response: $LOGIN"
    TOKEN=""
fi

AUTH_HEADER="Authorization: Bearer $TOKEN"

# ── STEP 3: ROE validation ────────────────────────────────────────────────────
step "ROE Gate"

# Valid target — should pass
ROE=$(curl -sf --max-time 5 -X POST "$API/roe/validate" \
    -H "Content-Type: application/json" \
    -H "$AUTH_HEADER" \
    -d "{\"target\":\"$TARGET\",\"scope\":[\"$TARGET\"],\"platform\":\"bugcrowd\"}" \
    2>/dev/null || echo "{}")
echo "$ROE" | grep -qi "valid\|ok\|true" && ok "ROE: $TARGET → VALID" || \
    info "ROE: $ROE"

# Dangerous target — should fail
BLOCKED=$(curl -sf --max-time 5 -X POST "$API/roe/validate" \
    -H "Content-Type: application/json" \
    -H "$AUTH_HEADER" \
    -d '{"target":"google.com","scope":["testphp.vulnweb.com"]}' \
    2>/dev/null || echo "{}")
echo "$BLOCKED" | grep -qi "invalid\|out.*scope\|false" && ok "ROE: out-of-scope → BLOCKED" || \
    fail "ROE: should have blocked google.com"

# Shell injection — should fail
INJECT=$(curl -sf --max-time 5 -X POST "$API/roe/validate" \
    -H "Content-Type: application/json" \
    -H "$AUTH_HEADER" \
    -d '{"target":"testphp.vulnweb.com; rm -rf /","scope":["testphp.vulnweb.com"]}' \
    2>/dev/null || echo "{}")
echo "$INJECT" | grep -qi "invalid\|rejected\|error" && ok "ROE: injection → BLOCKED" || \
    fail "ROE: should have blocked shell injection"

# ── STEP 4: Start scan ────────────────────────────────────────────────────────
step "Scan Execution"

info "Starting scan: $TARGET with profile=$PROFILE"
START=$(curl -sf --max-time 10 -X POST "$API/scans/start" \
    -H "Content-Type: application/json" \
    -H "$AUTH_HEADER" \
    -d "{\"target\":\"$TARGET\",\"profile\":\"$PROFILE\",\"scope\":[\"$TARGET\"],\"platform\":\"bugcrowd\"}" \
    2>/dev/null || echo "{}")

SCAN_ID=$(echo "$START" | jq -r '.scan_id // ""' 2>/dev/null)

if [[ -n "$SCAN_ID" ]] && [[ "$SCAN_ID" != "null" ]]; then
    ok "Scan started: $SCAN_ID"
else
    fail "Scan failed to start: $START"
    echo -e "\n${RED}Cannot continue without scan ID.${NC}"
    exit 1
fi

# ── STEP 5: Monitor scan progress ────────────────────────────────────────────
step "Scan Progress (max ${MAX_WAIT}s)"

START_TIME=$(date +%s)
LAST_PHASE=""
LAST_STATUS=""

while true; do
    NOW=$(date +%s)
    ELAPSED=$((NOW - START_TIME))

    if [[ $ELAPSED -gt $MAX_WAIT ]]; then
        fail "Scan timeout after ${MAX_WAIT}s"
        break
    fi

    STATUS=$(curl -sf --max-time 5 "$API/scans/$SCAN_ID" \
        -H "$AUTH_HEADER" 2>/dev/null || echo "{}")

    PHASE=$(echo "$STATUS"  | jq -r '.phase  // "?"' 2>/dev/null)
    STATE=$(echo "$STATUS"  | jq -r '.status // "?"' 2>/dev/null)
    VULNS=$(echo "$STATUS"  | jq -r '.stats.vulns // 0' 2>/dev/null)
    SUBS=$(echo  "$STATUS"  | jq -r '.stats.subs  // 0' 2>/dev/null)
    LIVE=$(echo  "$STATUS"  | jq -r '.stats.live  // 0' 2>/dev/null)

    if [[ "$PHASE" != "$LAST_PHASE" ]] || [[ "$STATE" != "$LAST_STATUS" ]]; then
        info "[${ELAPSED}s] Phase=$PHASE Status=$STATE Subs=$SUBS Live=$LIVE Findings=$VULNS"
        LAST_PHASE="$PHASE"
        LAST_STATUS="$STATE"
    fi

    if [[ "$STATE" == "done" ]]; then
        ok "Scan completed in ${ELAPSED}s"
        FINAL_VULNS=$VULNS
        FINAL_SUBS=$SUBS
        FINAL_LIVE=$LIVE
        break
    fi

    if [[ "$STATE" == "error" ]] || [[ "$STATE" == "dead" ]]; then
        fail "Scan ended with status: $STATE"
        break
    fi

    sleep 5
done

# ── STEP 6: Validate findings ─────────────────────────────────────────────────
step "Findings Validation"

FINDINGS=$(curl -sf --max-time 5 "$API/findings/$SCAN_ID" \
    -H "$AUTH_HEADER" 2>/dev/null || echo "[]")

FINDING_COUNT=$(echo "$FINDINGS" | jq 'length' 2>/dev/null || echo 0)

info "Total findings: $FINDING_COUNT"
info "Subdomains: $FINAL_SUBS | Live hosts: $FINAL_LIVE | Vulns: $FINAL_VULNS"

[[ $FINAL_SUBS -gt 0 ]]    && ok "Subdomains discovered: $FINAL_SUBS" || fail "No subdomains found"
[[ $FINAL_LIVE -gt 0 ]]    && ok "Live hosts confirmed: $FINAL_LIVE"  || fail "No live hosts found"
[[ $FINDING_COUNT -ge 0 ]] && ok "Findings store: $FINDING_COUNT findings" || fail "Findings store error"

# testphp.vulnweb.com should have known vulnerabilities
if [[ $FINDING_COUNT -gt 0 ]]; then
    ok "Vulnerability detection: $FINDING_COUNT findings"
    echo "$FINDINGS" | jq -r '.[] | "    → [\(.severity)] \(.title)"' 2>/dev/null | head -10
else
    fail "Expected vulnerabilities on testphp.vulnweb.com — 0 found (check nuclei templates)"
fi

# ── STEP 7: CORS engine validation ───────────────────────────────────────────
step "CORS Engine"

CORS_RESULT=$(curl -sf --max-time 30 \
    "$API/cors/scan?url=http://testphp.vulnweb.com" \
    -H "$AUTH_HEADER" 2>/dev/null || echo "{}")

CORS_COUNT=$(echo "$CORS_RESULT" | jq '.findings | length' 2>/dev/null || echo 0)
info "CORS findings: $CORS_COUNT"
[[ $CORS_COUNT -ge 0 ]] && ok "CORS engine: responded correctly" || fail "CORS engine error"

# ── STEP 8: Diff engine ───────────────────────────────────────────────────────
step "Diff Engine"

DIFF=$(curl -sf --max-time 5 "$API/diff/latest?target=$TARGET" \
    -H "$AUTH_HEADER" 2>/dev/null || echo "{}")
echo "$DIFF" | jq -e '.scan_id // .target' &>/dev/null && \
    ok "Diff engine: snapshot saved" || \
    info "Diff engine: first scan (no previous snapshot)"

# ── STEP 9: Cleanup ───────────────────────────────────────────────────────────
step "Cleanup"

rm -f /tmp/bbounty_e2e_cookies.txt
ok "Test artifacts cleaned up"

# ── SUMMARY ───────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${GREEN}══════════════════════════════════════════════${NC}"
echo -e "${BOLD}  BBounty Pro — E2E Test Results${NC}"
echo -e "${BOLD}${GREEN}══════════════════════════════════════════════${NC}"
echo ""
echo -e "  ${GREEN}✓ PASS: $PASS${NC}"
echo -e "  ${RED}✗ FAIL: $FAIL${NC}"
echo ""

if [[ $FAIL -eq 0 ]]; then
    echo -e "  ${GREEN}${BOLD}✓ Platform ready for production!${NC}"
    echo -e "  Scan completed: $FINAL_SUBS subs | $FINAL_LIVE live | $FINDING_COUNT findings"
    exit 0
else
    echo -e "  ${RED}${BOLD}✗ $FAIL checks failed — review before launch.${NC}"
    exit 1
fi
