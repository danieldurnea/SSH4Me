#!/usr/bin/env bash
# BBounty Pro — Fix Failed Tools
# Instalează toolurile care au eșuat la prima instalare
# Rulare: sudo bash scripts/fix-failed-tools.sh
set -euo pipefail

GRN='\033[0;32m'; YEL='\033[1;33m'; RED='\033[0;31m'; CYN='\033[0;36m'; NC='\033[0m'
ok()   { echo -e "${GRN}✓${NC} $1"; }
warn() { echo -e "${YEL}⚠${NC} $1"; }
fail() { echo -e "${RED}✗${NC} $1"; }
hdr()  { echo -e "\n${CYN}━━ $1 ━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"; }

echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo "  BBounty Pro — Fix Failed Tools"
echo "  Ubuntu 22.04 / 24.04"
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"

hdr "Python packages"
pip3 install --break-system-packages \
    fastapi==0.115.5 uvicorn[standard]==0.32.1 \
    google-generativeai==0.8.3 pydantic==2.10.3 \
    paramspider ppmap leaksearch \
    graphql-cop graphw00f \
    2>/dev/null && ok "Python packages" || warn "Unele pachete au eșuat"

hdr "trufflehog"
if ! command -v trufflehog &>/dev/null; then
    curl -sSfL https://raw.githubusercontent.com/trufflesecurity/trufflehog/main/scripts/install.sh \
        | sh -s -- -b /usr/local/bin 2>/dev/null && ok "trufflehog" || \
    go install github.com/trufflesecurity/trufflehog/v3@latest 2>/dev/null && ok "trufflehog (go)" || fail "trufflehog"
else ok "trufflehog (deja instalat)"; fi

hdr "ghauri"
if ! command -v ghauri &>/dev/null; then
    pip3 install ghauri --break-system-packages 2>/dev/null && ok "ghauri" || \
    (git clone https://github.com/r0oth3x49/ghauri.git /opt/ghauri 2>/dev/null && \
     pip3 install -r /opt/ghauri/requirements.txt --break-system-packages 2>/dev/null && \
     ln -sf /opt/ghauri/ghauri.py /usr/local/bin/ghauri && ok "ghauri (git)" || fail "ghauri")
else ok "ghauri (deja instalat)"; fi

hdr "ssrfmap"
if [[ ! -d /opt/ssrfmap ]]; then
    git clone https://github.com/swisskyrepo/SSRFmap.git /opt/ssrfmap 2>/dev/null && \
    pip3 install -r /opt/ssrfmap/requirements.txt --break-system-packages 2>/dev/null && \
    ln -sf /opt/ssrfmap/ssrfmap.py /usr/local/bin/ssrfmap && ok "ssrfmap" || fail "ssrfmap"
else ok "ssrfmap (deja instalat)"; fi

hdr "jwt-tool"
if [[ ! -d /opt/jwt_tool ]]; then
    git clone https://github.com/ticarpi/jwt_tool.git /opt/jwt_tool 2>/dev/null && \
    pip3 install -r /opt/jwt_tool/requirements.txt --break-system-packages 2>/dev/null && \
    ln -sf /opt/jwt_tool/jwt_tool.py /usr/local/bin/jwt-tool && \
    chmod +x /usr/local/bin/jwt-tool && ok "jwt-tool" || fail "jwt-tool"
else ok "jwt-tool (deja instalat)"; fi

hdr "whatweb"
command -v whatweb &>/dev/null && ok "whatweb (deja instalat)" || \
    (apt-get install -y whatweb 2>/dev/null && ok "whatweb" || \
     gem install whatweb 2>/dev/null && ok "whatweb (gem)" || fail "whatweb")

hdr "nomore403"
command -v nomore403 &>/dev/null && ok "nomore403 (deja instalat)" || \
    go install github.com/devploit/nomore403@latest 2>/dev/null && ok "nomore403" || fail "nomore403"

hdr "openredirex"
command -v openredirex &>/dev/null && ok "openredirex (deja instalat)" || \
    (pip3 install openredirex --break-system-packages 2>/dev/null && ok "openredirex" || \
     go install github.com/devanshbatham/openredirex@latest 2>/dev/null && ok "openredirex (go)" || fail "openredirex")

hdr "mantra"
command -v mantra &>/dev/null && ok "mantra (deja instalat)" || \
    go install github.com/MrEmpy/mantra@latest 2>/dev/null && ok "mantra" || warn "mantra: opțional"

hdr "metagoofil"
command -v metagoofil &>/dev/null && ok "metagoofil (deja instalat)" || \
    (pip3 install metagoofil --break-system-packages 2>/dev/null && ok "metagoofil" || \
     apt-get install -y metagoofil 2>/dev/null && ok "metagoofil (apt)" || warn "metagoofil: opțional")

hdr "orchestrator (build)"
ORCH_DIR="$(pwd)/apps/orchestrator"
if [[ -d "$ORCH_DIR" ]]; then
    cd "$ORCH_DIR"
    go build -o orchestrator ./cmd/server 2>/dev/null && ok "orchestrator compilat" || \
    fail "orchestrator: verifică Go instalat (go version)"
    cd - >/dev/null
else
    warn "Rulează din directorul bb-test: cd ~/bb-test && sudo bash scripts/fix-failed-tools.sh"
fi

echo ""
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
echo -e "${GRN}Fix complet!${NC} Verificare rapidă:"
for t in trufflehog ghauri whatweb nomore403 openredirex; do
    command -v "$t" &>/dev/null && echo -e "  ${GRN}✓${NC} $t" || echo -e "  ${RED}✗${NC} $t"
done
echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
