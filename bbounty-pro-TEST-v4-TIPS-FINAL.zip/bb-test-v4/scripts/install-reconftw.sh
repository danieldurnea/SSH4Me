#!/usr/bin/env bash
# BBounty Pro — reconFTW Integration Installer
# Installs reconFTW and configures it to work with the BBounty Pro orchestrator.
#
# Usage: sudo bash scripts/install-reconftw.sh
# Run AFTER install-ubuntu.sh

set -euo pipefail
GREEN='\033[0;32m'; CYAN='\033[0;36m'; YELLOW='\033[1;33m'; NC='\033[0m'
log_ok()   { echo -e "${GREEN}[✓]${NC} $*"; }
log_info() { echo -e "${CYAN}[*]${NC} $*"; }
log_warn() { echo -e "${YELLOW}[!]${NC} $*"; }

[[ $EUID -ne 0 ]] && { echo "Run as root: sudo bash scripts/install-reconftw.sh"; exit 1; }

INSTALL_DIR="/opt/bbounty-pro"
RECONFTW_DIR="/opt/reconftw"
ENV_FILE="$INSTALL_DIR/.env"

log_info "Installing reconFTW + dependencies..."

# Clone reconFTW
if [[ -d "$RECONFTW_DIR" ]]; then
    log_info "reconFTW exists — pulling latest..."
    git -C "$RECONFTW_DIR" pull -q 2>/dev/null || true
else
    git clone --depth 1 https://github.com/six2dez/reconftw.git "$RECONFTW_DIR"
    log_ok "reconFTW cloned → $RECONFTW_DIR"
fi

# Run reconFTW's own installer
cd "$RECONFTW_DIR"
log_info "Running reconFTW install.sh (may take 10-15 min)..."
bash install.sh 2>&1 | tail -20
log_ok "reconFTW installed"

# Create symlink to PATH
ln -sf "$RECONFTW_DIR/reconftw.sh" /usr/local/bin/reconftw
chmod +x /usr/local/bin/reconftw
log_ok "reconftw → /usr/local/bin/reconftw"

# Configure reconFTW output to a standard location
RECONFTW_OUTPUT="/opt/reconftw-output"
mkdir -p "$RECONFTW_OUTPUT"
chown bbounty:bbounty "$RECONFTW_OUTPUT" 2>/dev/null || true

# Update reconFTW config to use standard output dir
RECONFTW_CFG="$RECONFTW_DIR/reconftw.cfg"
if [[ -f "$RECONFTW_CFG" ]]; then
    sed -i "s|^RECONFTW_OUTPUT=.*|RECONFTW_OUTPUT=\"$RECONFTW_OUTPUT\"|" "$RECONFTW_CFG" 2>/dev/null || true
    log_ok "reconFTW output dir → $RECONFTW_OUTPUT"
fi

# Wire RECONFTW_OUTPUT into BBounty Pro .env
if [[ -f "$ENV_FILE" ]]; then
    if grep -q "^RECONFTW_OUTPUT=" "$ENV_FILE"; then
        sed -i "s|^RECONFTW_OUTPUT=.*|RECONFTW_OUTPUT=$RECONFTW_OUTPUT|" "$ENV_FILE"
    else
        echo "RECONFTW_OUTPUT=$RECONFTW_OUTPUT" >> "$ENV_FILE"
    fi
    log_ok "RECONFTW_OUTPUT=$RECONFTW_OUTPUT → .env"
else
    log_warn ".env not found at $ENV_FILE — set RECONFTW_OUTPUT manually"
fi

# Test reconFTW is accessible
if command -v reconftw &>/dev/null; then
    log_ok "reconftw binary: $(which reconftw)"
else
    log_warn "reconftw not in PATH — check /usr/local/bin/"
fi

echo ""
echo -e "${GREEN}reconFTW integration complete!${NC}"
echo ""
echo "  To use in BBounty Pro:"
echo "  1. Select profile: reconftw-deep"
echo "  2. reconFTW runs first (recon phase, ~30-60 min)"
echo "  3. Output feeds into conditional chaining automatically"
echo ""
echo "  Manual test:"
echo "    reconftw -d example.com -r --deep -o $RECONFTW_OUTPUT/example.com"
echo ""
echo "  reconFTW output dir: $RECONFTW_OUTPUT"
