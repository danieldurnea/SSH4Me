#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# BBounty Pro — Daily Recon & Monitoring
# Adapted from: danieldurnea/BugBounty/scripts/automation/daily-recon.sh
#               danieldurnea/BugBounty/scripts/automation/monitor.sh
# Pattern: AI runs overnight, human reviews in morning (docs/workflow.md)
# Usage: ./daily-recon.sh <domain> OR cron: 0 2 * * * /path/daily-recon.sh target.com
# ─────────────────────────────────────────────────────────────────────────────
set -euo pipefail

DOMAIN="${1:?Usage: $0 <domain>}"
BASE_DIR="$HOME/pentesting/$DOMAIN"
PREV_DIR=$(ls -dt "$BASE_DIR/recon-"* 2>/dev/null | head -2 | tail -1)  # second most recent
TODAY_DIR="$BASE_DIR/recon-$(date +%Y%m%d_%H%M%S)"
ORCHESTRATOR="${ORCHESTRATOR:-http://localhost:8080}"
NOTIFY_WEBHOOK="${NOTIFY_WEBHOOK:-}"  # Slack/Discord webhook URL

mkdir -p "$TODAY_DIR"

GREEN='\033[0;32m'; CYAN='\033[0;36m'; YELLOW='\033[1;33m'; NC='\033[0m'; BOLD='\033[1m'
log() { echo -e "[$(date +%H:%M:%S)] $1" | tee -a "$TODAY_DIR/daily.log"; }
notify() {
    [[ -z "$NOTIFY_WEBHOOK" ]] && return
    curl -sf -X POST "$NOTIFY_WEBHOOK" \
        -H "Content-Type: application/json" \
        -d "{\"text\":\"[BBounty Pro] $DOMAIN: $1\"}" &>/dev/null & true
}

# ─────────────────────────────────────────────────────────────────────────────
# Run the full recon pipeline
# ─────────────────────────────────────────────────────────────────────────────
log "Starting daily recon for $DOMAIN"
notify "Daily recon started 🎯"

OUTDIR="$TODAY_DIR" SCAN_ID="daily-$(date +%Y%m%d)" \
    bash "$(dirname "$0")/recon-pipeline.sh" "$DOMAIN"

# ─────────────────────────────────────────────────────────────────────────────
# DELTA DETECTION — What's new since yesterday?
# (danieldurnea monitor.sh pattern, enhanced)
# ─────────────────────────────────────────────────────────────────────────────
log "Running delta detection..."

DELTA_FILE="$TODAY_DIR/delta.txt"
echo "# Delta Report — $DOMAIN — $(date)" > "$DELTA_FILE"
echo "" >> "$DELTA_FILE"

if [[ -n "$PREV_DIR" && -d "$PREV_DIR" ]]; then
    # New subdomains
    if [[ -f "$TODAY_DIR/subs_resolved.txt" && -f "$PREV_DIR/subs_resolved.txt" ]]; then
        NEW_SUBS=$(comm -23 \
            <(sort "$TODAY_DIR/subs_resolved.txt") \
            <(sort "$PREV_DIR/subs_resolved.txt"))
        NEW_SUBS_COUNT=$(echo "$NEW_SUBS" | grep -c . 2>/dev/null || echo 0)
        
        echo "## New Subdomains ($NEW_SUBS_COUNT)" >> "$DELTA_FILE"
        echo "$NEW_SUBS" >> "$DELTA_FILE"
        
        if [[ $NEW_SUBS_COUNT -gt 0 ]]; then
            log "🆕 $NEW_SUBS_COUNT new subdomains found!"
            notify "$NEW_SUBS_COUNT new subdomains discovered!"
            
            # Immediately probe new subs
            echo "$NEW_SUBS" > "$TODAY_DIR/subs_new.txt"
            httpx -l "$TODAY_DIR/subs_new.txt" -silent -json -o "$TODAY_DIR/alive_new.json" \
                -rate-limit 100 2>/dev/null || true
            
            # Quick nuclei scan on new hosts
            jq -r '.url' "$TODAY_DIR/alive_new.json" 2>/dev/null > "$TODAY_DIR/alive_new_urls.txt" || true
            if [[ -s "$TODAY_DIR/alive_new_urls.txt" ]]; then
                log "Scanning new hosts with nuclei..."
                nuclei -l "$TODAY_DIR/alive_new_urls.txt" \
                    -severity critical,high \
                    -rate-limit 30 \
                    -json-export "$TODAY_DIR/vulns/nuclei_new_hosts.json" \
                    -silent 2>/dev/null || true
            fi
        fi
    fi

    # New URLs
    if [[ -f "$TODAY_DIR/urls_all.txt" && -f "$PREV_DIR/urls_all.txt" ]]; then
        NEW_URLS=$(comm -23 \
            <(sort "$TODAY_DIR/urls_all.txt") \
            <(sort "$PREV_DIR/urls_all.txt") | wc -l)
        echo "" >> "$DELTA_FILE"
        echo "## New URLs: $NEW_URLS" >> "$DELTA_FILE"
        [[ $NEW_URLS -gt 100 ]] && notify "$NEW_URLS new URLs discovered"
    fi

    # New vulnerabilities
    if [[ -f "$TODAY_DIR/vulns/nuclei_critical.json" ]]; then
        NEW_VULNS=$(jq -s 'length' "$TODAY_DIR/vulns/nuclei_critical.json" 2>/dev/null || echo 0)
        echo "" >> "$DELTA_FILE"
        echo "## Critical/High Findings: $NEW_VULNS" >> "$DELTA_FILE"
        
        if [[ $NEW_VULNS -gt 0 ]]; then
            log "🚨 $NEW_VULNS critical/high findings!"
            notify "🚨 ALERT: $NEW_VULNS critical/high findings on $DOMAIN!"
            
            # Extract finding details for notification
            jq -r '.info.name + " — " + .host' "$TODAY_DIR/vulns/nuclei_critical.json" 2>/dev/null \
                | head -10 >> "$DELTA_FILE" || true
        fi
    fi
else
    log "No previous scan found — this is the baseline"
    echo "## Baseline scan (no previous data for comparison)" >> "$DELTA_FILE"
fi

# ─────────────────────────────────────────────────────────────────────────────
# MORNING BRIEFING (danieldurnea workflow.md pattern)
# ─────────────────────────────────────────────────────────────────────────────
BRIEFING="$TODAY_DIR/morning_briefing.md"
cat > "$BRIEFING" << BRIEF_EOF
# Morning Briefing — $DOMAIN — $(date +%Y-%m-%d)

## 🎯 Overnight Scan Results

### Stats
- **New Subdomains:** $(grep -c . "$TODAY_DIR/subs_new.txt" 2>/dev/null || echo 0)
- **Live Hosts:** $(wc -l < "$TODAY_DIR/alive_urls.txt" 2>/dev/null || echo 0)
- **Total URLs:** $(wc -l < "$TODAY_DIR/urls_all.txt" 2>/dev/null || echo 0)
- **Critical Findings:** $(jq -s 'length' "$TODAY_DIR/vulns/nuclei_critical.json" 2>/dev/null || echo 0)

## 📋 Recommended Actions (Priority Order)

### Immediate (do first)
$(jq -r '"- [ ] Test: " + .info.name + " on " + .host' "$TODAY_DIR/vulns/nuclei_critical.json" 2>/dev/null | head -5 || echo "- [ ] No critical findings — check medium")

### Today's Focus
- [ ] Review delta: $TODAY_DIR/delta.txt
- [ ] Test XSS candidates: gf_xss.txt ($(wc -l < "$TODAY_DIR/gf_xss.txt" 2>/dev/null || echo 0) URLs)
- [ ] Test SQLi candidates: gf_sqli.txt ($(wc -l < "$TODAY_DIR/gf_sqli.txt" 2>/dev/null || echo 0) URLs)
- [ ] Check non-standard ports in ports/ports.json
- [ ] Manual test on new subdomains

### This Week
- [ ] Business logic testing on high-value endpoints
- [ ] Parameter fuzzing with arjun results
- [ ] Check JS secrets: js/js_secrets.txt
- [ ] API endpoint discovery with kiterunner

## 📁 Output Directory
\`$TODAY_DIR\`

## 🤖 AI Assist
Ask the agent: "Analyze $TODAY_DIR/vulns/nuclei_critical.json and prioritize by impact"
BRIEF_EOF

log "Morning briefing written: $BRIEFING"

# Push briefing to orchestrator for AI review
if command -v curl &>/dev/null; then
    curl -sf -X POST "$ORCHESTRATOR/api/v1/ai/chat" \
        -H "Content-Type: application/json" \
        -d "{\"preset\":\"recon_analysis\",\"messages\":[{\"role\":\"user\",\"content\":\"Daily recon complete for $DOMAIN. Stats: $(cat $TODAY_DIR/summary.txt | head -20 | tr '\n' ' ')\"}]}" \
        -o "$TODAY_DIR/ai_analysis.json" 2>/dev/null || true
fi

notify "Daily recon complete! 📊 Check $BRIEFING"
log "✅ Daily recon complete: $TODAY_DIR"

# ─────────────────────────────────────────────────────────────────────────────
# CONTINUOUS MONITOR (danieldurnea monitor.sh — run every 6h via cron)
# ─────────────────────────────────────────────────────────────────────────────
# To enable continuous monitoring, add to crontab:
#   0 */6 * * * /opt/bbounty-pro/scripts/daily-recon.sh TARGET.COM 2>&1 | tee -a /var/log/bbounty.log
# Or run the monitor loop:
if [[ "${CONTINUOUS:-false}" == "true" ]]; then
    log "Continuous monitor mode — sleeping 6h, then re-running..."
    sleep 21600
    exec "$0" "$DOMAIN"
fi
