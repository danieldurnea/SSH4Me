#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════════
#  BBounty Pro v3.3-zen — Kali Linux Native Installer
#  Non-blocking: every tool install is independent — one failure ≠ abort.
#
#  Usage: sudo bash scripts/install-kali-native.sh
#
#  Advantages on Kali:
#    - Most tools already in apt (nikto, sqlmap, hydra, nmap, whatweb, wpscan...)
#    - Kali metapackages checked first → skip if installed
#    - Same 70-tool registry as Ubuntu, adapted for Kali repos
#
#  Languages: Go 1.23 · Python 3 + pipx · Node 20 LTS · Ruby (system) · Rust · Java 17
#  Tested: Kali Linux 2024.x (amd64)
# ═══════════════════════════════════════════════════════════════════════════════

set -uo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

FAILED=(); SKIPPED=()
log_ok()   { echo -e "${GREEN}  ✓${NC} $*"; }
log_warn() { echo -e "${YELLOW}  ⚠${NC} $*"; }
log_info() { echo -e "${CYAN}  →${NC} $*"; }
step()     { echo -e "\n${BOLD}${CYAN}[STEP]${NC} ${BOLD}$*${NC}"; }
fail_t()   { FAILED+=("$1"); log_warn "$1 failed — continuing"; }
skip_t()   { SKIPPED+=("$1"); }

[[ $EUID -ne 0 ]] && { echo "Run as root: sudo bash $0"; exit 1; }

# Detect Kali
if ! grep -qi kali /etc/os-release 2>/dev/null; then
    echo -e "${YELLOW}Warning: This script is optimized for Kali Linux.${NC}"
    echo -e "For Ubuntu/Debian, use: ${CYAN}sudo bash scripts/install-ubuntu.sh${NC}"
    read -rp "Continue anyway? [y/N] " ans
    [[ "${ans,,}" == "y" ]] || exit 0
fi

INSTALL_DIR="/opt/bbounty-pro"
TOOLS_DIR="/opt/bbounty-tools"
BB_USER="bbounty"
GO_VERSION="1.26.0"
NODE_VERSION="22"

mkdir -p "$TOOLS_DIR/bin" "$TOOLS_DIR/src" "$TOOLS_DIR/wordlists"
export PATH="$TOOLS_DIR/bin:/usr/local/go/bin:$PATH"

LOG="/var/log/bbounty-install-kali.log"
mkdir -p /var/log
exec > >(tee -a "$LOG") 2>&1
echo "=== Kali install started: $(date) ==="

# ── STEP 1: System + Kali repo tools ─────────────────────────────────────────
step "System packages + Kali native tools"
apt-get update -qq 2>/dev/null

DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
    build-essential git curl wget unzip zip jq ca-certificates gnupg \
    libssl-dev libffi-dev libpcap-dev libpq-dev \
    python3 python3-pip python3-venv python3-dev python3-full \
    ruby ruby-dev ruby-bundler \
    redis-server postgresql postgresql-client \
    ufw fail2ban 2>/dev/null || log_warn "Some apt packages failed"

# ── Kali has these pre-packaged — check before installing ────────────────────
KALI_TOOLS=(
    nmap masscan nikto sqlmap hydra john hashcat
    whatweb wafw00f wpscan
    dnsrecon dnsenum dnsutils whois
    dirb gobuster dirbuster
    netcat-traditional curl wget
    metasploit-framework
    zaproxy
    wordlists
    jq xmlstarlet
)
echo ""
log_info "Checking Kali native tools..."
for t in "${KALI_TOOLS[@]}"; do
    if dpkg -s "$t" &>/dev/null; then
        skip_t "$t"
    else
        apt-get install -y -qq "$t" 2>/dev/null && \
            log_ok "$t" || log_warn "$t not in apt (will try other methods)"
    fi
done

# chromium for headless
apt-get install -y -qq chromium 2>/dev/null || \
    apt-get install -y -qq chromium-browser 2>/dev/null || true

log_ok "System + Kali tools"

# ── STEP 2: Language runtimes ─────────────────────────────────────────────────
step "Language runtimes"

# Go
if ! /usr/local/go/bin/go version 2>/dev/null | grep -q "$GO_VERSION"; then
    log_info "Installing Go $GO_VERSION..."
    ARCH=$(dpkg --print-architecture)
    curl -fsSL "https://go.dev/dl/go${GO_VERSION}.linux-${ARCH}.tar.gz" \
        -o /tmp/go.tar.gz 2>/dev/null && \
        rm -rf /usr/local/go && \
        tar -C /usr/local -xzf /tmp/go.tar.gz && \
        rm -f /tmp/go.tar.gz && \
        log_ok "Go $GO_VERSION" || fail_t "Go"
else
    log_ok "Go (already installed)"
fi
export PATH="/usr/local/go/bin:$PATH"
echo 'export PATH="/usr/local/go/bin:/opt/bbounty-tools/bin:$HOME/.local/bin:$PATH"' \
    > /etc/profile.d/bbounty.sh

# Python pipx
python3 -m pip install --quiet pipx --break-system-packages 2>/dev/null || \
    apt-get install -y -qq pipx 2>/dev/null || true
python3 -m pipx ensurepath 2>/dev/null || true
export PATH="$HOME/.local/bin:$PATH"
log_ok "Python 3 + pipx"

# Node.js
if ! node --version 2>/dev/null | grep -q "^v${NODE_VERSION}"; then
    curl -fsSL "https://deb.nodesource.com/setup_${NODE_VERSION}.x" \
        | bash - 2>/dev/null && \
        apt-get install -y -qq nodejs 2>/dev/null && \
        log_ok "Node.js $(node --version)" || fail_t "Node.js"
else
    log_ok "Node.js $(node --version)"
fi

# Rust
if ! command -v cargo &>/dev/null; then
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | \
        sh -s -- -y --no-modify-path --quiet 2>/dev/null
    source "$HOME/.cargo/env" 2>/dev/null && log_ok "Rust" || fail_t "Rust"
else
    source "$HOME/.cargo/env" 2>/dev/null || true
    log_ok "Rust (already installed)"
fi
export PATH="$HOME/.cargo/bin:$PATH"

# Java 17
if ! java -version 2>&1 | grep -qE "17|21"; then
    apt-get install -y -qq openjdk-17-jre-headless 2>/dev/null && \
        log_ok "Java 17" || log_warn "Java 17 not installed"
else
    log_ok "Java (already installed)"
fi

# Start services
systemctl enable redis-server postgresql &>/dev/null 2>&1 || true
systemctl start  redis-server postgresql  2>/dev/null || true

# ── STEP 3: Go tools ──────────────────────────────────────────────────────────
step "Go security tools"

go_install() {
    local pkg="$1" name="${2:-$(basename "${pkg%%@*}" | sed 's|cmd/||')}"
    command -v "$name" &>/dev/null && { skip_t "$name"; return 0; }
    log_info "go install $name..."
    GOBIN="$TOOLS_DIR/bin" /usr/local/go/bin/go install \
        -ldflags="-s -w" "$pkg" 2>/dev/null && \
        log_ok "$name" || fail_t "$name"
}

go_install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest     subfinder
go_install github.com/tomnomnom/assetfinder@latest                            assetfinder
go_install github.com/projectdiscovery/dnsx/cmd/dnsx@latest                  dnsx
go_install github.com/d3mondev/puredns/v2@latest                              puredns
go_install github.com/projectdiscovery/alterx/cmd/alterx@latest              alterx
go_install github.com/projectdiscovery/chaos-client/cmd/chaos@latest         chaos
go_install github.com/projectdiscovery/katana/cmd/katana@latest              katana
go_install github.com/hakluke/hakrawler@latest                                hakrawler
go_install github.com/jaeles-project/gospider@latest                         gospider
go_install github.com/zricethezav/gitleaks/v8@latest                         gitleaks
go_install github.com/trufflesecurity/trufflehog/v3@latest                   trufflehog
go_install github.com/projectdiscovery/httpx/cmd/httpx@latest                httpx
go_install github.com/projectdiscovery/naabu/v2/cmd/naabu@latest             naabu
go_install github.com/lc/gau/v2/cmd/gau@latest                               gau
go_install github.com/tomnomnom/waybackurls@latest                            waybackurls
go_install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest           nuclei
go_install github.com/hahwul/dalfox/v2@latest                                dalfox
go_install github.com/ffuf/ffuf/v2@latest                                     ffuf
go_install github.com/dwisiswant0/crlfuzz/cmd/crlfuzz@latest                 crlfuzz
go_install github.com/zan8in/afrog/v3/cmd/afrog@latest                       afrog
go_install github.com/tomnomnom/gf@latest                                     gf
go_install github.com/Emoe/kxss@latest                                        kxss
go_install github.com/tomnomnom/anew@latest                                   anew
go_install github.com/tomnomnom/unfurl@latest                                 unfurl
go_install github.com/LukaSikic/subzy@latest                                  subzy
go_install github.com/haccer/subjack@latest                                   subjack
# OOB + Notify (NEW)
go_install github.com/projectdiscovery/interactsh/cmd/interactsh-client@latest interactsh-client
go_install github.com/projectdiscovery/notify/cmd/notify@latest               notify
go_install github.com/projectdiscovery/mapcidr/cmd/mapcidr@latest            mapcidr
go_install github.com/projectdiscovery/shuffledns/cmd/shuffledns@latest      shuffledns

ln -sf "$TOOLS_DIR/bin/"* /usr/local/bin/ 2>/dev/null || true
log_ok "Go tools complete"

# ── STEP 4: Python tools ──────────────────────────────────────────────────────
step "Python tools (pipx isolated venvs)"

pipx_install() {
    local pkg="$1" name="${2:-$1}"
    python3 -m pipx install --force "$pkg" 2>/dev/null && \
        { log_ok "$name (pipx)"; return 0; }
    pip3 install --quiet --break-system-packages "$pkg" 2>/dev/null && \
        { log_ok "$name (pip3)"; return 0; }
    fail_t "$name"
}
pip3_req() {
    local pkg="$1" name="${2:-$1}"
    pip3 install --quiet --break-system-packages "$pkg" 2>/dev/null && \
        log_ok "$name" || fail_t "$name"
}

# Kali may already have these via apt — skip if present
command -v wafw00f  &>/dev/null || pipx_install wafw00f
command -v arjun    &>/dev/null || pipx_install arjun
command -v sqlmap   &>/dev/null || pipx_install sqlmap

pipx_install bbot
pipx_install theHarvester         theHarvester
pipx_install dirsearch
pip3_req     emailfinder
pip3_req     metagoofil
pip3_req     porch-pirate          porch-pirate
pip3_req     swaggerspy
pip3_req     graphw00f
pip3_req     graphql-cop           graphql-cop
pip3_req     ghauri
pip3_req     ssrfmap               ssrfmap
pip3_req     openredirex           openredirex
pip3_req     corscanner
pip3_req     jwt_tool              jwt-tool
pip3_req     bountyplz             bountyplz  # NEW
pip3_req     paramspider    paramspider
pip3_req     leaksearch     leaksearch
pip3_req     ppmap          ppmap
pip3_req     shodan
pip3_req     censys
pip3_req     fastapi
pip3_req     "uvicorn[standard]"   uvicorn
pip3_req     anthropic
pip3_req     "google-generativeai" google-generativeai
pip3_req     pydantic
pip3_req     python-dotenv
pip3_req     httpx
log_ok "Python tools complete"

# ── STEP 5: Rust tools ────────────────────────────────────────────────────────
step "Rust tools (feroxbuster)"

command -v feroxbuster &>/dev/null && { skip_t "feroxbuster"; } || {
    if command -v cargo &>/dev/null; then
        cargo install feroxbuster --quiet 2>/dev/null && \
            cp "$HOME/.cargo/bin/feroxbuster" "$TOOLS_DIR/bin/" 2>/dev/null && \
            log_ok "feroxbuster" || fail_t "feroxbuster"
    else
        curl -fsSL "https://github.com/epi052/feroxbuster/releases/latest/download/x86-64-linux-feroxbuster.zip" \
            -o /tmp/fero.zip 2>/dev/null && \
            unzip -q -o /tmp/fero.zip feroxbuster -d "$TOOLS_DIR/bin/" 2>/dev/null && \
            chmod +x "$TOOLS_DIR/bin/feroxbuster" && \
            log_ok "feroxbuster (binary)" || fail_t "feroxbuster"
        rm -f /tmp/fero.zip
    fi
}

# ── STEP 6: Git tools + SecLists ─────────────────────────────────────────────
step "Git-cloned tools"

git_clone() {
    local repo="$1" name="$2" setup="${3:-}"
    local dest="$TOOLS_DIR/src/$name"
    [[ -d "$dest" ]] && { git -C "$dest" pull -q 2>/dev/null || true; } || \
        git clone --depth 1 --quiet "$repo" "$dest" 2>/dev/null || \
        { fail_t "$name"; return; }
    [[ -n "$setup" ]] && (cd "$dest" && eval "$setup" 2>/dev/null || true)
    log_ok "$name"
}

git_clone https://github.com/1ndianl33t/Gf-Patterns.git Gf-Patterns \
    "mkdir -p ~/.gf && cp *.json ~/.gf/ 2>/dev/null || true"

# Kali has SecLists at /usr/share/seclists — symlink if available
if [[ -d /usr/share/seclists ]]; then
    ln -sf /usr/share/seclists "$TOOLS_DIR/wordlists/SecLists" 2>/dev/null
    log_ok "SecLists (Kali native at /usr/share/seclists)"
else
    git_clone https://github.com/danielmiessler/SecLists.git SecLists "" &
    SECLISTS_PID=$!
fi

git_clone https://github.com/s0md3v/XSStrike.git XSStrike \
    "pip3 install -r requirements.txt --break-system-packages -q 2>/dev/null; \
     ln -sf \$PWD/xsstrike.py $TOOLS_DIR/bin/xsstrike 2>/dev/null || true"

# nomore403
git_clone https://github.com/nomore403/nomore403.git nomore403 \
    "go build -o $TOOLS_DIR/bin/nomore403 . 2>/dev/null || true"

# ── STEP 7: Nuclei templates ──────────────────────────────────────────────────
step "Nuclei templates + GF patterns"
command -v nuclei &>/dev/null && \
    nuclei -update-templates -silent 2>/dev/null && \
    log_ok "Nuclei templates" || log_warn "Nuclei template update failed"

mkdir -p ~/.gf
[[ -d "$TOOLS_DIR/src/Gf-Patterns" ]] && \
    cp "$TOOLS_DIR/src/Gf-Patterns"/*.json ~/.gf/ 2>/dev/null || true

# ── STEP 8: BBounty Pro platform ─────────────────────────────────────────────
step "BBounty Pro platform"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$(dirname "$SCRIPT_DIR")"

if [[ -f "$SRC_DIR/apps/orchestrator/go.mod" ]]; then
    id "$BB_USER" &>/dev/null || useradd -r -s /bin/bash -d "$INSTALL_DIR" -m "$BB_USER"
    rsync -a --exclude='.git' --exclude='node_modules' --exclude='.next' \
        "$SRC_DIR/" "$INSTALL_DIR/" 2>/dev/null
    chown -R "$BB_USER:$BB_USER" "$INSTALL_DIR"

    cd "$INSTALL_DIR/apps/orchestrator"
    sudo -u "$BB_USER" /usr/local/go/bin/go build \
        -ldflags="-s -w" -o "$TOOLS_DIR/bin/bbounty-orchestrator" \
        ./cmd/server/main.go 2>/dev/null && \
        log_ok "Orchestrator built" || fail_t "orchestrator"

    AIPROXY_REQS="$INSTALL_DIR/apps/ai-proxy/requirements.txt"
    [[ -f "$AIPROXY_REQS" ]] && \
        pip3 install -r "$AIPROXY_REQS" --break-system-packages -q 2>/dev/null || \
        pip3 install fastapi "uvicorn[standard]" anthropic pydantic python-dotenv \
            --break-system-packages -q 2>/dev/null

    cd "$INSTALL_DIR/apps/web"
    npm install --no-audit --no-fund --loglevel=error 2>/dev/null && \
        log_ok "Frontend" || log_warn "Frontend npm had errors"
    npm install -g pm2 --loglevel=error &>/dev/null && log_ok "pm2" || fail_t "pm2"
fi

# ── STEP 9: Systemd services ──────────────────────────────────────────────────
step "Systemd services"

[[ -d "$INSTALL_DIR/infra/systemd" ]] && {
    cp "$INSTALL_DIR/infra/systemd/nuclei-update.timer"   /etc/systemd/system/ 2>/dev/null || true
    cp "$INSTALL_DIR/infra/systemd/nuclei-update.service" /etc/systemd/system/ 2>/dev/null || true
}

cat > /etc/systemd/system/bbounty-orchestrator.service <<EOF
[Unit]
Description=BBounty Pro Orchestrator
After=network.target redis.service
[Service]
Type=simple
User=$BB_USER
WorkingDirectory=$INSTALL_DIR
ExecStart=$TOOLS_DIR/bin/bbounty-orchestrator
EnvironmentFile=-$INSTALL_DIR/.env
Restart=on-failure
RestartSec=5
[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/bbounty-aiproxy.service <<EOF
[Unit]
Description=BBounty Pro AI Proxy
After=network.target
[Service]
Type=simple
User=$BB_USER
WorkingDirectory=$INSTALL_DIR/apps/ai-proxy
ExecStart=/usr/bin/python3 -m uvicorn main:app --host 127.0.0.1 --port 8001
EnvironmentFile=-$INSTALL_DIR/.env
Restart=on-failure
RestartSec=5
[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable bbounty-orchestrator bbounty-aiproxy 2>/dev/null || true
systemctl enable --now nuclei-update.timer 2>/dev/null && \
    log_ok "Nuclei auto-update timer" || true

# ── STEP 10: Firewall ─────────────────────────────────────────────────────────
step "Firewall"
ufw --force reset &>/dev/null; ufw default deny incoming &>/dev/null
ufw default allow outgoing &>/dev/null; ufw allow ssh &>/dev/null
ufw allow 80/tcp &>/dev/null; ufw allow 443/tcp &>/dev/null
ufw --force enable &>/dev/null && log_ok "UFW"
systemctl enable --now fail2ban 2>/dev/null && log_ok "Fail2Ban" || true

# ── STEP 11: notify + bountyplz config skeletons ────────────────────────────
step "Notify + bountyplz config"
NOTIFY_CFG="$HOME/.config/notify/provider-config.yaml"
mkdir -p "$(dirname "$NOTIFY_CFG")"
[[ -f "$NOTIFY_CFG" ]] || cat > "$NOTIFY_CFG" <<'YAML'
# BBounty Pro — notify provider config
# telegram:
#   - id: "bbounty"
#     telegram_api_key: "YOUR_BOT_TOKEN"
#     telegram_chat_id: "YOUR_CHAT_ID"
#     telegram_format: "{{data}}"
# slack:
#   - id: "bbounty"
#     slack_webhook_url: "https://hooks.slack.com/services/..."
#     slack_format: "{{data}}"
YAML
log_ok "Notify config → $NOTIFY_CFG"

# Wait for SecLists if downloading
[[ -v SECLISTS_PID ]] && wait $SECLISTS_PID 2>/dev/null && \
    log_ok "SecLists downloaded" || true

# ── SUMMARY ───────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${GREEN}══════════════════════════════════════════════${NC}"
echo -e "${BOLD}  BBounty Pro v3.3-zen — Kali Install Done${NC}"
echo -e "${BOLD}${GREEN}══════════════════════════════════════════════${NC}"
echo ""
echo -e "  Tools:     ${CYAN}$TOOLS_DIR/bin${NC}"
echo -e "  Platform:  ${CYAN}$INSTALL_DIR${NC}"
echo -e "  Log:       ${CYAN}$LOG${NC}"
[[ ${#SKIPPED[@]} -gt 0 ]] && \
    echo -e "  Skipped (Kali native): ${CYAN}${#SKIPPED[@]} tools${NC}"
[[ ${#FAILED[@]} -gt 0 ]] && {
    echo -e "  ${YELLOW}Failed (${#FAILED[@]}):${NC}"
    printf '    ✗ %s\n' "${FAILED[@]}"
}
echo ""
echo -e "  ${BOLD}Next steps:${NC}"
echo -e "  1. Edit ${CYAN}$INSTALL_DIR/.env${NC}"
echo -e "  2. Configure ${CYAN}$NOTIFY_CFG${NC}"
echo -e "  3. sudo systemctl start bbounty-orchestrator bbounty-aiproxy"
echo ""
echo -e "  ${GREEN}✓ Authorized testing only 🔐${NC}"
echo ""
echo "=== Kali install finished: $(date) ===" >> "$LOG"
