#!/usr/bin/env bash
# ═══════════════════════════════════════════════════════════════════════════════
#  BBounty Pro v3.3-zen — Ubuntu 22.04 / 24.04 Installer
#  Non-blocking: every tool install is independent — one failure ≠ abort.
#
#  Usage: sudo bash scripts/install-ubuntu.sh
#
#  Languages: Go 1.23 · Python 3 + pipx · Node 20 LTS · Ruby 3 · Rust · Java 17
#  Tools: 70 total (Go + Python + Ruby + Rust + apt + git-cloned)
#  Tested: Ubuntu 22.04 LTS / 24.04 LTS (amd64)
# ═══════════════════════════════════════════════════════════════════════════════

set -uo pipefail

RED='\033[0;31m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'
CYAN='\033[0;36m'; BOLD='\033[1m'; NC='\033[0m'

FAILED=(); SKIPPED=()
log_ok()   { echo -e "${GREEN}  ✓${NC} $*"; }
log_warn() { echo -e "${YELLOW}  ⚠${NC} $*"; }
log_info() { echo -e "${CYAN}  →${NC} $*"; }
step()     { echo -e "\n${BOLD}${CYAN}[STEP]${NC} ${BOLD}$*${NC}"; }
fail_t()   { FAILED+=("$1"); log_warn "$1 failed — continuing"; }
skip_t()   { SKIPPED+=("$1"); }

[[ $EUID -ne 0 ]] && { echo "Run as root: sudo bash $0"; exit 1; }

INSTALL_DIR="/opt/bbounty-pro"
TOOLS_DIR="/opt/bbounty-tools"
BB_USER="bbounty"
GO_VERSION="1.26.0"
NODE_VERSION="22"

mkdir -p "$TOOLS_DIR/bin" "$TOOLS_DIR/src" "$TOOLS_DIR/wordlists"
export PATH="$TOOLS_DIR/bin:/usr/local/go/bin:$PATH"

LOG="/var/log/bbounty-install.log"
mkdir -p /var/log
exec > >(tee -a "$LOG") 2>&1
echo "=== Install started: $(date) ==="

# ── STEP 1: System packages ───────────────────────────────────────────────────
step "System packages"
apt-get update -qq 2>/dev/null
DEBIAN_FRONTEND=noninteractive apt-get install -y -qq \
    build-essential git curl wget unzip zip jq ca-certificates gnupg \
    lsb-release software-properties-common apt-transport-https \
    libssl-dev libffi-dev libpcap-dev libpq-dev \
    nmap masscan dnsutils whois netcat-openbsd \
    nikto hydra john \
    ruby ruby-dev ruby-bundler \
    libxml2-dev libxslt1-dev zlib1g-dev \
    python3 python3-pip python3-venv python3-dev python3-full \
    redis-server postgresql postgresql-client \
    ufw fail2ban 2>/dev/null || log_warn "Some apt packages failed"

# sqlmap from apt (reliable on Ubuntu)
apt-get install -y -qq sqlmap 2>/dev/null && log_ok "sqlmap (apt)" || true

# chromium for headless screenshots
apt-get install -y -qq chromium-browser 2>/dev/null || \
    apt-get install -y -qq chromium 2>/dev/null || \
    log_warn "chromium not available — aquatone/gowitness screenshots disabled"

log_ok "System packages"

# ── STEP 2: Language runtimes ─────────────────────────────────────────────────
step "Language runtimes (Go · Python/pipx · Node · Ruby · Rust · Java)"

# Go
if ! /usr/local/go/bin/go version 2>/dev/null | grep -q "$GO_VERSION"; then
    log_info "Installing Go $GO_VERSION..."
    ARCH=$(dpkg --print-architecture)
    curl -fsSL "https://go.dev/dl/go${GO_VERSION}.linux-${ARCH}.tar.gz" \
        -o /tmp/go.tar.gz 2>/dev/null && \
        rm -rf /usr/local/go && \
        tar -C /usr/local -xzf /tmp/go.tar.gz && \
        rm -f /tmp/go.tar.gz && \
        log_ok "Go $GO_VERSION" || fail_t "Go"
else
    log_ok "Go (already installed)"
fi
export PATH="/usr/local/go/bin:$PATH"
echo 'export PATH="/usr/local/go/bin:/opt/bbounty-tools/bin:$HOME/.local/bin:$PATH"' \
    > /etc/profile.d/bbounty.sh

# Python pipx — isolates each tool in its own venv
# Works on Python 3.11+ / 3.12+ / Ubuntu 23+ without --break-system-packages issues
python3 -m pip install --quiet pipx --break-system-packages 2>/dev/null || \
    pip3 install --quiet pipx 2>/dev/null || \
    apt-get install -y -qq pipx 2>/dev/null || \
    log_warn "pipx not available — will use pip3 --break-system-packages fallback"
python3 -m pipx ensurepath 2>/dev/null || true
export PATH="$HOME/.local/bin:$PATH"
log_ok "Python 3 + pipx"

# Node.js 20 LTS
if ! node --version 2>/dev/null | grep -q "^v${NODE_VERSION}"; then
    log_info "Installing Node.js $NODE_VERSION LTS..."
    curl -fsSL "https://deb.nodesource.com/setup_${NODE_VERSION}.x" \
        | bash - 2>/dev/null && \
        apt-get install -y -qq nodejs 2>/dev/null && \
        log_ok "Node.js $(node --version)" || fail_t "Node.js"
else
    log_ok "Node.js $(node --version)"
fi

# Rust (needed by feroxbuster)
if ! command -v cargo &>/dev/null; then
    log_info "Installing Rust..."
    curl --proto '=https' --tlsv1.2 -sSf https://sh.rustup.rs | \
        sh -s -- -y --no-modify-path --quiet 2>/dev/null
    source "$HOME/.cargo/env" 2>/dev/null && log_ok "Rust" || fail_t "Rust"
else
    source "$HOME/.cargo/env" 2>/dev/null || true
    log_ok "Rust (already installed)"
fi
export PATH="$HOME/.cargo/bin:$PATH"

# Java 17 (needed by ZAP)
if ! java -version 2>&1 | grep -qE "17|21"; then
    apt-get install -y -qq openjdk-17-jre-headless 2>/dev/null && \
        log_ok "Java 17" || log_warn "Java 17 not installed — ZAP disabled"
else
    log_ok "Java (already installed)"
fi

# Start services
systemctl enable redis-server postgresql &>/dev/null 2>&1 || true
systemctl start  redis-server postgresql  2>/dev/null || true

# ── STEP 3: Go tools ──────────────────────────────────────────────────────────
step "Go security tools"

go_install() {
    local pkg="$1" name="${2:-$(basename "${pkg%%@*}" | sed 's|cmd/||')}"
    command -v "$name" &>/dev/null && { skip_t "$name"; return 0; }
    log_info "go install $name..."
    GOBIN="$TOOLS_DIR/bin" /usr/local/go/bin/go install \
        -ldflags="-s -w" "$pkg" 2>/dev/null && \
        log_ok "$name" || fail_t "$name"
}

# Recon
go_install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest     subfinder
go_install github.com/tomnomnom/assetfinder@latest                            assetfinder
go_install github.com/projectdiscovery/dnsx/cmd/dnsx@latest                  dnsx
go_install github.com/d3mondev/puredns/v2@latest                              puredns
go_install github.com/projectdiscovery/alterx/cmd/alterx@latest              alterx
go_install github.com/projectdiscovery/chaos-client/cmd/chaos@latest         chaos
go_install github.com/projectdiscovery/katana/cmd/katana@latest              katana
go_install github.com/hakluke/hakrawler@latest                                hakrawler
go_install github.com/jaeles-project/gospider@latest                         gospider
go_install github.com/zricethezav/gitleaks/v8@latest                         gitleaks
go_install github.com/trufflesecurity/trufflehog/v3@latest                   trufflehog

# HTTP / Probing
go_install github.com/projectdiscovery/httpx/cmd/httpx@latest                httpx
go_install github.com/projectdiscovery/naabu/v2/cmd/naabu@latest             naabu
go_install github.com/lc/gau/v2/cmd/gau@latest                               gau
go_install github.com/tomnomnom/waybackurls@latest                            waybackurls
go_install github.com/projectdiscovery/asnmap/cmd/asnmap@latest              asnmap

# Scanning
go_install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest           nuclei
go_install github.com/hahwul/dalfox/v2@latest                                dalfox
go_install github.com/ffuf/ffuf/v2@latest                                     ffuf
go_install github.com/OJ/gobuster/v3@latest                                   gobuster
go_install github.com/dwisiswant0/crlfuzz/cmd/crlfuzz@latest                 crlfuzz
go_install github.com/zan8in/afrog/v3/cmd/afrog@latest                       afrog

# Params / Enum
go_install github.com/tomnomnom/gf@latest                                     gf
go_install github.com/Emoe/kxss@latest                                        kxss
go_install github.com/tomnomnom/qsreplace@latest                              qsreplace
go_install github.com/tomnomnom/anew@latest                                   anew
go_install github.com/tomnomnom/unfurl@latest                                 unfurl

# Takeover
go_install github.com/LukaSikic/subzy@latest                                  subzy
go_install github.com/haccer/subjack@latest                                   subjack

# OOB + Notifications (NEW)
go_install github.com/projectdiscovery/interactsh/cmd/interactsh-client@latest interactsh-client
go_install github.com/projectdiscovery/notify/cmd/notify@latest               notify

# Utilities
go_install github.com/projectdiscovery/mapcidr/cmd/mapcidr@latest            mapcidr
go_install github.com/projectdiscovery/uncover/cmd/uncover@latest            uncover
go_install github.com/projectdiscovery/shuffledns/cmd/shuffledns@latest      shuffledns

ln -sf "$TOOLS_DIR/bin/"* /usr/local/bin/ 2>/dev/null || true
log_ok "Go tools complete"

# ── STEP 4: Python tools via pipx ────────────────────────────────────────────
step "Python tools (pipx isolated venvs)"

# pipx_install: isolated venv per tool — no env conflicts ever
pipx_install() {
    local pkg="$1" name="${2:-$1}"
    log_info "pipx $pkg..."
    python3 -m pipx install --force "$pkg" 2>/dev/null && \
        { log_ok "$name (pipx)"; return 0; }
    # Fallback: pip3 --break-system-packages (Ubuntu 23+/24+ compatible)
    pip3 install --quiet --break-system-packages "$pkg" 2>/dev/null && \
        { log_ok "$name (pip3)"; return 0; }
    fail_t "$name"
}

pip3_req() {
    local pkg="$1" name="${2:-$1}"
    log_info "pip3 $pkg..."
    pip3 install --quiet --break-system-packages "$pkg" 2>/dev/null && \
        log_ok "$name" || fail_t "$name"
}

# OSINT & Recon
pipx_install bbot
pipx_install theHarvester         theHarvester
pip3_req     emailfinder
pip3_req     metagoofil
pip3_req     porch-pirate         porch-pirate
pip3_req     swaggerspy
pip3_req     "msftrecon"          msftrecon

# Web security
pipx_install wafw00f
pipx_install arjun
pipx_install xsstrike              xsstrike
pipx_install dirsearch
pip3_req     graphw00f
pip3_req     graphql-cop           graphql-cop
pip3_req     "ssrfmap"             ssrfmap

# Exploitation
pip3_req     ghauri
pip3_req     corscanner
pip3_req     openredirex           openredirex
pip3_req     "git+https://github.com/MrEmpy/mantra.git" mantra

# JWT
pip3_req     jwt_tool              jwt-tool

# Reporting & Auto-submit (NEW)
pip3_req     bountyplz

# AI proxy stack
pip3_req     fastapi
pip3_req     "uvicorn[standard]"   uvicorn
pip3_req     anthropic
pip3_req     "google-generativeai" google-generativeai
pip3_req     pydantic
pip3_req     python-dotenv
pip3_req     httpx

# Threat intel
pip3_req     paramspider    paramspider
pip3_req     leaksearch     leaksearch
pip3_req     ppmap          ppmap
pip3_req     shodan
pip3_req     censys

log_ok "Python tools complete"

# ── STEP 5: Ruby tools ────────────────────────────────────────────────────────
step "Ruby tools (whatweb · wpscan)"

export GEM_HOME="$TOOLS_DIR/gems"
export GEM_PATH="$TOOLS_DIR/gems"
echo "export GEM_HOME=$TOOLS_DIR/gems" >> /etc/profile.d/bbounty.sh
echo 'export PATH=$GEM_HOME/bin:$PATH'  >> /etc/profile.d/bbounty.sh

gem_install() {
    local g="$1"
    log_info "gem install $g..."
    BUNDLE_IGNORE_FUNDING_REQUESTS=1 \
        gem install "$g" --no-document --quiet 2>/dev/null && \
        log_ok "$g" || fail_t "$g"
}

gem_install whatweb
gem_install wpscan
gem_install bundler

ln -sf "$TOOLS_DIR/gems/bin/whatweb" /usr/local/bin/whatweb 2>/dev/null || true
ln -sf "$TOOLS_DIR/gems/bin/wpscan"  /usr/local/bin/wpscan  2>/dev/null || true
log_ok "Ruby tools complete"

# ── STEP 6: Rust tools ────────────────────────────────────────────────────────
step "Rust tools (feroxbuster)"

if command -v cargo &>/dev/null; then
    log_info "cargo install feroxbuster..."
    cargo install feroxbuster --quiet 2>/dev/null && \
        cp "$HOME/.cargo/bin/feroxbuster" "$TOOLS_DIR/bin/" 2>/dev/null && \
        ln -sf "$TOOLS_DIR/bin/feroxbuster" /usr/local/bin/feroxbuster && \
        log_ok "feroxbuster (Rust)" || fail_t "feroxbuster"
else
    # Binary fallback
    log_info "feroxbuster binary fallback..."
    curl -fsSL "https://github.com/epi052/feroxbuster/releases/latest/download/x86-64-linux-feroxbuster.zip" \
        -o /tmp/fero.zip 2>/dev/null && \
        unzip -q -o /tmp/fero.zip feroxbuster -d "$TOOLS_DIR/bin/" 2>/dev/null && \
        chmod +x "$TOOLS_DIR/bin/feroxbuster" && \
        ln -sf "$TOOLS_DIR/bin/feroxbuster" /usr/local/bin/feroxbuster && \
        log_ok "feroxbuster (binary)" || fail_t "feroxbuster"
    rm -f /tmp/fero.zip
fi

# ── STEP 7: Git-cloned tools ──────────────────────────────────────────────────
step "Git-cloned tools"

git_clone() {
    local repo="$1" name="$2" setup="${3:-}"
    local dest="$TOOLS_DIR/src/$name"
    log_info "Cloning $name..."
    if [[ -d "$dest" ]]; then
        git -C "$dest" pull -q 2>/dev/null || true
    else
        git clone --depth 1 --quiet "$repo" "$dest" 2>/dev/null || \
            { fail_t "$name"; return; }
    fi
    [[ -n "$setup" ]] && (cd "$dest" && eval "$setup" 2>/dev/null || true)
    log_ok "$name"
}

git_clone https://github.com/s0md3v/XSStrike.git XSStrike \
    "pip3 install -r requirements.txt --break-system-packages -q 2>/dev/null; \
     ln -sf \$PWD/xsstrike.py $TOOLS_DIR/bin/xsstrike 2>/dev/null || true"

git_clone https://github.com/1ndianl33t/Gf-Patterns.git Gf-Patterns \
    "mkdir -p ~/.gf && cp *.json ~/.gf/ 2>/dev/null || true"

git_clone https://github.com/danielmiessler/SecLists.git SecLists "" &
SECLISTS_PID=$!

git_clone https://github.com/nomore403/nomore403.git nomore403 \
    "go build -o $TOOLS_DIR/bin/nomore403 . 2>/dev/null || true"

# ── STEP 8: Nuclei templates + GF patterns ───────────────────────────────────
step "Nuclei templates + GF patterns"

command -v nuclei &>/dev/null && \
    nuclei -update-templates -silent 2>/dev/null && \
    log_ok "Nuclei templates" || log_warn "Nuclei template update failed"

mkdir -p ~/.gf
[[ -d "$TOOLS_DIR/src/Gf-Patterns" ]] && \
    cp "$TOOLS_DIR/src/Gf-Patterns"/*.json ~/.gf/ 2>/dev/null || true
log_ok "GF patterns"

# ── STEP 9: BBounty Pro platform ─────────────────────────────────────────────
step "BBounty Pro platform"

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
SRC_DIR="$(dirname "$SCRIPT_DIR")"

if [[ -f "$SRC_DIR/apps/orchestrator/go.mod" ]]; then
    id "$BB_USER" &>/dev/null || useradd -r -s /bin/bash -d "$INSTALL_DIR" -m "$BB_USER"

    rsync -a --exclude='.git' --exclude='node_modules' --exclude='.next' \
        "$SRC_DIR/" "$INSTALL_DIR/" 2>/dev/null
    chown -R "$BB_USER:$BB_USER" "$INSTALL_DIR"

    cd "$INSTALL_DIR/apps/orchestrator"
    log_info "Building orchestrator..."
    sudo -u "$BB_USER" /usr/local/go/bin/go build \
        -ldflags="-s -w" -o "$TOOLS_DIR/bin/bbounty-orchestrator" \
        ./cmd/server/main.go 2>/dev/null && \
        log_ok "Orchestrator built" || fail_t "orchestrator"

    # AI proxy deps
    AIPROXY_REQS="$INSTALL_DIR/apps/ai-proxy/requirements.txt"
    if [[ -f "$AIPROXY_REQS" ]]; then
        pip3 install -r "$AIPROXY_REQS" --break-system-packages -q 2>/dev/null && \
            log_ok "AI proxy requirements" || \
            pip3 install fastapi "uvicorn[standard]" anthropic pydantic python-dotenv \
                --break-system-packages -q 2>/dev/null
    fi

    # Frontend
    cd "$INSTALL_DIR/apps/web"
    npm install --no-audit --no-fund --loglevel=error 2>/dev/null && \
        log_ok "Frontend npm install" || log_warn "Frontend npm had errors"

    npm install -g pm2 --loglevel=error &>/dev/null && log_ok "pm2" || fail_t "pm2"
else
    log_warn "Source not found — run from repo root: sudo bash scripts/install-ubuntu.sh"
fi

# ── STEP 10: Caddy ───────────────────────────────────────────────────────────
step "Caddy (auto-HTTPS)"
if ! command -v caddy &>/dev/null; then
    curl -fsSL 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' \
        | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg 2>/dev/null
    echo "deb [signed-by=/usr/share/keyrings/caddy-stable-archive-keyring.gpg] \
https://dl.cloudsmith.io/public/caddy/stable/deb/debian any-version main" \
        > /etc/apt/sources.list.d/caddy-stable.list
    apt-get update -qq && apt-get install -y -qq caddy 2>/dev/null && \
        log_ok "Caddy" || fail_t "Caddy"
else
    log_ok "Caddy (already installed)"
fi

# ── STEP 11: Systemd services + timers ───────────────────────────────────────
step "Systemd services"

# Nuclei auto-update timer
if [[ -d "$INSTALL_DIR/infra/systemd" ]]; then
    cp "$INSTALL_DIR/infra/systemd/nuclei-update.timer"   /etc/systemd/system/ 2>/dev/null || true
    cp "$INSTALL_DIR/infra/systemd/nuclei-update.service" /etc/systemd/system/ 2>/dev/null || true
fi

cat > /etc/systemd/system/bbounty-orchestrator.service <<EOF
[Unit]
Description=BBounty Pro Orchestrator
After=network.target redis.service postgresql.service
[Service]
Type=simple
User=$BB_USER
WorkingDirectory=$INSTALL_DIR
ExecStart=$TOOLS_DIR/bin/bbounty-orchestrator
EnvironmentFile=-$INSTALL_DIR/.env
Restart=on-failure
RestartSec=5
[Install]
WantedBy=multi-user.target
EOF

cat > /etc/systemd/system/bbounty-aiproxy.service <<EOF
[Unit]
Description=BBounty Pro AI Proxy
After=network.target
[Service]
Type=simple
User=$BB_USER
WorkingDirectory=$INSTALL_DIR/apps/ai-proxy
ExecStart=/usr/bin/python3 -m uvicorn main:app --host 127.0.0.1 --port 8001
EnvironmentFile=-$INSTALL_DIR/.env
Restart=on-failure
RestartSec=5
[Install]
WantedBy=multi-user.target
EOF

systemctl daemon-reload
systemctl enable bbounty-orchestrator bbounty-aiproxy 2>/dev/null || true
systemctl enable --now nuclei-update.timer 2>/dev/null && \
    log_ok "Nuclei auto-update timer (daily 04:00 UTC)" || true
log_ok "Systemd services configured"

# ── STEP 12: Firewall ─────────────────────────────────────────────────────────
step "Firewall (UFW + Fail2Ban)"
ufw --force reset &>/dev/null
ufw default deny incoming &>/dev/null; ufw default allow outgoing &>/dev/null
ufw allow ssh &>/dev/null; ufw allow 80/tcp &>/dev/null; ufw allow 443/tcp &>/dev/null
ufw --force enable &>/dev/null && log_ok "UFW"
systemctl enable --now fail2ban 2>/dev/null && log_ok "Fail2Ban" || true

# ── STEP 13: notify config skeleton ──────────────────────────────────────────
step "Notify config (Telegram/Slack/Discord)"
NOTIFY_CFG="$HOME/.config/notify/provider-config.yaml"
mkdir -p "$(dirname "$NOTIFY_CFG")"
[[ -f "$NOTIFY_CFG" ]] || cat > "$NOTIFY_CFG" <<'YAML'
# BBounty Pro — notify provider config
# Uncomment + fill the provider you want.

# telegram:
#   - id: "bbounty"
#     telegram_api_key: "YOUR_BOT_TOKEN"
#     telegram_chat_id: "YOUR_CHAT_ID"
#     telegram_format: "{{data}}"

# slack:
#   - id: "bbounty"
#     slack_webhook_url: "https://hooks.slack.com/services/..."
#     slack_format: "{{data}}"

# discord:
#   - id: "bbounty"
#     discord_webhook_url: "https://discord.com/api/webhooks/..."
#     discord_format: "{{data}}"
YAML
log_ok "Notify config → $NOTIFY_CFG"

# ── STEP 14: bountyplz config skeleton ───────────────────────────────────────
BPLZ_CFG="$HOME/.bountyplz"
[[ -f "$BPLZ_CFG" ]] || cat > "$BPLZ_CFG" <<'YAML'
# BBounty Pro — bountyplz config
# Set env vars to enable auto-submit:
#   export BOUNTYPLZ_PLATFORM=hackerone   # or: bugcrowd
#   export BOUNTYPLZ_TOKEN=your_api_token
#   export BOUNTYPLZ_LIVE=1               # 0=dry-run (default), 1=submit for real
YAML

# Wait for SecLists
log_info "Waiting for SecLists..."
wait $SECLISTS_PID 2>/dev/null && log_ok "SecLists downloaded" || \
    log_warn "SecLists failed — retry manually"

# ── SUMMARY ───────────────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${GREEN}══════════════════════════════════════════════${NC}"
echo -e "${BOLD}  BBounty Pro v3.3-zen — Ubuntu Install Done${NC}"
echo -e "${BOLD}${GREEN}══════════════════════════════════════════════${NC}"
echo ""
echo -e "  Tools:     ${CYAN}$TOOLS_DIR/bin${NC}"
echo -e "  Platform:  ${CYAN}$INSTALL_DIR${NC}"
echo -e "  Log:       ${CYAN}$LOG${NC}"
echo ""
[[ ${#FAILED[@]} -gt 0 ]] && {
    echo -e "  ${YELLOW}Failed (non-critical, ${#FAILED[@]} items):${NC}"
    printf '    ✗ %s\n' "${FAILED[@]}"
    echo ""
}
echo -e "  ${BOLD}Next steps:${NC}"
echo -e "  1. Edit ${CYAN}$INSTALL_DIR/.env${NC}"
echo -e "  2. Configure ${CYAN}$NOTIFY_CFG${NC} (Telegram/Slack)"
echo -e "  3. sudo systemctl start bbounty-orchestrator bbounty-aiproxy"
echo -e "  4. sudo bash scripts/install-reconftw.sh  (optional)"
echo ""
echo -e "  ${GREEN}✓ Authorized testing only 🔐${NC}"
echo ""
echo "=== Install finished: $(date) ===" >> "$LOG"
