# Security Policy

## Reporting Vulnerabilities

If you discover a security vulnerability in BBounty Pro, please report it
responsibly:

- **Email**: security@example.com (replace with your address)
- **PGP key**: Available at https://example.com/pgp.txt

**Please do NOT** open a public GitHub issue for security reports.

### What to include

- Description of the vulnerability
- Steps to reproduce
- Affected version (commit hash if from git)
- Proof of concept (minimal, not weaponised)
- Your assessment of impact

### Response timeline

- **24 hours**: Acknowledgment of receipt
- **72 hours**: Initial assessment
- **30 days**: Patch released or detailed timeline provided

We follow coordinated disclosure. Public disclosure happens after a patch
is available, ideally with researcher credit (with consent).

## Supported Versions

| Version | Supported          |
| ------- | ------------------ |
| 3.x     | :white_check_mark: |
| 2.x     | :x:                |
| 1.x     | :x:                |

## Security Practices

This project follows these practices:

- Pre-commit gitleaks scan (no secrets in repo)
- Dependabot for dependency updates
- httpOnly cookies for JWT (not localStorage)
- bcrypt for password hashing (cost 12 in prod)
- ROE Gate enforces scope before any tool execution
- Rate limiting per target with adaptive backoff
- Audit log persists all auth + scan actions
- VPS-only enforcement prevents accidental localhost exposure

## Hall of Fame

We thank these researchers for responsible disclosure:

- *(Be the first!)*
