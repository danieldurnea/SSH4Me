# BBounty Pro — Test Local
# Gemini only | Fără login | Fără rapoarte | Doar findings

## Setup (10 minute)

### 1. Configurare
```bash
cp .env.test .env
nano .env
# → înlocuiește GEMINI_API_KEY=AIza_PUNE_CHEIA_TA_AICI
# → cheie gratuită: https://aistudio.google.com/app/apikey
```

### 2. Tool-uri lipsă (dacă e prima instalare)
```bash
sudo bash scripts/install-ubuntu.sh
# Apoi:
sudo bash scripts/fix-failed-tools.sh
```

### 3. Build orchestrator
```bash
cd apps/orchestrator
go build -o orchestrator ./cmd/server
cd ../..
```

### 4. Start (3 terminale)

**Terminal 1 — Backend:**
```bash
sudo service redis-server start
cd apps/orchestrator && ./orchestrator
```

**Terminal 2 — AI (Gemini):**
```bash
cd apps/ai-proxy
pip3 install -r requirements.txt --break-system-packages
uvicorn main:app --host 127.0.0.1 --port 8001
```

**Terminal 3 — Frontend:**
```bash
cd apps/web
npm install && npm run dev
```

### 5. Acces
```
http://localhost:3000  →  direct în dashboard, fără login
```

### 6. Primul scan
```bash
curl -X POST http://localhost:8080/api/v1/scan/start \
  -H "Content-Type: application/json" \
  -d '{"target":"testphp.vulnweb.com","profile":"quick","platform":"hackerone"}'
```

## Ce funcționează
✅ Pipeline complet (78 tooluri dacă sunt instalate)
✅ Gemini analizează finding-urile (în română)
✅ Dashboard fără login — direct la findings
✅ Asset DB + diff între scanuri
✅ Finding-uri apar live în dashboard

## Ce e dezactivat
❌ Login / auth
❌ Rapoarte HackerOne / Bugcrowd
❌ Telegram alerts
❌ bountyplz auto-submit
❌ Stripe billing
❌ Email notifications

## Verificare Gemini
```bash
curl http://localhost:8001/health
# Răspuns așteptat:
# {"status":"ok","provider":"gemini","configured":true,"mode":"test"}
```

## Troubleshooting
```bash
# Redis nu pornește
sudo service redis-server start
redis-cli ping  # trebuie PONG

# Port 3000 ocupat
npx kill-port 3000

# Go not found
export PATH=$PATH:/usr/local/go/bin
source ~/.bashrc
```
