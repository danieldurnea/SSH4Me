"""Unit tests for 7-Question Gate validator."""
import sys, os
sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..'))

import pytest
from pentest_agents.validator import SevenQuestionGate, Finding, Verdict

gate = SevenQuestionGate()

def make_finding(**kwargs) -> Finding:
    defaults = dict(
        title="SQL Injection on /api/search",
        severity="high",
        url="https://target.com/api/search?q=",
        tool="sqlmap",
        evidence="' OR 1=1-- response differs",
        poc="sqlmap -u 'https://target.com/api/search?q=' --batch",
        reproduced=True,
        in_scope=True,
        checked_dup=True,
        impact="Attacker can dump the entire database including user credentials.",
    )
    defaults.update(kwargs)
    return Finding(**defaults)

class TestNeverSubmitFilter:
    def test_self_xss_killed(self):
        f = make_finding(title="Self-XSS on profile page")
        r = gate.validate(f)
        assert r.verdict == Verdict.KILL
        assert r.score == 0

    def test_missing_hsts_killed(self):
        f = make_finding(title="Missing HSTS without chain")
        r = gate.validate(f)
        assert r.verdict == Verdict.KILL

    def test_csrf_on_get_killed(self):
        f = make_finding(title="CSRF on GET Request to /search")
        r = gate.validate(f)
        assert r.verdict == Verdict.KILL

    def test_banner_grabbing_killed(self):
        f = make_finding(title="Banner Grabbing on port 22")
        r = gate.validate(f)
        assert r.verdict == Verdict.KILL

    def test_rate_limiting_non_critical_killed(self):
        f = make_finding(title="Rate limiting on non-critical endpoint /sitemap")
        r = gate.validate(f)
        assert r.verdict == Verdict.KILL

class TestSevenQuestions:
    def test_full_pass(self):
        r = gate.validate(make_finding())
        assert r.verdict == Verdict.PASS
        assert r.score == 7
        assert r.failed_at is None

    def test_q1_out_of_scope(self):
        r = gate.validate(make_finding(in_scope=False))
        assert r.verdict == Verdict.KILL
        assert r.failed_at == 1

    def test_q2_not_reproduced(self):
        r = gate.validate(make_finding(reproduced=False))
        assert r.verdict == Verdict.KILL
        assert r.failed_at == 2

    def test_q3_no_evidence(self):
        r = gate.validate(make_finding(evidence="", poc=""))
        assert r.verdict == Verdict.KILL
        assert r.failed_at == 3

    def test_q4_no_impact(self):
        r = gate.validate(make_finding(impact=""))
        assert r.verdict == Verdict.KILL
        assert r.failed_at == 4

    def test_q6_critical_without_rce(self):
        f = make_finding(severity="critical", title="Missing auth header", evidence="no auth")
        r = gate.validate(f)
        assert r.verdict == Verdict.DOWNGRADE

    def test_critical_with_rce_passes(self):
        f = make_finding(severity="critical", title="RCE via SSTI", evidence="unauthenticated rce confirmed")
        r = gate.validate(f)
        assert r.verdict == Verdict.PASS

class TestBatchValidate:
    def test_batch_summary(self):
        findings = [
            make_finding(),
            make_finding(title="Self-XSS in console"),
            make_finding(reproduced=False),
        ]
        results = gate.batch_validate(findings)
        assert results["summary"]["PASS"] == 1
        assert results["summary"]["KILL"] == 2
