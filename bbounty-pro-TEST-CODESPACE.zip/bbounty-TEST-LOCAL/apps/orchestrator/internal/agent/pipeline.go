package agent

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"sync"
	"sync/atomic"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/bbounty-pro/orchestrator/internal/cors"
	"github.com/bbounty-pro/orchestrator/internal/findings"
	"github.com/bbounty-pro/orchestrator/internal/profile"
	"github.com/bbounty-pro/orchestrator/internal/roe"
	"github.com/bbounty-pro/orchestrator/internal/ratelimit"
	"github.com/bbounty-pro/orchestrator/internal/tools"
	"github.com/bbounty-pro/orchestrator/internal/ws"
	"github.com/spf13/viper"
	"github.com/go-chi/chi/v5"
	"github.com/google/uuid"
	"github.com/rs/zerolog/log"
	"golang.org/x/sync/errgroup"
	"golang.org/x/time/rate"
)

// ── Constants ─────────────────────────────────────────────────────────────────

const (
	outputBase  = "/tmp/bbounty-scans"
	maxRetries  = 2
)

// ── Phase + Status ────────────────────────────────────────────────────────────

// Lock pattern note: Throughout this file, mutex Lock/Unlock pairs are intentionally
// inline (no defer) for atomic 1-3 line operations. This is safe because:
//   1. No panics possible inside critical sections (no allocs, no I/O, no func calls)
//   2. defer would hold locks longer than needed, hurting contention
//   3. All Unlock calls are unconditional on next 1-3 lines, verified by go vet
// If you add code between Lock/Unlock, switch to defer pattern.

type Phase      string
type ScanStatus string

const (
	PhaseAnalyze Phase = "ANALYZE"
	PhasePlan    Phase = "PLAN"
	PhaseExecute Phase = "EXECUTE"
	PhaseIterate Phase = "ITERATE"
)

const (
	StatusQueued  ScanStatus = "queued"
	StatusRunning ScanStatus = "running"
	StatusPaused  ScanStatus = "paused"
	StatusDone    ScanStatus = "done"
	StatusFailed  ScanStatus = "failed"
	StatusAborted ScanStatus = "aborted"
)

// ── LiveStats is broadcast in real-time ───────────────────────────────────────

type LiveStats struct {
	ScanID    string     `json:"scan_id"`
	Phase     Phase      `json:"phase"`
	Status    ScanStatus `json:"status"`
	Subs      int64      `json:"subs"`
	Live      int64      `json:"live"`
	URLs      int64      `json:"urls"`
	Vulns     int64      `json:"vulns"`
	Progress  float64    `json:"progress"`
	StartedAt time.Time  `json:"started_at"`
	Elapsed   float64    `json:"elapsed_sec"`
}

// ── ScanRequest from API ──────────────────────────────────────────────────────

type ScanRequest struct {
	Target     string   `json:"target"`
	Program    string   `json:"program"`
	Tester     string   `json:"tester"`
	Scope      []string `json:"scope"`
	Excluded   []string `json:"excluded"`
	Platform   string   `json:"platform"`
	ToolIDs    []string `json:"tool_ids"`
	MaxConc    int      `json:"max_concurrent"`
	OwnerID    string   `json:"owner_id"`
	Profile    string   `json:"profile,omitempty"` // profile name: quick/deep/wordpress/api/stealth
}

// ── activeScan tracks a running scan ──────────────────────────────────────────

type activeScan struct {
	req      ScanRequest
	cancelFn context.CancelFunc
	mu       sync.RWMutex
	startedAt time.Time // used by dead scan janitor

	// FIXED: atomic fields — use atomic.Int64 (Go 1.19+) instead of raw int64.
	subs  atomic.Int64
	live  atomic.Int64
	urls  atomic.Int64
	vulns atomic.Int64

	phase  Phase
	status ScanStatus
}

func (s *activeScan) stats(scanID string) LiveStats {
	s.mu.RLock()
	defer s.mu.RUnlock()
	return LiveStats{
		ScanID:  scanID,
		Phase:   s.phase,
		Status:  s.status,
		Subs:    s.subs.Load(),
		Live:    s.live.Load(),
		URLs:    s.urls.Load(),
		Vulns:   s.vulns.Load(),
	}
}

// ── Pipeline ──────────────────────────────────────────────────────────────────

// emailSender is a minimal interface so Pipeline doesn't import email package directly.
type emailSender interface {
	SendScanComplete(ctx context.Context, to, username, target string, crit, high, total int, scanID string) error
}

// findingsLister allows pipeline to list findings without importing findings package again.
type findingsLister interface {
	ListByScan(ctx context.Context, scanID string) ([]*findings.Finding, error)
}

// diffSaver is a minimal interface so pipeline doesn't import diff package directly.
type diffSaver interface {
	SaveSnapshot(ctx context.Context, snap interface{}) error
	CompareLatest(ctx context.Context, target string) (interface{}, error)
	ShouldNotifyIface(d interface{}) (bool, string)
}

type Pipeline struct {
	registry *tools.Registry
	hub      *ws.Hub
	gate     *roe.Gate
	findings *findings.Store
	cache    *cache.Client

	checkpoints   *CheckpointStore
	rateLimiter   *ratelimit.Registry
	profileLoader *profile.Loader
	emailSvc      emailSender
	findingsStore *findings.Store
	diffEngine    diffEngineIface
	notifier      notifierIface

	scans   map[string]*activeScan
	scansMu sync.RWMutex
}

// diffEngineIface allows pipeline to call diff engine without circular import.
type diffEngineIface interface {
	SaveSnapshotRaw(ctx context.Context, target, scanID string, subs, liveHosts, ports, tech interface{}, fs interface{}) error
	CompareLatestRaw(ctx context.Context, target string) (bool, string, error)
}

// notifierIface minimal interface for sending alerts from pipeline.
type notifierIface interface {
	SendText(ctx context.Context, text string) error
}

func NewPipeline(
	r *tools.Registry, h *ws.Hub, g *roe.Gate,
	f *findings.Store, c *cache.Client,
) *Pipeline {
	p := &Pipeline{
		registry: r, hub: h, gate: g,
		findings: f, cache: c,
		scans:    make(map[string]*activeScan),
	}
	// Dead scan janitor — runs every 15 minutes.
	// Cancels and removes scans stuck in running/queued state > 2 hours.
	// Prevents Redis/memory leaks from crashed or abandoned scans.
	go p.deadScanJanitor()
	return p
}

// deadScanJanitor periodically cancels scans that have been running too long.
// A scan stuck > 2h is almost certainly crashed or orphaned.

// safeReadFile reads a file up to maxBytes — prevents OOM on large scan outputs.
func safeReadFile(path string, maxBytes int64) ([]byte, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, err
	}
	defer f.Close()
	return io.ReadAll(io.LimitReader(f, maxBytes))
}

func (p *Pipeline) deadScanJanitor() {
	const (
		checkInterval = 15 * time.Minute
		maxScanAge    = 2 * time.Hour
	)
	ticker := time.NewTicker(checkInterval)
	defer ticker.Stop()
	for range ticker.C {
		p.scansMu.Lock()
		now := time.Now()
		for id, scan := range p.scans {
			scan.mu.Lock()
			age     := now.Sub(scan.startedAt)
			status  := scan.status
			scan.mu.Unlock()

			if (status == StatusRunning || status == StatusQueued) && age > maxScanAge {
				log.Warn().
					Str("scan", id).
					Dur("age", age).
					Str("status", string(status)).
					Msg("[janitor] canceling dead scan")
				scan.cancelFn()
				delete(p.scans, id)
				// Mark as failed in Redis for dashboard visibility
				p.cache.Raw().Set(
					context.Background(),
					"scan:status:"+id,
					"dead",
					24*time.Hour,
				)
				p.broadcastEvent(id, "scan_dead", map[string]string{
					"scan_id": id,
					"reason":  "exceeded max scan age (2h)",
				})
			}
		}
		p.scansMu.Unlock()
	}
}

func (p *Pipeline) SetCheckpointStore(cs *CheckpointStore) { p.checkpoints = cs }
func (p *Pipeline) SetRateLimiter(rl *ratelimit.Registry)  { p.rateLimiter = rl }
func (p *Pipeline) SetProfileLoader(pl *profile.Loader)    { p.profileLoader = pl }
func (p *Pipeline) SetEmailService(svc emailSender)        { p.emailSvc = svc; p.findingsStore = p.findings }
func (p *Pipeline) SetDiffEngine(de diffEngineIface)       { p.diffEngine = de }
func (p *Pipeline) SetNotifier(n notifierIface)            { p.notifier = n }

// HandleStart validates ROE, creates a scan, and launches the pipeline.
func (p *Pipeline) HandleStart(w http.ResponseWriter, r *http.Request) {
	// ── Per-user scan limit bazat pe JWT userID ───────────────────────────────
	// FIX: folosim userID din JWT, nu IP sau header.
	// IP/header = bypass trivial via VPN sau alt tab.
	// userID din JWT = legat de cont, imposibil de bypass fără alt cont plătit.
	userID := fmt.Sprintf("%v", r.Context().Value("userID"))
	if userID == "" || userID == "<nil>" {
		http.Error(w, `{"error":"not authenticated"}`, http.StatusUnauthorized)
		return
	}

	// Verifică limita de scanuri concurente per user (din plan)
	if err := p.checkScanRateLimit(r.Context(), userID); err != nil {
		w.Header().Set("Retry-After", "60")
		http.Error(w, fmt.Sprintf(`{"error":"%s"}`, err.Error()), http.StatusTooManyRequests)
		return
	}

	var req ScanRequest
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, `{"error":"invalid body"}`, http.StatusBadRequest)
		return
	}
	if err := p.gate.Validate(req.Target, req.Scope, req.Excluded); err != nil {
		http.Error(w, fmt.Sprintf(`{"error":"ROE violation: %s"}`, err), http.StatusForbidden)
		return
	}
	if req.MaxConc <= 0 {
		req.MaxConc = 8
	}

	// Apply profile if specified — overrides tool_ids and max_concurrent
	if req.Profile != "" && p.profileLoader != nil {
		if prof := p.profileLoader.Get(req.Profile); prof != nil {
			// Profile tools override manual tool selection
			if len(req.ToolIDs) == 0 {
				req.ToolIDs = prof.Tools
			}
			if req.MaxConc == 8 && prof.MaxConcurrent > 0 {
				req.MaxConc = prof.MaxConcurrent
			}
			log.Info().Str("profile", prof.Name).
				Int("tools", len(req.ToolIDs)).
				Msg("pipeline: profile applied")
		} else {
			log.Warn().Str("profile", req.Profile).Msg("pipeline: unknown profile — ignored")
		}
	}

	scanID := uuid.New().String()
	ctx, cancel := context.WithCancel(context.Background())

	scan := &activeScan{
		req:       req,
		cancelFn:  cancel,
		phase:     PhaseAnalyze,
		status:    StatusQueued,
		startedAt: time.Now(),
	}

	p.scansMu.Lock()
	p.scans[scanID] = scan
	p.scansMu.Unlock()

	// Store scan ownership + user info in Redis for:
	// 1. Findings ownership check (auth middleware)
	// 2. Scan complete email notification
	scanTTL := 48 * time.Hour
	p.cache.Raw().Set(context.Background(), "scan:owner:"+scanID,
		fmt.Sprintf("%v", r.Context().Value("userID")), scanTTL)
	if userEmail, _ := p.cache.Raw().Get(context.Background(),
		"user:email:"+fmt.Sprintf("%v", r.Context().Value("userID"))).Result(); userEmail != "" {
		p.cache.Raw().Set(context.Background(), "scan:email:"+scanID, userEmail, scanTTL)
	}
	if username, _ := p.cache.Raw().Get(context.Background(),
		"user:username:"+fmt.Sprintf("%v", r.Context().Value("userID"))).Result(); username != "" {
		p.cache.Raw().Set(context.Background(), "scan:user:"+scanID, username, scanTTL)
	}

	go p.run(ctx, scanID, scan)

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(http.StatusAccepted)
	json.NewEncoder(w).Encode(map[string]string{
		"scan_id": scanID,
		"ws_url":  fmt.Sprintf("/ws/pipeline/%s", scanID),
	})
}

// run executes the 4-phase pipeline.
func (p *Pipeline) run(ctx context.Context, scanID string, scan *activeScan) {
	start := time.Now()

	defer func() {
		scan.mu.Lock()
		scan.status = StatusDone
		scan.mu.Unlock()
		p.broadcastStats(scanID, scan, start)
		go CleanOldOutputs(72 * time.Hour)
		log.Info().Str("scan", scanID).Dur("elapsed", time.Since(start)).Msg("scan complete")

		// Decrement concurrent scan counter — eliberează slot pentru userul ăsta
		go p.decrementScanRateLimit(context.Background(), fmt.Sprintf("%v", ctx.Value("userID")))

		// ── Notify scan complete via Telegram/Slack/Discord ──────────────────
		if p.notifier != nil {
			go func() {
				ctx2, cancel := context.WithTimeout(context.Background(), 10*time.Second)
				defer cancel()
				allF, _ := p.findings.ListByScan(ctx2, scanID)
				crit, high, med := 0, 0, 0
				for _, f := range allF {
					switch f.Severity {
					case "critical": crit++
					case "high":     high++
					case "medium":   med++
					}
				}
				_ = p.notifier.SendText(ctx2, fmt.Sprintf(
					"[BBounty] Scan finished: %s | %d findings (crit:%d high:%d med:%d) | %s",
					scan.req.Target, len(allF), crit, high, med, time.Since(start).Round(time.Second),
				))
			}()
		}

		// ── Send scan complete email ──────────────────────────────────────────
		// Count findings by severity and notify the user that the scan finished.
		// Runs in background — never blocks the pipeline.
		if p.emailSvc != nil {
			go func() {
				ctx2, cancel := context.WithTimeout(context.Background(), 15*time.Second)
				defer cancel()
				allFindings, err := p.findings.ListByScan(ctx2, scanID)
				if err != nil {
					return
				}
				crit, high := 0, 0
				for _, f := range allFindings {
					switch f.Severity {
					case "critical": crit++
					case "high":     high++
					}
				}
				// Get user email from Redis (stored when scan starts)
				userEmail, _ := p.cache.Raw().Get(ctx2, "scan:email:"+scanID).Result()
				username,  _ := p.cache.Raw().Get(ctx2, "scan:user:"+scanID).Result()
				if userEmail != "" {
					if err := p.emailSvc.SendScanComplete(
						ctx2, userEmail, username, scan.req.Target,
						crit, high, len(allFindings), scanID,
					); err != nil {
						log.Warn().Err(err).Str("scan", scanID).Msg("[email] scan complete email failed")
					}
				}
			}()
		}

		// ── Asset DB: save snapshot + compare with previous scan ──────────────
		// This is the continuous monitoring core:
		// 1. Save current scan state (subdomains, ports, tech, findings)
		// 2. Compare with last snapshot for same target
		// 3. Alert on delta (new subdomain, new finding, port change)
		if p.diffEngine != nil {
			go func() {
				ctx2, cancel := context.WithTimeout(context.Background(), 30*time.Second)
				defer cancel()

				// Read subdomains from scan output
				subsFile := filepath.Join(outputBase, scanID[:8], scanID[:8]+"_subs.txt")
				var subs []string
				if data, err := safeReadFile(subsFile, 10<<20); err == nil {
					for _, line := range strings.Split(string(data), "\n") {
						if line = strings.TrimSpace(line); line != "" {
							subs = append(subs, line)
						}
					}
				}

				// Get findings for this scan
				allFindings, _ := p.findings.ListByScan(ctx2, scanID)
				findingIDs := make([]string, 0, len(allFindings))
				for _, f := range allFindings {
					findingIDs = append(findingIDs, f.ID)
				}

				// Save snapshot to Redis (90-day retention via TTL)
				if err := p.diffEngine.SaveSnapshotRaw(
					ctx2, scan.req.Target, scanID,
					subs, nil, nil, nil, findingIDs,
				); err != nil {
					log.Warn().Err(err).Msg("[diff] save snapshot failed")
					return
				}

				// Compare with previous scan — alert on delta
				shouldAlert, summary, err := p.diffEngine.CompareLatestRaw(ctx2, scan.req.Target)
				if err != nil {
					log.Debug().Err(err).Msg("[diff] compare failed (first scan?)")
					return
				}
				if shouldAlert && summary != "" {
					log.Info().Str("target", scan.req.Target).Str("delta", summary).Msg("[diff] new assets detected")
					p.broadcastEvent(scanID, "diff_alert", map[string]string{
						"target":  scan.req.Target,
						"summary": summary,
					})
				}
			}()
		}
	}()

	phases := []struct {
		phase   Phase
		toolSet string
	}{
		{PhaseAnalyze, tools.PhaseRecon},
		{PhasePlan,    tools.PhaseEnum},
		{PhaseExecute, tools.PhaseScan},
		{PhaseIterate, tools.PhaseExploit},
	}

	sem := NewSemaphore(scan.req.MaxConc)

	// outDir is used by both runPhase (tool execution) and analyzeOutputs (conditional chaining)
	outDir := filepath.Join(outputBase, scanID[:8])
	if err := os.MkdirAll(outDir, 0o755); err != nil {
		log.Warn().Err(err).Str("dir", outDir).Msg("pipeline: mkdir failed — using /tmp fallback")
		outDir = "/tmp"
	}

	// Load profile conditions (nil-safe)
	var cond profile.Conditions
	if p.profileLoader != nil && scan.req.Profile != "" {
		if prof := p.profileLoader.Get(scan.req.Profile); prof != nil {
			cond = prof.Conditions
			log.Info().Str("profile", scan.req.Profile).Msg("pipeline: using scan profile")
		}
	}

	// injectedScan/Exploit hold tools added by conditional chaining mid-run
	var injectedScanTools    []string
	var injectedExploitTools []string

	for _, ph := range phases {
		select {
		case <-ctx.Done():
			scan.mu.Lock(); scan.status = StatusAborted; scan.mu.Unlock()
			return
		default:
		}

		scan.mu.Lock()
		scan.phase = ph.phase
		scan.status = StatusRunning
		scan.mu.Unlock()

		p.broadcastStats(scanID, scan, start)
		p.broadcastEvent(scanID, "phase_start", map[string]string{"phase": string(ph.phase)})

		// Persist checkpoint so we can resume if the process restarts.
		if p.checkpoints != nil {
			_ = p.checkpoints.Save(ctx, &Checkpoint{
				ScanID:    scanID,
				Phase:     ph.phase,
				Request:   scan.req,
				UpdatedAt: time.Now(),
			})
		}

		toolList := p.filterTools(scan.req.ToolIDs, ph.toolSet)

		// Merge conditionally injected tools for this phase
		switch ph.phase {
		case PhaseExecute:
			for _, id := range injectedScanTools {
				if t, ok := p.registry.Get(id); ok && t != nil {
					toolList = append(toolList, t)
					p.broadcastEvent(scanID, "tool_injected", map[string]string{
						"tool_id": id, "reason": "conditional_chain",
					})
					log.Info().Str("tool", id).Str("phase", "scan").Msg("pipeline: conditional tool injected")
				}
			}
		case PhaseIterate:
			for _, id := range injectedExploitTools {
				if t, ok := p.registry.Get(id); ok && t != nil {
					toolList = append(toolList, t)
					p.broadcastEvent(scanID, "tool_injected", map[string]string{
						"tool_id": id, "reason": "conditional_chain",
					})
					log.Info().Str("tool", id).Str("phase", "exploit").Msg("pipeline: conditional tool injected")
				}
			}
		}

		if err := p.runPhase(ctx, scanID, scan, sem, toolList); err != nil {
			p.broadcastEvent(scanID, "phase_error", map[string]string{
				"phase": string(ph.phase), "error": err.Error(),
			})
		}

		// Real scope enforcement on tool output files
		p.filterOutputsInScope(scanID, scan)

		// Conditional analysis — inject tools into subsequent phases
		injected := analyzeOutputs(scanID, outDir, cond)
		injectedScanTools    = mergeUnique(injectedScanTools,    injected.ScanTools)
		injectedExploitTools = mergeUnique(injectedExploitTools, injected.ExploitTools)
		for _, reason := range injected.Reasons {
			p.broadcastEvent(scanID, "condition_triggered", map[string]string{
				"reason": reason, "phase": string(ph.phase),
			})
		}
	}
}

// runPhase executes all tools in a phase with the shared semaphore.
func (p *Pipeline) runPhase(
	ctx context.Context, scanID string, scan *activeScan,
	sem *Semaphore, toolList []*tools.Tool,
) error {
	// Per-phase rate limiter shared across all tools.
	// Profile rate_limit overrides default 20 req/s.
	rateLimit := float64(20)
	if scan.req.Profile != "" && p.profileLoader != nil {
		if prof := p.profileLoader.Get(scan.req.Profile); prof != nil && prof.RateLimit > 0 {
			rateLimit = float64(prof.RateLimit)
		}
	}
	limiter := rate.NewLimiter(rate.Limit(rateLimit), int(rateLimit))

	g, gctx := errgroup.WithContext(ctx)

	// Split tools: parallel ones run concurrently, serial ones run in order
	// but still inside goroutines so they don't block the errgroup.
	var serialTools []*tools.Tool
	for _, tool := range toolList {
		tool := tool // capture
		if tool.Parallel {
			// Parallel tool → own goroutine, semaphore controls max concurrency
			g.Go(func() error {
				if err := p.executeTool(gctx, scanID, scan, tool, limiter, sem); err != nil {
					log.Warn().Err(err).Str("tool", tool.ID).Msg("tool error")
				}
				return nil // non-fatal — log and continue
			})
		} else {
			serialTools = append(serialTools, tool)
		}
	}

	// Serial tools run sequentially in a single goroutine
	// so they don't interleave (e.g. sqlmap after gf finds SQLi params)
	if len(serialTools) > 0 {
		g.Go(func() error {
			for _, tool := range serialTools {
				select {
				case <-gctx.Done():
					return gctx.Err()
				default:
				}
				if err := p.executeTool(gctx, scanID, scan, tool, limiter, sem); err != nil {
					log.Warn().Err(err).Str("tool", tool.ID).Msg("serial tool error")
				}
			}
			return nil
		})
	}

	return g.Wait()
}

// executeTool runs a single tool with retry and live streaming.
func (p *Pipeline) executeTool(
	ctx context.Context, scanID string, scan *activeScan,
	tool *tools.Tool, limiter *rate.Limiter, sem *Semaphore,
) error {
	if err := sem.Acquire(ctx); err != nil {
		return err
	}
	defer sem.Release()

	if err := limiter.Wait(ctx); err != nil {
		return err
	}

	// ── Native tools: Go functions, no subprocess ─────────────────────────────
	// These run directly in the orchestrator process — fully parallel,
	// no shell overhead, no binary dependency.
	if tool.Native {
		return p.executeNativeTool(ctx, scanID, scan, tool)
	}

	outDir := filepath.Join(outputBase, scanID[:8])
	if err := os.MkdirAll(outDir, 0o755); err != nil {
		log.Warn().Err(err).Str("dir", outDir).Msg("pipeline: mkdir failed — using /tmp fallback")
		outDir = "/tmp"
	}

	// FIXED: use tools.BuildCommand() — single source of truth, no duplicates.
	// Returns "" if target failed strict sanitisation; skip the tool in that
	// case rather than spawning bash with a malformed command line.
	cmd := tools.BuildCommand(tool, tools.BuildContext{
		Target: scan.req.Target,
		ScanID: scanID,
		OutDir: outDir,
		Scope:  scan.req.Scope,
	})
	if cmd == "" {
		log.Warn().Str("tool", tool.ID).Str("target", scan.req.Target).
			Msg("pipeline: skipping tool — target failed strict sanitisation")
		p.broadcastEvent(scanID, "tool_skipped", map[string]string{
			"tool_id": tool.ID, "reason": "unsafe_target",
		})
		return nil
	}
	if tool.Phase == tools.PhaseRecon || tool.Phase == tools.PhaseEnum {
		cmd = tools.ScopeFilter(cmd, scan.req.Scope)
	}

	p.broadcastEvent(scanID, "tool_start", map[string]string{
		"tool_id":  tool.ID,
		"tool":     tool.Name,
		"phase":    tool.Phase,
		"parallel": fmt.Sprintf("%v", tool.Parallel),
	})

	var lastErr error
	for attempt := 0; attempt <= maxRetries; attempt++ {
		if attempt > 0 {
			select {
			case <-ctx.Done():
				return ctx.Err()
			case <-time.After(time.Duration(attempt*5) * time.Second):
			}
		}
		var buf bytes.Buffer
		lastErr = p.shell(ctx, cmd, tool, scanID, &buf, scan.req.Target, scan.req.Platform)
		if buf.Len() > 0 {
			if found, err := tools.Parse(tool.ID, &buf, scanID); err == nil {
				p.saveFindings(ctx, scanID, scan, found)
			}
			if p.rateLimiter != nil && (tool.ID == "httpx" || tool.ID == "nuclei") {
				p.observeHTTPStatuses(scan.req.Target, scan.req.Platform, &buf)
			}
		}

		// ── reconFTW special handling ─────────────────────────────────────────
		// After reconFTW finishes, parse its output directory and feed the
		// results into both the findings store and the pipeline's canonical
		// output files (so conditional chaining can pick up signals).
		if tool.ID == "reconftw" && lastErr == nil {
			reconFTWDir := p.reconFTWOutputDir(scan.req.Target)
			if r, err := tools.ParseReconFTWOutput(scanID, reconFTWDir); err == nil {
				// Save findings from reconFTW to Redis
				p.saveFindings(ctx, scanID, scan, r.Findings)
				// Write subs/hosts/signals to pipeline canonical files
				tools.WriteReconFTWToPipeline(outDir, scanID, r)
				log.Info().
					Int("findings", len(r.Findings)).
					Int("subs", len(r.Subdomains)).
					Int("hosts", len(r.LiveHosts)).
					Msg("pipeline: reconFTW output integrated")
				p.broadcastEvent(scanID, "reconftw_parsed", map[string]string{
					"findings": fmt.Sprintf("%d", len(r.Findings)),
					"subs":     fmt.Sprintf("%d", len(r.Subdomains)),
					"hosts":    fmt.Sprintf("%d", len(r.LiveHosts)),
				})
			} else {
				log.Warn().Err(err).Str("dir", reconFTWDir).Msg("pipeline: reconFTW output parse failed")
			}
		}
		if lastErr == nil || ctx.Err() != nil {
			break
		}
	}

	p.broadcastEvent(scanID, "tool_done", map[string]string{
		"tool_id": tool.ID, "status": errStatus(lastErr),
	})
	return lastErr
}

// executeNativeTool dispatches to built-in Go implementations.
// These run inside the orchestrator process — fully parallel, no subprocess.
func (p *Pipeline) executeNativeTool(
	ctx context.Context, scanID string, scan *activeScan,
	tool *tools.Tool,
) error {
	p.broadcastEvent(scanID, "tool_start", map[string]string{
		"tool_id":  tool.ID,
		"tool":     tool.Name,
		"phase":    tool.Phase,
		"parallel": "true",
		"native":   "true",
	})

	timeout := time.Duration(tool.Timeout) * time.Second
	if timeout <= 0 {
		timeout = 120 * time.Second
	}
	tctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()

	var err error

	switch tool.ID {
	case "cors-engine":
		err = p.runCORSEngine(tctx, scanID, scan)

	default:
		log.Warn().Str("tool", tool.ID).Msg("pipeline: unknown native tool — skipped")
	}

	status := "ok"
	if err != nil {
		status = "error"
		log.Warn().Err(err).Str("tool", tool.ID).Msg("pipeline: native tool error")
	}
	p.broadcastEvent(scanID, "tool_done", map[string]string{
		"tool_id": tool.ID, "status": status,
	})
	return err
}

// runCORSEngine runs the built-in CORS testing engine against discovered live hosts.
// It reads the httpx output file for live URLs, then tests all CORS vectors in parallel.
func (p *Pipeline) runCORSEngine(ctx context.Context, scanID string, scan *activeScan) error {
	outDir := filepath.Join("/tmp/bbounty-scans", scanID[:8])
	target := scan.req.Target

	// Collect URLs to test:
	// 1. Primary target
	// 2. Any live hosts discovered by httpx in this scan
	urls := []string{
		"https://" + target,
		"http://" + target,
	}

	// Parse httpx output if available
	httpxFile := filepath.Join(outDir, scanID[:8]+"_httpx.txt")
	if data, err := safeReadFile(httpxFile, 10<<20); err == nil {
		for _, line := range splitLines(string(data)) {
			line = trimLine(line)
			if line != "" && (hasPrefix(line, "http://") || hasPrefix(line, "https://")) {
				urls = append(urls, line)
			}
		}
	}

	// Deduplicate
	seen := make(map[string]bool)
	var deduped []string
	for _, u := range urls {
		if !seen[u] {
			seen[u] = true
			deduped = append(deduped, u)
		}
	}

	log.Info().
		Str("target", target).
		Int("urls", len(deduped)).
		Msg("[cors-engine] starting parallel CORS tests")

	engine := cors.New()
	corsFindings := engine.TestTargets(ctx, deduped)

	if len(corsFindings) == 0 {
		log.Info().Str("target", target).Msg("[cors-engine] no CORS vulnerabilities found")
		return nil
	}

	// Convert cors.Finding → findings.Finding and save
	for _, cf := range corsFindings {
		sev := findings.Severity(cf.Severity)
		f := &findings.Finding{
			ScanID:   scanID,
			Title:    fmt.Sprintf("CORS: %s — %s", cf.Vector, cf.URL),
			Severity: sev,
			URL:      cf.URL,
			Category: "cors",
			Payload:  cf.PoC,
			Response: cf.Description,
			Source:   "cors-engine",
			AIAnalysis: cf.Remediation,
			Tags:     []string{"cors", cf.Vector},
		}
		p.saveFindings(ctx, scanID, scan, []*findings.Finding{f})

		// Notify on critical/high via WebSocket
		p.broadcastEvent(scanID, "finding", map[string]string{
			"tool_id":  "cors-engine",
			"severity": string(sev),
			"title":    f.Title,
			"url":      f.URL,
		})

		log.Info().
			Str("vector", cf.Vector).
			Str("severity", string(sev)).
			Str("url", cf.URL).
			Msg("[cors-engine] CORS vulnerability found")
	}

	return nil
}

// ── String helpers (avoid importing strings just for these) ───────────────────

func splitLines(s string) []string {
	var lines []string
	cur := ""
	for _, c := range s {
		if c == '\n' {
			lines = append(lines, cur)
			cur = ""
		} else {
			cur += string(c)
		}
	}
	if cur != "" {
		lines = append(lines, cur)
	}
	return lines
}

func trimLine(s string) string {
	for len(s) > 0 && (s[0] == ' ' || s[0] == '\t' || s[0] == '\r') {
		s = s[1:]
	}
	for len(s) > 0 && (s[len(s)-1] == ' ' || s[len(s)-1] == '\t' || s[len(s)-1] == '\r') {
		s = s[:len(s)-1]
	}
	return s
}

func hasPrefix(s, prefix string) bool {
	return len(s) >= len(prefix) && s[:len(prefix)] == prefix
}

// shell runs a bash command, streaming output to WS and capturing for parsing.
func (p *Pipeline) shell(
	ctx context.Context, cmd string, tool *tools.Tool,
	scanID string, buf *bytes.Buffer,
	target, platform string,
) error {
	timeout := time.Duration(tool.Timeout) * time.Second
	if timeout == 0 {
		timeout = 5 * time.Minute
	}
	tctx, cancel := context.WithTimeout(ctx, timeout)
	defer cancel()

	// ── Binary availability check ─────────────────────────────────────────────
	// Skip gracefully if tool binary not installed.
	// Native tools (cors-engine) and script-based tools skip this check.
	if tool.BinaryPath != "" && tool.BinaryPath != "cors-engine" {
		checkCmd := exec.CommandContext(tctx, "command", "-v", tool.BinaryPath)
		if err := checkCmd.Run(); err != nil {
			// Try which as fallback
			whichCmd := exec.CommandContext(tctx, "which", tool.BinaryPath)
			if err2 := whichCmd.Run(); err2 != nil {
				log.Info().
					Str("tool", tool.ID).
					Str("binary", tool.BinaryPath).
					Msg("[pipeline] tool not installed — skipping gracefully")
				p.broadcastEvent(scanID, "tool_skip", map[string]string{
					"tool_id": tool.ID,
					"reason":  tool.BinaryPath + " not found",
				})
				return nil // Non-fatal — continue pipeline
			}
		}
	}

	// Tools rulează nativ pe Ubuntu — Kali container eliminat.
	// Toate cele 78 tooluri se instalează via scripts/install-ubuntu.sh
	execCmd := exec.CommandContext(tctx, "/bin/bash", "-c", cmd)

	tw := &teeWriter{hub: p.hub, scanID: scanID, toolID: tool.ID, buf: buf}
	execCmd.Stdout = tw
	execCmd.Stderr = tw

	// Inject pipeline context into subprocess env.
	// M6-FIX: explicit env allowlist — os.Environ() was passing JWT_SECRET,
	// ANTHROPIC_API_KEY, STRIPE_SECRET_KEY etc. to all subprocesses (security leak).
	// Only pass what tools actually need.
	subprocEnv := []string{
		"PATH=" + os.Getenv("PATH"),
		"HOME=" + os.Getenv("HOME"),
		"USER=" + os.Getenv("USER"),
		"TMPDIR=" + os.TempDir(),
		"SCAN_ID=" + scanID,
		// H3-FIX: BBOUNTY_API removed — tools don't need internal API URL
		// Reduces attack surface if a tool binary is compromised (supply chain)
		"BBOUNTY_TARGET=" + target,
		"BBOUNTY_PLATFORM=" + platform,
		"RECONFTW_OUTPUT=" + os.Getenv("RECONFTW_OUTPUT"),
		// Tool-specific API keys — only the ones tools actually use
		"SHODAN_API_KEY=" + os.Getenv("SHODAN_API_KEY"),
		"PDCP_API_KEY=" + os.Getenv("PDCP_API_KEY"),
		"GITHUB_TOKEN=" + os.Getenv("GITHUB_TOKEN"),
		"BOUNTYPLZ_PLATFORM=" + os.Getenv("BOUNTYPLZ_PLATFORM"),
		"BOUNTYPLZ_LIVE=" + os.Getenv("BOUNTYPLZ_LIVE"),
		"INTERACTSH_URL=" + os.Getenv("INTERACTSH_URL"),
	}
	// Native Ubuntu mode — no container needed
	execCmd.Env = subprocEnv

	if err := execCmd.Start(); err != nil {
		return fmt.Errorf("start %s: %w", tool.Name, err)
	}
	return execCmd.Wait()
}

// saveFindings persists new findings and updates stats atomically.
func (p *Pipeline) saveFindings(ctx context.Context, scanID string, scan *activeScan, items []*findings.Finding) {
	for _, f := range items {
		if err := p.findings.Save(ctx, f); err != nil {
			log.Warn().Err(err).Str("title", f.Title).Msg("finding: save failed")
			continue
		}
		scan.vulns.Add(1)
		p.broadcastEvent(scanID, "new_finding", map[string]any{
			"id": f.ID, "title": f.Title,
			"severity": string(f.Severity), "url": f.URL,
		})
	}
}

// ── teeWriter: write to WS hub AND capture buffer ─────────────────────────────

type teeWriter struct {
	hub    *ws.Hub
	scanID string
	toolID string
	buf    *bytes.Buffer
	lines  int
}

func (t *teeWriter) Write(p []byte) (int, error) {
	t.buf.Write(p)
	// Throttle WS broadcast: every 3rd chunk to avoid flooding slow clients.
	t.lines++
	if t.lines%3 == 0 {
		d := make([]byte, len(p))
		copy(d, p)
		t.hub.BroadcastTerminal(t.scanID, t.toolID, d)
	}
	return len(p), nil
}

// ── Output management ─────────────────────────────────────────────────────────

// CleanOldOutputs removes scan directories older than ttl.
func CleanOldOutputs(ttl time.Duration) {
	entries, err := os.ReadDir(outputBase)
	if err != nil {
		return
	}
	cutoff := time.Now().Add(-ttl)
	for _, e := range entries {
		if !e.IsDir() {
			continue
		}
		info, err := e.Info()
		if err != nil || !info.ModTime().Before(cutoff) {
			continue
		}
		path := filepath.Join(outputBase, e.Name())
		if err := os.RemoveAll(path); err != nil {
			log.Warn().Err(err).Str("path", path).Msg("cleanup failed")
		}
	}
}

// ── Broadcast helpers ─────────────────────────────────────────────────────────

func (p *Pipeline) broadcastStats(scanID string, scan *activeScan, start time.Time) {
	s := scan.stats(scanID)
	s.StartedAt = start
	s.Elapsed = time.Since(start).Seconds()
	data, _ := json.Marshal(s)
	p.hub.BroadcastStats(scanID, data)
}

func (p *Pipeline) broadcastEvent(scanID, event string, payload any) {
	data, _ := json.Marshal(map[string]any{
		"event": event, "payload": payload,
		"ts": time.Now().UnixMilli(),
	})
	p.hub.BroadcastPipeline(scanID, data)
}

// ── HTTP Handlers ─────────────────────────────────────────────────────────────

func (p *Pipeline) HandleStop(w http.ResponseWriter, r *http.Request) {
	scanID := r.URL.Query().Get("scan_id")
	p.scansMu.RLock()
	scan, ok := p.scans[scanID]
	p.scansMu.RUnlock()
	if !ok {
		http.Error(w, `{"error":"not found"}`, http.StatusNotFound)
		return
	}
	scan.cancelFn()
	w.Write([]byte(`{"status":"stopping"}`))
}

func (p *Pipeline) HandlePause(w http.ResponseWriter, _ *http.Request) {
	w.Write([]byte(`{"status":"paused"}`))
}

func (p *Pipeline) HandleStatus(w http.ResponseWriter, r *http.Request) {
	scanID := chi.URLParam(r, "scanID")
	p.scansMu.RLock()
	scan, ok := p.scans[scanID]
	p.scansMu.RUnlock()
	if !ok {
		http.Error(w, `{"error":"not found"}`, http.StatusNotFound)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(scan.stats(scanID))
}

func (p *Pipeline) HandleStats(w http.ResponseWriter, r *http.Request) {
	p.HandleStatus(w, r)
}

func (p *Pipeline) DrainAll(ctx context.Context) {
	p.scansMu.RLock()
	defer p.scansMu.RUnlock()
	for _, scan := range p.scans {
		scan.cancelFn()
	}
	select {
	case <-ctx.Done():
	case <-time.After(10 * time.Second):
	}
}

// ── Utilities ─────────────────────────────────────────────────────────────────

func (p *Pipeline) filterTools(requested []string, phase string) []*tools.Tool {
	all := p.registry.ByPhase(phase)
	if len(requested) == 0 {
		return all
	}
	want := make(map[string]bool, len(requested))
	for _, id := range requested {
		want[id] = true
	}
	var out []*tools.Tool
	for _, t := range all {
		if want[t.ID] {
			out = append(out, t)
		}
	}
	return out
}

func containsAny(s string, subs ...string) bool {
	for _, sub := range subs {
		if len(s) >= len(sub) {
			// Case-insensitive contains without strings import loop
			for i := 0; i <= len(s)-len(sub); i++ {
				if equalFold(s[i:i+len(sub)], sub) {
					return true
				}
			}
		}
	}
	return false
}

func equalFold(a, b string) bool {
	if len(a) != len(b) {
		return false
	}
	for i := 0; i < len(a); i++ {
		ca, cb := a[i], b[i]
		if ca >= 'A' && ca <= 'Z' {
			ca += 32
		}
		if cb >= 'A' && cb <= 'Z' {
			cb += 32
		}
		if ca != cb {
			return false
		}
	}
	return true
}

func errStatus(err error) string {
	if err == nil {
		return "success"
	}
	return "error"
}

// ── Streaming io.ReadCloser helpers ───────────────────────────────────────────

// Ensure teeWriter implements io.Writer.
var _ io.Writer = (*teeWriter)(nil)

// ── Real scope enforcement on tool output files ───────────────────────────────
//
// filterOutputsInScope reads the canonical per-phase output files
// (subs.txt, live.txt, urls.txt) after each phase and removes any line whose
// host does not pass the ROE gate. This is the authoritative in-loop scope
// check; the ScopeFilter grep in executor.go is a best-effort pre-filter only.
func (p *Pipeline) filterOutputsInScope(scanID string, scan *activeScan) {
	if len(scan.req.Scope) == 0 {
		return // no scope configured — nothing to filter
	}
	scanID8 := scanID
	if len(scanID8) > 8 {
		scanID8 = scanID8[:8]
	}
	outDir := filepath.Join("/tmp/bb-scans", scanID8)

	fileNames := []string{
		scanID8 + "_subs.txt",
		scanID8 + "_live.txt",
		scanID8 + "_urls.txt",
	}
	for _, name := range fileNames {
		path := filepath.Join(outDir, name)
		if err := filterFileInScope(path, p.gate, scan.req.Scope, scan.req.Excluded); err != nil {
			log.Debug().Err(err).Str("file", name).Msg("pipeline: scope filter skipped")
		}
	}
}

// filterFileInScope reads a line-delimited file, removes lines whose host is
// out-of-scope, and writes the result back atomically.
func filterFileInScope(path string, g *roe.Gate, scope, excluded []string) error {
	raw, err := os.ReadFile(path)
	if err != nil {
		return err // file may not exist yet — not an error
	}
	lines := bytes.Split(raw, []byte("\n"))
	kept := lines[:0]
	for _, line := range lines {
		s := string(bytes.TrimSpace(line))
		if s == "" {
			continue
		}
		if g.CheckURL(s, scope, excluded) {
			kept = append(kept, line)
		}
	}
	out := bytes.Join(kept, []byte("\n"))
	if len(out) > 0 {
		out = append(out, '\n')
	}
	return os.WriteFile(path, out, 0o644)
}

// ── Scan Resume ───────────────────────────────────────────────────────────────

// HandleListResumable lists scans that were interrupted and can be resumed.
func (p *Pipeline) HandleListResumable(w http.ResponseWriter, r *http.Request) {
	if p.checkpoints == nil {
		w.Header().Set("Content-Type", "application/json")
		w.Write([]byte(`[]`))
		return
	}
	ids, err := p.checkpoints.ListResumable(r.Context(), 5*time.Minute)
	if err != nil {
		http.Error(w, `{"error":"failed to list resumable scans"}`, http.StatusInternalServerError)
		return
	}
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(ids)
}

// HandleResume restarts a previously interrupted scan from its checkpoint.
func (p *Pipeline) HandleResume(w http.ResponseWriter, r *http.Request) {
	scanID := chi.URLParam(r, "scanID")
	if p.checkpoints == nil {
		http.Error(w, `{"error":"checkpoints not configured"}`, http.StatusServiceUnavailable)
		return
	}
	cp, err := p.checkpoints.Load(r.Context(), scanID)
	if err != nil {
		http.Error(w, `{"error":"checkpoint not found"}`, http.StatusNotFound)
		return
	}

	scan := &activeScan{
		req:    cp.Request,
		phase:  Phase(cp.Phase),
		status: StatusRunning,
	}

	p.scansMu.Lock()
	if _, exists := p.scans[scanID]; exists {
		p.scansMu.Unlock()
		http.Error(w, `{"error":"scan already running"}`, http.StatusConflict)
		return
	}
	ctx, cancel := context.WithCancel(r.Context())
	scan.cancelFn = cancel
	p.scans[scanID] = scan
	p.scansMu.Unlock()

	go func() {
		defer func() {
			p.scansMu.Lock()
			delete(p.scans, scanID)
			p.scansMu.Unlock()
			_ = p.checkpoints.Delete(context.Background(), scanID)
		}()
		p.run(ctx, scanID, scan)
	}()

	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]string{
		"scan_id": scanID,
		"status":  "resumed",
		"phase":   string(cp.Phase),
	})
}

// mergeUnique appends items from b to a, skipping duplicates.
func mergeUnique(a, b []string) []string {
	seen := make(map[string]bool, len(a))
	for _, v := range a {
		seen[v] = true
	}
	for _, v := range b {
		if !seen[v] {
			a = append(a, v)
			seen[v] = true
		}
	}
	return a
}

// ── Adaptive ratelimiter: observe HTTP status codes from tool output ───────────

// observeHTTPStatuses parses httpx/nuclei JSONL output and calls RecordResponse
// on the rate limiter for every line that has a "status_code" field.
// This is the missing link that makes the adaptive ratelimit engine actually work:
// instead of just counting requests, it now adjusts rate on observed 429/503 responses.
func (p *Pipeline) observeHTTPStatuses(target, platform string, buf *bytes.Buffer) {
	if p.rateLimiter == nil {
		return
	}
	limiter := p.rateLimiter.ForTarget(target, ratelimitPlatform(platform))

	data := buf.Bytes()
	for len(data) > 0 {
		// Find next line
		end := 0
		for end < len(data) && data[end] != '\n' {
			end++
		}
		line := data[:end]
		if end < len(data) {
			data = data[end+1:]
		} else {
			data = nil
		}
		if len(line) == 0 {
			continue
		}

		// Fast path: look for "status_code" without full JSON parse
		// httpx outputs: {"url":"...","status_code":429,...}
		const marker = `"status_code":`
		idx := bytes.Index(line, []byte(marker))
		if idx < 0 {
			continue
		}
		rest := line[idx+len(marker):]
		// Parse the integer
		code := 0
		for i, b := range rest {
			if b >= '0' && b <= '9' {
				code = code*10 + int(b-'0')
			} else if i > 0 {
				break
			}
		}
		if code > 0 {
			limiter.RecordResponse(code, 0)
		}
	}
}

// ratelimitPlatform converts a platform string to the ratelimit.Platform type.
func ratelimitPlatform(p string) ratelimit.Platform {
	switch p {
	case "hackerone":
		return ratelimit.PlatformHackerOne
	case "bugcrowd":
		return ratelimit.PlatformBugcrowd
	case "intigriti":
		return ratelimit.PlatformIntigriti
	case "private":
		return ratelimit.PlatformPrivate
	default:
		return ratelimit.PlatformBugcrowd // conservative default
	}
}

// ── reconFTW integration ──────────────────────────────────────────────────────

// reconFTWOutputDir returns the reconFTW output directory for a given target.
// reconFTW writes to ~/reconftw/Recon/<domain>/ by default.
// Can be overridden with RECONFTW_OUTPUT env var.
func (p *Pipeline) reconFTWOutputDir(target string) string {
	if dir := os.Getenv("RECONFTW_OUTPUT"); dir != "" {
		return filepath.Join(dir, target)
	}
	home, err := os.UserHomeDir()
	if err != nil {
		home = "/root"
	}
	return filepath.Join(home, "reconftw", "Recon", target)
}

// ── Scan rate limiter ─────────────────────────────────────────────────────────

const maxConcurrentScansPerUser = 3

// checkScanRateLimit enforces max concurrent scans per user bazat pe plan.
//
// FIX: userKey = JWT userID (nu IP sau header).
// Limita vine din planul de abonament stocat în Redis:
//   Solo:         1 scan concurent
//   Professional: 3 scanuri concurente
//   Team:         5 scanuri concurente (per seat)
//
// Cheia Redis: scan:concurrent:{userID} → nr scanuri active
// La final scan: decrementScanRateLimit() decrementează contorul.
// TTL 6h — safety net dacă decrement e ratat (crash, timeout).
func (p *Pipeline) checkScanRateLimit(ctx context.Context, userID string) error {
	// Citește limita din planul userului
	maxConc := p.getMaxConcurrentForUser(ctx, userID)

	key   := "scan:concurrent:" + userID
	count, err := p.cache.Raw().Incr(ctx, key).Result()
	if err != nil {
		// Fail open pe eroare Redis — preferăm disponibilitate
		log.Warn().Err(err).Str("user", userID).Msg("[pipeline] scan rate limit Redis error — fail open")
		return nil
	}

	// Prima incrementare — setează TTL 6h (safety net)
	if count == 1 {
		p.cache.Raw().Expire(ctx, key, 6*time.Hour)
	}

	if int(count) > maxConc {
		// Decrement — nu am pornit scanul
		p.cache.Raw().Decr(ctx, key)
		return fmt.Errorf(
			"ai %d scan(uri) active — planul tău permite maxim %d concurent(e). "+
				"Așteaptă finalizarea unui scan sau upgradează planul",
			count-1, maxConc,
		)
	}

	// Stochează și numărul total de scanuri pornite luna asta
	// (folosit de billing pentru limita lunară)
	monthKey := fmt.Sprintf("scan:monthly:%s:%s", userID, time.Now().Format("2006-01"))
	p.cache.Raw().Incr(ctx, monthKey)
	p.cache.Raw().Expire(ctx, monthKey, 35*24*time.Hour) // TTL 35 zile

	return nil
}

// getMaxConcurrentForUser returnează numărul maxim de scanuri concurente
// bazat pe planul de abonament al userului din Redis.
func (p *Pipeline) getMaxConcurrentForUser(ctx context.Context, userID string) int {
	planKey := "billing:plan:" + userID
	plan, err := p.cache.Raw().Get(ctx, planKey).Result()
	if err != nil {
		// Fără plan = Solo (cel mai restrictiv)
		return 1
	}
	switch plan {
	case "professional":
		return 3
	case "team":
		return 5
	case "solo":
		return 1
	default:
		return 1
	}
}

// decrementScanRateLimit decrementează contorul când scanul se termină.
func (p *Pipeline) decrementScanRateLimit(ctx context.Context, userID string) {
	key := "scan:concurrent:" + userID
	val, _ := p.cache.Raw().Decr(ctx, key).Result()
	// Nu lăsa să scadă sub 0 (safety)
	if val < 0 {
		p.cache.Raw().Set(ctx, key, 0, 6*time.Hour)
	}
}
