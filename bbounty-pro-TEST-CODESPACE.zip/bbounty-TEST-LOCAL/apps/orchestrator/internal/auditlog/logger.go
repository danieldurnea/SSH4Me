// Package auditlog — Persistent audit trail for security-sensitive actions.
//
// HARDENED v3.3.2:
// - HMAC-SHA256 chain adăugat: fiecare event conține HMAC(payload + prev_hash)
//   → orice modificare sau ștergere e detectabilă via VerifyChain()
// - Chain secret: AUDIT_HMAC_SECRET env var (required în producție)
// - PrevHash + EventHash adăugate în Event struct și în Postgres schema
//
// Usage:
//   logger := auditlog.New(redis, postgres)
//   go logger.Run(ctx)
//   logger.Log(ctx, AuditEvent{...})
//   verified, err := logger.VerifyChain(ctx, "2026-05-19")

package auditlog

import (
	"context"
	"crypto/hmac"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"os"
	"sync"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/redis/go-redis/v9"
	"github.com/rs/zerolog/log"
)

const (
	pubsubChannel = "audit:events"
	bufferSize    = 1024
)

// EventType enumerates auditable actions.
type EventType string

const (
	// Auth events
	EventLoginSuccess  EventType = "auth.login.success"
	EventLoginFailure  EventType = "auth.login.failure"
	EventRegister      EventType = "auth.register"
	EventLogout        EventType = "auth.logout"
	EventInviteCreate  EventType = "auth.invite.create"
	EventRoleChange    EventType = "auth.role.change"
	EventDeactivate    EventType = "auth.deactivate"
	EventTokenRefresh  EventType = "auth.token.refresh"

	// Scan events
	EventScanStart    EventType = "scan.start"
	EventScanStop     EventType = "scan.stop"
	EventROEViolation EventType = "scan.roe.violation"

	// Findings events
	EventFindingCreate EventType = "finding.create"
	EventFindingUpdate EventType = "finding.update"
	EventFindingDelete EventType = "finding.delete"

	// Admin events
	EventConfigChange EventType = "admin.config.change"
	EventDataExport   EventType = "admin.export"
)

// Event represents a single audit record.
type Event struct {
	ID         string         `json:"id"                    db:"id"`
	Type       EventType      `json:"type"                  db:"event_type"`
	Timestamp  time.Time      `json:"timestamp"             db:"timestamp"`
	UserID     string         `json:"user_id"               db:"user_id"`
	Username   string         `json:"username"              db:"username"`
	UserRole   string         `json:"role"                  db:"user_role"`
	IPAddress  string         `json:"ip"                    db:"ip_address"`
	UserAgent  string         `json:"user_agent"            db:"user_agent"`
	ResourceID string         `json:"resource_id,omitempty" db:"resource_id"`
	Action     string         `json:"action"                db:"action"`
	Success    bool           `json:"success"               db:"success"`
	Metadata   map[string]any `json:"metadata,omitempty"    db:"metadata"`
	ErrorMsg   string         `json:"error,omitempty"       db:"error_message"`

	// HMAC chain — adăugat în v3.3.2-HARDENED
	PrevHash  string `json:"prev_hash"  db:"prev_hash"`  // hash-ul eventului anterior
	EventHash string `json:"event_hash" db:"event_hash"` // HMAC(payload + prev_hash)
}

// Logger handles audit event persistence with HMAC chaining.
type Logger struct {
	cache      *cache.Client
	db         *pgxpool.Pool
	hmacSecret []byte
	chainMu    sync.Mutex // serializează actualizările chain-ului
}

const chainKeyLatest = "audit:chain:latest_hash"

func New(c *cache.Client, db *pgxpool.Pool) *Logger {
	secret := os.Getenv("AUDIT_HMAC_SECRET")
	if secret == "" {
		log.Warn().Msg("auditlog: AUDIT_HMAC_SECRET not set — chain integrity disabled")
	}
	return &Logger{cache: c, db: db, hmacSecret: []byte(secret)}
}

// computeHMAC returnează hex(HMAC-SHA256(payload + "|" + prevHash, secret)).
func (l *Logger) computeHMAC(payload, prevHash string) string {
	if len(l.hmacSecret) == 0 {
		return ""
	}
	mac := hmac.New(sha256.New, l.hmacSecret)
	mac.Write([]byte(payload))
	mac.Write([]byte("|"))
	mac.Write([]byte(prevHash))
	return hex.EncodeToString(mac.Sum(nil))
}

// VerifyChain replays toate eventurile dintr-un stream și validează HMAC chain.
// Returnează numărul de evenimente verificate și prima eroare de integritate.
func (l *Logger) VerifyChain(ctx context.Context, streamDate string) (int, error) {
	if len(l.hmacSecret) == 0 {
		return 0, fmt.Errorf("AUDIT_HMAC_SECRET not set — cannot verify chain")
	}
	streamKey := "audit:stream:" + streamDate
	entries, err := l.cache.Raw().XRange(ctx, streamKey, "-", "+").Result()
	if err != nil {
		return 0, fmt.Errorf("xrange: %w", err)
	}
	prevHash := ""
	for i, entry := range entries {
		raw, ok := entry.Values["event"].(string)
		if !ok {
			return i, fmt.Errorf("entry %d: missing event field", i)
		}
		var e Event
		if err := json.Unmarshal([]byte(raw), &e); err != nil {
			return i, fmt.Errorf("entry %d: unmarshal: %w", i, err)
		}
		if e.PrevHash != prevHash {
			return i, fmt.Errorf("entry %d (id=%s): chain broken — prev_hash mismatch", i, e.ID)
		}
		payloadBytes, _ := json.Marshal(struct {
			ID       string         `json:"id"`
			Type     EventType      `json:"type"`
			UserID   string         `json:"user_id"`
			Action   string         `json:"action"`
			Success  bool           `json:"success"`
			Metadata map[string]any `json:"metadata,omitempty"`
		}{e.ID, e.Type, e.UserID, e.Action, e.Success, e.Metadata})
		expected := l.computeHMAC(string(payloadBytes), prevHash)
		if !hmac.Equal([]byte(e.EventHash), []byte(expected)) {
			return i, fmt.Errorf("entry %d (id=%s): HMAC mismatch — event tampered", i, e.ID)
		}
		prevHash = e.EventHash
	}
	return len(entries), nil
}

// Log publishes an audit event.
//
// IMPORTANT: This is fire-and-forget. If the publish fails, we log the error
// but don't propagate it — auditing must never break primary functionality.
//
// LIMITATION: events lost between publish and Postgres write are gone.
// For high-stakes deployments, switch to Redis Streams (XADD) which persist.
func (l *Logger) Log(ctx context.Context, e Event) {
	if e.ID == "" {
		e.ID = fmt.Sprintf("%d-%s", time.Now().UnixNano(), e.Type)
	}
	if e.Timestamp.IsZero() {
		e.Timestamp = time.Now().UTC()
	}

	// ── HMAC chain (atomic sub mutex) ────────────────────────────────────────
	if len(l.hmacSecret) > 0 {
		l.chainMu.Lock()
		prevHash, _ := l.cache.Raw().Get(ctx, chainKeyLatest).Result()
		e.PrevHash = prevHash

		payloadBytes, _ := json.Marshal(struct {
			ID       string         `json:"id"`
			Type     EventType      `json:"type"`
			UserID   string         `json:"user_id"`
			Action   string         `json:"action"`
			Success  bool           `json:"success"`
			Metadata map[string]any `json:"metadata,omitempty"`
		}{e.ID, e.Type, e.UserID, e.Action, e.Success, e.Metadata})

		e.EventHash = l.computeHMAC(string(payloadBytes), prevHash)
		l.cache.Raw().Set(ctx, chainKeyLatest, e.EventHash, 0)
		l.chainMu.Unlock()
	}

	data, err := json.Marshal(e)
	if err != nil {
		log.Error().Err(err).Msg("auditlog: marshal failed")
		return
	}

	if err := l.cache.Raw().Publish(ctx, pubsubChannel, data).Err(); err != nil {
		log.Warn().Err(err).Msg("auditlog: redis publish failed")
	}

	streamKey := "audit:stream:" + time.Now().UTC().Format("2006-01-02")
	l.cache.Raw().XAdd(ctx, &redis.XAddArgs{
		Stream: streamKey,
		MaxLen: 100000,
		Approx: true,
		Values: map[string]any{"event": string(data)},
	})
	l.cache.Raw().Expire(ctx, streamKey, 30*24*time.Hour)
}

// Run starts the background Postgres writer.
// Subscribes to Redis pub/sub and persists events to Postgres.
//
// LIMITATION: If Postgres is down, events accumulate in memory and may be
// lost on orchestrator crash. For production, replace with Redis Streams
// + consumer groups (XREADGROUP) which guarantees at-least-once delivery.
func (l *Logger) Run(ctx context.Context) {
	if l.db == nil {
		log.Warn().Msg("auditlog: no Postgres pool — events stored only in Redis")
		return
	}

	pubsub := l.cache.Raw().Subscribe(ctx, pubsubChannel)
	defer pubsub.Close()

	ch := pubsub.Channel(redis.WithChannelSize(bufferSize))
	log.Info().Str("channel", pubsubChannel).Msg("auditlog: writer started")

	for {
		select {
		case <-ctx.Done():
			return
		case msg, ok := <-ch:
			if !ok {
				return
			}
			var e Event
			if err := json.Unmarshal([]byte(msg.Payload), &e); err != nil {
				log.Warn().Err(err).Msg("auditlog: unmarshal failed")
				continue
			}
			if err := l.writeToPostgres(ctx, e); err != nil {
				log.Error().Err(err).Str("event", string(e.Type)).Msg("auditlog: postgres write failed")
				// Event is still in Redis stream as fallback
			}
		}
	}
}

func (l *Logger) writeToPostgres(ctx context.Context, e Event) error {
	metaJSON, _ := json.Marshal(e.Metadata)
	_, err := l.db.Exec(ctx, `
		INSERT INTO audit_log (
			id, event_type, timestamp, user_id, username, user_role,
			ip_address, user_agent, resource_id, action, success, metadata, error_message
		) VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12, $13)
		ON CONFLICT (id) DO NOTHING
	`,
		e.ID, e.Type, e.Timestamp, e.UserID, e.Username, e.UserRole,
		e.IPAddress, e.UserAgent, e.ResourceID, e.Action, e.Success,
		metaJSON, e.ErrorMsg)
	return err
}

// Query searches audit events. Used by admin dashboard.
//
// LIMITATION: Only basic filters supported (user, type, time range).
// No full-text search on metadata. For complex queries, query Postgres directly.
func (l *Logger) Query(ctx context.Context, opts QueryOptions) ([]Event, error) {
	if l.db == nil {
		return nil, fmt.Errorf("auditlog: query requires Postgres")
	}

	q := `SELECT id, event_type, timestamp, user_id, username, user_role,
		ip_address, user_agent, resource_id, action, success, metadata, error_message
		FROM audit_log WHERE 1=1`
	args := []any{}
	idx := 1

	if opts.UserID != "" {
		q += fmt.Sprintf(" AND user_id = $%d", idx)
		args = append(args, opts.UserID)
		idx++
	}
	if opts.EventType != "" {
		q += fmt.Sprintf(" AND event_type = $%d", idx)
		args = append(args, opts.EventType)
		idx++
	}
	if !opts.Since.IsZero() {
		q += fmt.Sprintf(" AND timestamp >= $%d", idx)
		args = append(args, opts.Since)
		idx++
	}
	q += " ORDER BY timestamp DESC LIMIT 500"

	rows, err := l.db.Query(ctx, q, args...)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var events []Event
	for rows.Next() {
		var e Event
		var metaJSON []byte
		if err := rows.Scan(&e.ID, &e.Type, &e.Timestamp, &e.UserID, &e.Username,
			&e.UserRole, &e.IPAddress, &e.UserAgent, &e.ResourceID,
			&e.Action, &e.Success, &metaJSON, &e.ErrorMsg); err != nil {
			continue
		}
		if len(metaJSON) > 0 {
			json.Unmarshal(metaJSON, &e.Metadata)
		}
		events = append(events, e)
	}
	return events, nil
}

type QueryOptions struct {
	UserID    string
	EventType EventType
	Since     time.Time
	Limit     int
}
