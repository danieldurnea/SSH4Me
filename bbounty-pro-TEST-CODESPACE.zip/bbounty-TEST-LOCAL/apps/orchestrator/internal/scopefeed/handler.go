package scopefeed

// Handler expune scope feed via REST API.
//
// Endpoints:
//   GET  /api/v1/scope/lookup?target=example.com  → lookup complet
//   GET  /api/v1/scope/check?target=example.com   → simplu in/out scope
//   GET  /api/v1/scope/stats                       → statistici feed
//   POST /api/v1/scope/suggest                     → sugestii scope pentru un scan nou

import (
	"encoding/json"
	"net/http"

	"github.com/go-chi/chi/v5"
)

type Handler struct {
	client *Client
}

func NewHandler(c *Client) *Handler {
	return &Handler{client: c}
}

func (h *Handler) Routes(r chi.Router) {
	r.Get("/lookup", h.handleLookup)
	r.Get("/check",  h.handleCheck)
	r.Get("/stats",  h.handleStats)
	r.Post("/suggest", h.handleSuggest)
}

// GET /api/v1/scope/lookup?target=example.com
func (h *Handler) handleLookup(w http.ResponseWriter, r *http.Request) {
	target := r.URL.Query().Get("target")
	if target == "" {
		http.Error(w, `{"error":"target required"}`, http.StatusBadRequest)
		return
	}
	result := h.client.Lookup(target)
	writeJSON(w, result)
}

// GET /api/v1/scope/check?target=example.com
// Răspuns simplu: in_scope, out_of_scope, reason
func (h *Handler) handleCheck(w http.ResponseWriter, r *http.Request) {
	target := r.URL.Query().Get("target")
	if target == "" {
		http.Error(w, `{"error":"target required"}`, http.StatusBadRequest)
		return
	}

	blocked, reason := h.client.IsOutOfScope(target)
	inScope := h.client.IsInScope(target)

	writeJSON(w, map[string]any{
		"target":        target,
		"in_scope":      inScope,
		"out_of_scope":  blocked,
		"reason":        reason,
		"source":        "rix4uni/scope",
	})
}

// GET /api/v1/scope/stats
func (h *Handler) handleStats(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, h.client.Stats())
}

// POST /api/v1/scope/suggest
// Body: {"target": "example.com"}
// Returnează: programe care conțin targetul + domenii adiacente sugestionate
func (h *Handler) handleSuggest(w http.ResponseWriter, r *http.Request) {
	var body struct {
		Target string `json:"target"`
	}
	if err := json.NewDecoder(r.Body).Decode(&body); err != nil || body.Target == "" {
		http.Error(w, `{"error":"target required"}`, http.StatusBadRequest)
		return
	}

	result := h.client.Lookup(body.Target)
	writeJSON(w, map[string]any{
		"target":    body.Target,
		"programs":  result.Programs,
		"suggested": result.Suggested,
		"in_scope":  result.InScope,
		"source":    "https://github.com/rix4uni/scope",
		"credit":    "rix4uni",
	})
}

func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(v)
}
