// Package scopefeed — rix4uni/scope integration
// Source: https://github.com/rix4uni/scope
//
// Ce face:
//   - Descarcă scope-urile publice din HackerOne, Bugcrowd, Intigriti, YesWeHack
//   - Se auto-refreshează la fiecare 15 minute (sursa se actualizează la 10 min)
//   - Integrare cu ROE Gate: blochează scanarea domeniilor out-of-scope
//   - Scope expansion: sugerează domenii in-scope din același program
//   - Program discovery: identifică programul pentru un domeniu dat

package scopefeed

import (
	"bufio"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/rs/zerolog/log"
)

const (
	baseURL        = "https://raw.githubusercontent.com/rix4uni/scope/main/data"
	refreshInterval = 15 * time.Minute
	fetchTimeout    = 20 * time.Second
)

// Feed URLs din rix4uni/scope
var feedURLs = map[string]string{
	"inscope":    baseURL + "/inscope.txt",
	"outofscope": baseURL + "/outofscope.txt",

	// Per platformă
	"hackerone_in":   baseURL + "/Hackerone/hackerone_inscope.txt",
	"hackerone_out":  baseURL + "/Hackerone/hackerone_outofscope.txt",
	"bugcrowd_in":    baseURL + "/Bugcrowd/bugcrowd_inscope.txt",
	"bugcrowd_out":   baseURL + "/Bugcrowd/bugcrowd_outofscope.txt",
	"intigriti_in":   baseURL + "/Intigriti/intigriti_inscope.txt",
	"intigriti_out":  baseURL + "/Intigriti/intigriti_outofscope.txt",
	"yeswehack_in":   baseURL + "/Yeswehack/yeswehack_inscope.txt",
	"yeswehack_out":  baseURL + "/Yeswehack/yeswehack_outofscope.txt",

	// Wildcard-uri separate (pentru matching mai precis)
	"wildcards_in":  baseURL + "/Wildcards/inscope_wildcards.txt",
	"wildcards_out": baseURL + "/Wildcards/outofscope_wildcards.txt",

	// Programs JSON — pentru discovery (nume program, payout, URL)
	"programs": "https://raw.githubusercontent.com/rix4uni/scope/main/programs.json",
}

// Program reprezintă un program de bug bounty cu scope-ul lui.
type Program struct {
	Name    string   `json:"name"`
	URL     string   `json:"url"`
	Platform string  `json:"platform"`
	MaxPayout int    `json:"max_payout"`
	InScope []string `json:"in_scope"`
	OutScope []string `json:"out_scope"`
}

// ScopeResult returnează rezultatul unui lookup.
type ScopeResult struct {
	Target    string    `json:"target"`
	InScope   bool      `json:"in_scope"`
	OutScope  bool      `json:"out_of_scope"`
	Programs  []Program `json:"programs,omitempty"`   // programe care conțin targetul
	Suggested []string  `json:"suggested,omitempty"` // alte domenii in-scope din același program
}

// Client gestionează feed-ul de scope-uri.
type Client struct {
	mu          sync.RWMutex
	inScope     map[string]bool   // exact domains + wildcards in-scope
	outScope    map[string]bool   // exact domains + wildcards out-of-scope
	wildcards   []string          // wildcard patterns in-scope (ex: *.tidal.com)
	wildcardOut []string          // wildcard patterns out-of-scope
	programs    []Program         // program list for discovery
	lastUpdate  time.Time
	httpClient  *http.Client
}

func NewClient() *Client {
	return &Client{
		inScope:    make(map[string]bool),
		outScope:   make(map[string]bool),
		httpClient: &http.Client{Timeout: fetchTimeout},
	}
}

// Start inițiază un refresh imediat și pornește auto-refresh în background.
func (c *Client) Start(ctx context.Context) {
	c.refresh(ctx)
	go func() {
		ticker := time.NewTicker(refreshInterval)
		defer ticker.Stop()
		for {
			select {
			case <-ctx.Done():
				return
			case <-ticker.C:
				c.refresh(ctx)
			}
		}
	}()
	log.Info().Str("interval", refreshInterval.String()).Msg("scopefeed: started auto-refresh from rix4uni/scope")
}

// IsOutOfScope returnează true dacă targetul e explicit out-of-scope într-un program.
// Folosit de ROE Gate ca layer suplimentar de protecție.
func (c *Client) IsOutOfScope(target string) (bool, string) {
	c.mu.RLock()
	defer c.mu.RUnlock()

	host := normalizeHost(target)

	// Exact match
	if c.outScope[host] {
		return true, fmt.Sprintf("%s e explicit out-of-scope într-un program de bounty", host)
	}

	// Wildcard match out-of-scope
	for _, pattern := range c.wildcardOut {
		if matchWildcard(pattern, host) {
			return true, fmt.Sprintf("%s matches out-of-scope pattern %s", host, pattern)
		}
	}

	return false, ""
}

// IsInScope returnează true dacă targetul e in-scope într-un program cunoscut.
func (c *Client) IsInScope(target string) bool {
	c.mu.RLock()
	defer c.mu.RUnlock()

	host := normalizeHost(target)
	if c.inScope[host] {
		return true
	}
	for _, pattern := range c.wildcards {
		if matchWildcard(pattern, host) {
			return true
		}
	}
	return false
}

// Lookup returnează informații complete despre un target:
// programele care îl conțin, dacă e in/out-of-scope, sugestii de domenii adiacente.
func (c *Client) Lookup(target string) ScopeResult {
	c.mu.RLock()
	defer c.mu.RUnlock()

	host := normalizeHost(target)
	result := ScopeResult{Target: host}

	// Check in-scope
	if c.inScope[host] {
		result.InScope = true
	}
	for _, pattern := range c.wildcards {
		if matchWildcard(pattern, host) {
			result.InScope = true
			break
		}
	}

	// Check out-of-scope
	if c.outScope[host] {
		result.OutScope = true
	}
	for _, pattern := range c.wildcardOut {
		if matchWildcard(pattern, host) {
			result.OutScope = true
			break
		}
	}

	// Program discovery — găsește programele care conțin targetul
	for _, prog := range c.programs {
		for _, scope := range prog.InScope {
			if normalizeHost(scope) == host || matchWildcard(scope, host) {
				result.Programs = append(result.Programs, prog)
				// Sugerează celelalte domenii in-scope din același program
				for _, s := range prog.InScope {
					if normalizeHost(s) != host {
						result.Suggested = append(result.Suggested, s)
					}
				}
				break
			}
		}
	}

	return result
}

// Stats returnează statistici despre datele încărcate.
func (c *Client) Stats() map[string]any {
	c.mu.RLock()
	defer c.mu.RUnlock()
	return map[string]any{
		"in_scope_count":      len(c.inScope),
		"out_of_scope_count":  len(c.outScope),
		"wildcards_in":        len(c.wildcards),
		"wildcards_out":       len(c.wildcardOut),
		"programs_count":      len(c.programs),
		"last_update":         c.lastUpdate.Format(time.RFC3339),
		"source":              "https://github.com/rix4uni/scope",
	}
}

// ── Internal ──────────────────────────────────────────────────────────────────

func (c *Client) refresh(ctx context.Context) {
	log.Info().Msg("scopefeed: refreshing from rix4uni/scope...")

	inScope  := make(map[string]bool)
	outScope := make(map[string]bool)
	var wildcards, wildcardOut []string

	// Fetch in-scope
	if lines, err := c.fetchLines(ctx, feedURLs["inscope"]); err == nil {
		for _, line := range lines {
			host := normalizeHost(line)
			if strings.HasPrefix(line, "*.") {
				wildcards = append(wildcards, host)
			} else {
				inScope[host] = true
			}
		}
	} else {
		log.Warn().Err(err).Msg("scopefeed: failed to fetch inscope.txt")
	}

	// Fetch wildcard in-scope (more complete)
	if lines, err := c.fetchLines(ctx, feedURLs["wildcards_in"]); err == nil {
		for _, line := range lines {
			wildcards = append(wildcards, normalizeHost(line))
		}
	}

	// Fetch out-of-scope
	if lines, err := c.fetchLines(ctx, feedURLs["outofscope"]); err == nil {
		for _, line := range lines {
			host := normalizeHost(line)
			if strings.HasPrefix(line, "*.") {
				wildcardOut = append(wildcardOut, host)
			} else {
				outScope[host] = true
			}
		}
	} else {
		log.Warn().Err(err).Msg("scopefeed: failed to fetch outofscope.txt")
	}

	// Fetch wildcard out-of-scope
	if lines, err := c.fetchLines(ctx, feedURLs["wildcards_out"]); err == nil {
		for _, line := range lines {
			wildcardOut = append(wildcardOut, normalizeHost(line))
		}
	}

	// Fetch programs.json pentru discovery
	programs := c.fetchPrograms(ctx)

	c.mu.Lock()
	c.inScope     = inScope
	c.outScope    = outScope
	c.wildcards   = dedup(wildcards)
	c.wildcardOut = dedup(wildcardOut)
	c.programs    = programs
	c.lastUpdate  = time.Now()
	c.mu.Unlock()

	log.Info().
		Int("in_scope",  len(inScope)).
		Int("out_scope", len(outScope)).
		Int("wildcards", len(wildcards)).
		Int("programs",  len(programs)).
		Msg("scopefeed: refresh complete")
}

func (c *Client) fetchLines(ctx context.Context, url string) ([]string, error) {
	req, _ := http.NewRequestWithContext(ctx, "GET", url, nil)
	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()
	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("HTTP %d", resp.StatusCode)
	}
	return parseLines(resp.Body), nil
}

func (c *Client) fetchPrograms(ctx context.Context) []Program {
	req, _ := http.NewRequestWithContext(ctx, "GET", feedURLs["programs"], nil)
	resp, err := c.httpClient.Do(req)
	if err != nil {
		return nil
	}
	defer resp.Body.Close()

	var programs []Program
	if err := json.NewDecoder(resp.Body).Decode(&programs); err != nil {
		return nil
	}
	return programs
}

func parseLines(r io.Reader) []string {
	var lines []string
	scanner := bufio.NewScanner(r)
	scanner.Buffer(make([]byte, 2*1024*1024), 2*1024*1024)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		lines = append(lines, line)
	}
	return lines
}

func normalizeHost(s string) string {
	s = strings.ToLower(strings.TrimSpace(s))
	s = strings.TrimPrefix(s, "https://")
	s = strings.TrimPrefix(s, "http://")
	s = strings.TrimSuffix(s, "/")
	return s
}

// matchWildcard verifică dacă host se potrivește cu un pattern wildcard (ex: *.tidal.com)
func matchWildcard(pattern, host string) bool {
	pattern = strings.ToLower(pattern)
	host    = strings.ToLower(host)

	if !strings.HasPrefix(pattern, "*.") {
		return pattern == host
	}
	suffix := pattern[1:] // ex: .tidal.com
	return strings.HasSuffix(host, suffix) || host == suffix[1:]
}

func dedup(s []string) []string {
	seen := make(map[string]bool, len(s))
	out  := s[:0]
	for _, v := range s {
		if !seen[v] {
			seen[v] = true
			out = append(out, v)
		}
	}
	return out
}
