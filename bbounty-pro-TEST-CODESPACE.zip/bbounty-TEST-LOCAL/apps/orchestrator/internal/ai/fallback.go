// Item #16: AI client fallback when Anthropic API is unreachable.
//
// PARTIAL IMPLEMENTATION DISCLAIMER:
// - Cache layer for finding analyses (deterministic per-finding key)
// - Falls back to a minimal heuristic message if API + cache miss
// - NOT a real fallback model — just degraded UX
// - For real fallback, integrate local LLM (llama.cpp, ollama)

package ai

import (
	"context"
	"crypto/sha256"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/cache"
)

type CachedClient struct {
	primary *Client
	cache   *cache.Client
	ttl     time.Duration
}

func NewCachedClient(primary *Client, c *cache.Client) *CachedClient {
	return &CachedClient{
		primary: primary,
		cache:   c,
		ttl:     7 * 24 * time.Hour,
	}
}

// AnalyzeFindingCached checks cache before hitting API.
// Cache key is SHA(title|url|category) — same finding gets same analysis.
func (c *CachedClient) AnalyzeFindingCached(ctx context.Context, title, url, category string) (string, error) {
	key := analysisKey(title, url, category)

	var cached string
	if err := c.cache.GetJSON(ctx, key, &cached); err == nil && cached != "" {
		return cached, nil
	}

	if c.primary == nil {
		return fallbackAnalysis(category), nil
	}

	resp, err := c.primary.Complete(ctx,
		"You are a security expert. Analyze this finding in 2-3 sentences.",
		[]Message{{Role: "user", Content: "Title: " + title + "\nURL: " + url + "\nCategory: " + category}},
		512)
	if err != nil {
		return fallbackAnalysis(category), nil
	}

	c.cache.SetJSON(ctx, key, resp, c.ttl)
	return resp, nil
}

func analysisKey(title, url, category string) string {
	h := sha256.Sum256([]byte(title + "|" + url + "|" + category))
	return "ai:analysis:" + hex.EncodeToString(h[:8])
}

// fallbackAnalysis returns a deterministic generic analysis based on category.
// Used when AI API is unavailable.
func fallbackAnalysis(category string) string {
	templates := map[string]string{
		"XSS":        "Cross-site scripting vulnerability. Verify CSP and confirm the payload executes in a real browser.",
		"SQLi":       "Possible SQL injection. Confirm with sqlmap manually before reporting.",
		"SSRF":       "Server-side request forgery candidate. Test with internal IPs and metadata endpoints.",
		"IDOR":       "Insecure direct object reference. Verify by accessing resources owned by other users.",
		"RCE":        "Remote code execution candidate. Confirm with a benign command (id, hostname).",
		"Secrets":    "Exposed secret. Validate it works (or did at commit time) before reporting.",
		"CORS":       "CORS misconfiguration. Confirm credentials can be exfiltrated cross-origin.",
	}
	if t, ok := templates[category]; ok {
		return t + " (Fallback analysis — AI service unavailable.)"
	}
	return "Manual review required. (Fallback — AI service unavailable.)"
}

// HandleAnalyzeFindingCached is the HTTP handler version of AnalyzeFindingCached.
// Drop-in replacement for (*Client).HandleAnalyzeFinding — tries cache first,
// then API, then heuristic fallback. Never returns 500 on API failure.
func (c *CachedClient) HandleAnalyzeFindingCached(w http.ResponseWriter, r *http.Request) {
	var req struct {
		Finding struct {
			Title       string `json:"title"`
			Description string `json:"description"`
			URL         string `json:"url"`
			Method      string `json:"method"`
			Parameter   string `json:"parameter"`
			Payload     string `json:"payload"`
			Response    string `json:"response"`
			Category    string `json:"category"`
		} `json:"finding"`
	}
	if err := json.NewDecoder(r.Body).Decode(&req); err != nil {
		http.Error(w, `{"error":"invalid body"}`, http.StatusBadRequest)
		return
	}

	f := req.Finding
	category := f.Category
	if category == "" {
		category = "Other"
	}

	// Try cache first — deduplicates identical findings across scans
	cacheKey := analysisKey(f.Title, f.URL, category)
	var cached string
	if err := c.cache.GetJSON(r.Context(), cacheKey, &cached); err == nil && cached != "" {
		w.Header().Set("Content-Type", "application/json")
		w.Header().Set("X-Cache", "HIT")
		json.NewEncoder(w).Encode(map[string]string{"analysis": cached})
		return
	}

	// Cache miss — call primary AI
	content := fmt.Sprintf("Finding: %s\nURL: %s\nMethod: %s\nParameter: %s\nPayload: %s\nResponse snippet: %s\nDescription: %s",
		f.Title, f.URL, f.Method, f.Parameter, f.Payload, f.Response, f.Description)

	var analysis string
	if c.primary != nil {
		resp, err := c.primary.Complete(r.Context(),
			baseSystemPrompt+"\n\n---\n\n"+SystemPrompts["finding_analyze"],
			[]Message{{Role: "user", Content: content}},
			4096)
		if err == nil {
			analysis = resp
			// Populate cache for next hit
			_ = c.cache.SetJSON(r.Context(), cacheKey, resp, c.ttl)
		} else {
			analysis = fallbackAnalysis(category)
		}
	} else {
		analysis = fallbackAnalysis(category)
	}

	w.Header().Set("Content-Type", "application/json")
	w.Header().Set("X-Cache", "MISS")
	json.NewEncoder(w).Encode(map[string]string{"analysis": analysis})
}
