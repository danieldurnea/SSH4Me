package payloads

// Handler expune payload-urile din PayloadBox via REST API.
//
// Endpoints:
//   GET /api/v1/payloads                    → lista tuturor tipurilor disponibile
//   GET /api/v1/payloads/{type}             → lista payload-uri pentru un tip
//   GET /api/v1/payloads/{type}?limit=50    → primele N payload-uri
//   GET /api/v1/payloads/stats              → statistici (count per tip)

import (
	"encoding/json"
	"net/http"
	"strconv"

	"github.com/go-chi/chi/v5"
)

type Handler struct {
	registry *Registry
}

func NewHandler(reg *Registry) *Handler {
	return &Handler{registry: reg}
}

func (h *Handler) Routes(r chi.Router) {
	r.Get("/", h.handleList)
	r.Get("/stats", h.handleStats)
	r.Get("/{type}", h.handleGet)
}

func (h *Handler) handleList(w http.ResponseWriter, r *http.Request) {
	types := make([]string, 0, len(payloadSources))
	for t := range payloadSources {
		types = append(types, string(t))
	}
	writeJSON(w, map[string]any{
		"types":  types,
		"source": "https://github.com/payload-box",
		"credit": "Ismail Taşedelen (ismailtsdln)",
	})
}

func (h *Handler) handleStats(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, map[string]any{
		"stats":  h.registry.Stats(),
		"source": "payload-box by Ismail Taşedelen",
	})
}

func (h *Handler) handleGet(w http.ResponseWriter, r *http.Request) {
	pType := PayloadType(chi.URLParam(r, "type"))

	limitStr := r.URL.Query().Get("limit")
	limit := 0
	if limitStr != "" {
		limit, _ = strconv.Atoi(limitStr)
	}

	list, err := h.registry.Get(pType)
	if err != nil {
		http.Error(w, `{"error":"unknown payload type"}`, http.StatusNotFound)
		return
	}

	if limit > 0 && limit < len(list) {
		list = list[:limit]
	}

	writeJSON(w, map[string]any{
		"type":    pType,
		"count":   len(list),
		"payloads": list,
		"source":  "https://github.com/payload-box/" + string(pType) + "-payload-list",
		"credit":  "Ismail Taşedelen",
		"license": "MIT",
	})
}

func writeJSON(w http.ResponseWriter, v any) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(v)
}
