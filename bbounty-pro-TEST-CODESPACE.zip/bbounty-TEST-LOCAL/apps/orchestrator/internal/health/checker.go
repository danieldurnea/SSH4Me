// Package health — Liveness and readiness probes for the orchestrator.
//
// LIMITATION: This is a basic implementation. For production, consider:
//   - kubelet-style health caching (don't hit deps every probe)
//   - Circuit breakers per dependency
//   - Detailed metrics on probe latencies

package health

import (
	"context"
	"encoding/json"
	"net/http"
	"strings"
	"os"
	"sync"
	"time"

	"github.com/bbounty-pro/orchestrator/internal/cache"
	"github.com/jackc/pgx/v5/pgxpool"
)

// Probe is a single dependency health check.
type Probe struct {
	Name     string
	Critical bool // if true, failure makes /readyz return 503
	Check    func(context.Context) error
}

// Checker aggregates probes.
type Checker struct {
	probes []Probe
	mu     sync.RWMutex

	// cache last probe results to avoid hammering deps
	lastResults map[string]ProbeResult
	cacheTTL    time.Duration
}

type ProbeResult struct {
	Name     string `json:"name"`
	Healthy  bool   `json:"healthy"`
	Critical bool   `json:"critical"`
	Latency  string `json:"latency"`
	Error    string `json:"error,omitempty"`
	Checked  time.Time `json:"checked"`
}

// New creates a Checker with default probes.
func New(redis *cache.Client, db *pgxpool.Pool) *Checker {
	c := &Checker{
		lastResults: make(map[string]ProbeResult),
		cacheTTL:    5 * time.Second,
	}

	// Always check Redis — orchestrator can't function without it
	c.AddProbe(Probe{
		Name:     "redis",
		Critical: true,
		Check: func(ctx context.Context) error {
			return redis.Raw().Ping(ctx).Err()
		},
	})

	// Postgres only if configured
	if db != nil {
		c.AddProbe(Probe{
			Name:     "postgres",
			Critical: false, // findings work in Redis-only mode
			Check: func(ctx context.Context) error {
				return db.Ping(ctx)
			},
		})
	}

	// Disk space — basic check
	c.AddProbe(Probe{
		Name:     "disk",
		Critical: false,
		Check: func(ctx context.Context) error {
			// Try writing to /tmp
			f, err := os.CreateTemp("", "bbounty-health-*")
			if err != nil {
				return err
			}
			f.Close()
			os.Remove(f.Name())
			return nil
		},
	})

	return c
}

func (c *Checker) AddProbe(p Probe) {
	c.mu.Lock()
	c.probes = append(c.probes, p)
	c.mu.Unlock()
}

// runProbes executes all probes with caching.
func (c *Checker) runProbes(ctx context.Context) []ProbeResult {
	c.mu.Lock()
	probes := make([]Probe, len(c.probes))
	copy(probes, c.probes)
	cache := c.lastResults
	c.mu.Unlock()

	results := make([]ProbeResult, len(probes))
	now := time.Now()

	for i, p := range probes {
		// Use cached result if still fresh
		if cached, ok := cache[p.Name]; ok && now.Sub(cached.Checked) < c.cacheTTL {
			results[i] = cached
			continue
		}

		probeCtx, cancel := context.WithTimeout(ctx, 2*time.Second)
		start := time.Now()
		err := p.Check(probeCtx)
		cancel()
		latency := time.Since(start)

		r := ProbeResult{
			Name:     p.Name,
			Healthy:  err == nil,
			Critical: p.Critical,
			Latency:  latency.String(),
			Checked:  now,
		}
		if err != nil {
			r.Error = err.Error()
		}
		results[i] = r
	}

	// Update cache
	c.mu.Lock()
	for _, r := range results {
		c.lastResults[r.Name] = r
	}
	c.mu.Unlock()

	return results
}

// HandleLive returns 200 if process is running. No dependency checks.
// Used by container orchestrator for restart decisions.
func (c *Checker) HandleLive(w http.ResponseWriter, _ *http.Request) {
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]any{
		"status":  "alive",
		"version": versionShort(),
	})
}

// HandleReady returns 200 only if all critical dependencies are healthy.
// Used by load balancer to decide if traffic should be routed here.
func (c *Checker) HandleReady(w http.ResponseWriter, r *http.Request) {
	results := c.runProbes(r.Context())

	allCriticalHealthy := true
	for _, res := range results {
		if res.Critical && !res.Healthy {
			allCriticalHealthy = false
			break
		}
	}

	status := http.StatusOK
	statusStr := "ready"
	if !allCriticalHealthy {
		status = http.StatusServiceUnavailable
		statusStr = "not_ready"
	}

	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(map[string]any{
		"status": statusStr,
		"probes": results,
	})
}

// HandleHealth returns full status (legacy /healthz for backwards compat).
func (c *Checker) HandleHealth(w http.ResponseWriter, r *http.Request) {
	results := c.runProbes(r.Context())
	w.Header().Set("Content-Type", "application/json")
	json.NewEncoder(w).Encode(map[string]any{
		"status":  "ok",
		"status": statusStr,
		"probes": results,
	})
}

var startTime = time.Now()

// versionShort returns only major.minor to avoid fingerprintable version disclosure.
func versionShort() string {
	if Version == "dev" {
		return "dev"
	}
	// "3.3.1" -> "3.3"
	parts := strings.SplitN(Version, ".", 3)
	if len(parts) >= 2 {
		return parts[0] + "." + parts[1]
	}
	return Version
}

// Version is injected at build time via -ldflags.
// Build: go build -ldflags="-X github.com/bbounty-pro/orchestrator/internal/health.Version=3.3.1"
var Version = "dev"
