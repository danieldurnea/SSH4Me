"use client";

import { useState } from "react";
import { useRouter } from "next/navigation";
import { PipelineHeader }    from "@/components/pipeline/PipelineHeader";
import { StatsBar }          from "@/components/pipeline/StatsBar";
import { ROEGate }           from "@/components/roe/ROEGate";
import { ToolGrid }          from "@/components/arsenal/ToolGrid";
import { LiveTerminal }      from "@/components/terminal/LiveTerminal";
import { FindingsTable }     from "@/components/findings/FindingsTable";
import { AIAgent }           from "@/components/agent/AIAgent";
import { ReportTab }         from "@/components/report/ReportTab";
import { PriorityDashboard } from "@/components/priority/PriorityDashboard";
import { DiffViewer }        from "@/components/diff/DiffViewer";
import { RateLimitMonitor }  from "@/components/priority/RateLimitMonitor";
import { SkillsPanel }       from "@/components/skills/SkillsPanel";
import { TipsPanel }         from "@/components/tips/TipsPanel";
import { useScanStore }      from "@/lib/store";
import { useAuth }           from "@/hooks/useAuth";
import { cn }                from "@/lib/utils";
import {
  Shield, Zap, Target, FileText, Bot, Terminal,
  LayoutDashboard, GitCompare, Brain, Activity, LogOut, CreditCard,
  Sparkles, Lightbulb,
} from "lucide-react";

type Tab =
  | "pipeline" | "arsenal"  | "terminal"
  | "findings" | "priority" | "diff"
  | "agent"    | "report"   | "ratelimit"
  | "skills"   | "tips";

const TABS: { id: Tab; label: string; icon: typeof Shield; adminOnly?: boolean }[] = [
  { id: "pipeline",  label: "Pipeline",   icon: LayoutDashboard },
  { id: "arsenal",   label: "Arsenal",    icon: Zap },
  { id: "terminal",  label: "Terminal",   icon: Terminal },
  { id: "findings",  label: "Findings",   icon: Target },
  { id: "priority",  label: "Priority",   icon: Brain },
  { id: "diff",      label: "Delta",      icon: GitCompare },
  { id: "agent",     label: "AI Agent",   icon: Bot },
  { id: "report",    label: "Report",     icon: FileText },
  { id: "skills",    label: "Skills",     icon: Sparkles },
  { id: "tips",      label: "Tips",       icon: Lightbulb },
  { id: "ratelimit", label: "Rate Limit", icon: Activity, adminOnly: true },
];

export default function DashboardPage() {
  const [activeTab, setActiveTab]       = useState<Tab>("pipeline");
  const [roeConfirmed, setRoeConfirmed] = useState(false);
  const { scanID, isScanning, stats, phase } = useScanStore();
  const router = useRouter();
  const { user, loading, isAdmin, logout } = useAuth();

  if (loading) {
    return (
      <div className="min-h-screen bg-[#080c0e] flex items-center justify-center">
        <div className="text-[#00e5cc] text-sm font-mono animate-pulse tracking-widest">
          AUTHENTICATING...
        </div>
      </div>
    );
  }

  if (!user) return null;

  const visibleTabs = TABS.filter(t => !t.adminOnly || isAdmin);

  return (
    <div className="min-h-screen bg-[#080c0e] text-[#c8d8e0] font-mono overflow-hidden">
      {!roeConfirmed && <ROEGate onConfirm={() => setRoeConfirmed(true)} />}

      <div className={cn("flex flex-col h-screen",
        !roeConfirmed && "blur-sm pointer-events-none select-none")}>

        <PipelineHeader phase={phase} isScanning={isScanning} scanID={scanID} />
        <StatsBar stats={stats} />

        <nav className="flex items-stretch border-b border-[#1a2a32] bg-[#0a1015] overflow-x-auto">
          <div className="flex flex-1">
            {visibleTabs.map(({ id, label, icon: Icon }) => (
              <button
                key={id}
                onClick={() => setActiveTab(id)}
                className={cn(
                  "flex items-center gap-2 px-4 py-3 text-xs font-semibold",
                  "uppercase tracking-widest border-b-2 -mb-px whitespace-nowrap transition-all",
                  activeTab === id
                    ? "border-[#00e5cc] text-[#00e5cc]"
                    : "border-transparent text-[#4a6a7a] hover:text-[#8ab4c4]"
                )}
              >
                <Icon size={13} strokeWidth={2.5} />
                {label}
                {id === "findings" && stats.vulns > 0 && (
                  <span className="ml-1 px-1.5 py-0.5 text-[10px] bg-[#ff3a5c]/20 text-[#ff3a5c] rounded border border-[#ff3a5c]/30">
                    {stats.vulns}
                  </span>
                )}
              </button>
            ))}
          </div>

          {/* User + logout */}
          <div className="flex items-center gap-3 px-4 border-l border-[#1a2a32] flex-shrink-0">
            <div className="text-[10px]">
              <span className="text-[#4a8a9a]">{user.username}</span>
              <span className="text-[#1a3a4a] mx-1">·</span>
              <span className={cn("font-bold",
                user.role === "admin"  && "text-[#ff3a5c]",
                user.role === "hunter" && "text-[#00e5cc]",
                user.role === "viewer" && "text-[#4a6a7a]"
              )}>{user.role}</span>
              {user.totp_enabled && (
                <span className="ml-1 text-[#54b35f]" title="2FA enabled">🔐</span>
              )}
            </div>
            <button onClick={() => router.push("/billing")}
              className="p-1.5 text-[#2a4a5a] hover:text-[#00e5cc] transition-colors"
              title="Billing & Plans">
              <CreditCard size={13} />
            </button>
            <button onClick={logout}
              className="p-1.5 text-[#2a4a5a] hover:text-[#ff3a5c] transition-colors"
              title="Logout">
              <LogOut size={13} />
            </button>
          </div>
        </nav>

        <main className="flex-1 overflow-hidden">
          {activeTab === "pipeline"  && <div className="h-full p-4 overflow-y-auto"><PipelineHeader phase={phase} isScanning={isScanning} scanID={scanID} /></div>}
          {activeTab === "arsenal"   && <div className="h-full p-4 overflow-y-auto"><ToolGrid /></div>}
          {activeTab === "terminal"  && <div className="h-full"><LiveTerminal scanID={scanID} /></div>}
          {activeTab === "findings"  && <div className="h-full p-4 overflow-y-auto"><FindingsTable scanID={scanID} /></div>}
          {activeTab === "priority"  && <div className="h-full p-4 overflow-y-auto"><PriorityDashboard scanID={scanID} /></div>}
          {activeTab === "diff"      && <div className="h-full p-4 overflow-y-auto"><DiffViewer /></div>}
          {activeTab === "agent"     && <div className="h-full p-4 overflow-y-auto"><AIAgent /></div>}
          {activeTab === "report"    && <div className="h-full p-4 overflow-y-auto"><ReportTab scanID={scanID} /></div>}
          {activeTab === "skills"    && <div className="h-full overflow-hidden"><SkillsPanel scanID={scanID} /></div>}
          {activeTab === "tips"      && <div className="h-full overflow-hidden"><TipsPanel /></div>}
          {activeTab === "ratelimit" && <div className="h-full p-4 overflow-y-auto"><RateLimitMonitor /></div>}
        </main>
      </div>
    </div>
  );
}
