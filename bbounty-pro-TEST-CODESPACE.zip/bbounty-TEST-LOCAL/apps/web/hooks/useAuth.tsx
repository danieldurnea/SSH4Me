"use client";
import { useRouter } from "next/navigation";

// ── TEST MODE — No authentication required ────────────────────────────────────
// Login complet dezactivat pentru testare locală.
// Toți userii sunt tratați ca admin fără token/cookie.
// NU folosi în producție!

interface AuthUser {
  id: string;
  username: string;
  role: "admin" | "hunter" | "viewer";
  active: boolean;
  totp_enabled: boolean;
}

interface UseAuthReturn {
  user: AuthUser | null;
  loading: boolean;
  isAdmin: boolean;
  isHunter: boolean;
  logout: () => void;
}

// Mock user — mereu autentificat în test mode
const TEST_USER: AuthUser = {
  id:           "test-user-001",
  username:     "tester",
  role:         "admin",
  active:       true,
  totp_enabled: false,
};

export function useAuth(requireAuth = true): UseAuthReturn {
  const router = useRouter();

  return {
    user:     TEST_USER,
    loading:  false,
    isAdmin:  true,
    isHunter: true,
    logout:   () => router.push("/"),
  };
}

// CSRF stub — returneaza token gol în test mode
export function getCsrfToken(): string {
  return "test-csrf-token";
}

interface AuthUser {
  id: string;
  username: string;
  role: "admin" | "hunter" | "viewer";
  active: boolean;
  totp_enabled: boolean;
}

interface UseAuthReturn {
  user: AuthUser | null;
  loading: boolean;
  isAdmin: boolean;
  isHunter: boolean;
  logout: () => void;
}

// ── Cookie-based auth (httpOnly) ──────────────────────────────────────────────
// The access token lives in an httpOnly cookie (bb_access) set by the server.
// JS never touches the token — it only reads the CSRF token from bb_csrf cookie
// and sends it as X-CSRF-Token header on state-changing requests.
// This eliminates XSS token theft (sessionStorage was readable by any JS).

function getCsrfToken(): string {
  // bb_csrf cookie is NOT httpOnly — JS reads it for the double-submit pattern.
  const match = document.cookie.match(/(?:^|;\s*)bb_csrf=([^;]+)/);
  return match ? decodeURIComponent(match[1]) : "";
}

export function useAuth(requireAuth = true): UseAuthReturn {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [loading, setLoading] = useState(true);
  const router = useRouter();

  const check = useCallback(async () => {
    try {
      // credentials: 'include' sends httpOnly cookies automatically.
      // No Authorization header needed — server reads bb_access cookie.
      const res = await fetch("/auth/me", {
        credentials: "include",
      });
      if (!res.ok) throw new Error("unauthorized");
      const data = await res.json();
      setUser(data);
    } catch {
      if (requireAuth) router.push("/login");
    } finally {
      setLoading(false);
    }
  }, [requireAuth, router]);

  useEffect(() => {
    check();
  }, [check]);

  const logout = useCallback(async () => {
    try {
      await fetch("/auth/logout", {
        method: "POST",
        credentials: "include",
        headers: {
          // CSRF double-submit: send cookie value in header
          "X-CSRF-Token": getCsrfToken(),
        },
      });
    } catch {
      // Ignore network errors — clear local state regardless
    }
    setUser(null);
    router.push("/login");
  }, [router]);

  return {
    user,
    loading,
    isAdmin:  user?.role === "admin",
    isHunter: user?.role === "hunter" || user?.role === "admin",
    logout,
  };
}

// ── Helper: authenticated fetch with CSRF header ──────────────────────────────
// Use this instead of bare fetch() for all API calls that mutate state.
// Automatically adds credentials + CSRF token.
export async function apiFetch(
  url: string,
  options: RequestInit = {},
): Promise<Response> {
  const method = (options.method ?? "GET").toUpperCase();
  const mutating = !["GET", "HEAD", "OPTIONS"].includes(method);

  return fetch(url, {
    ...options,
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
      ...(mutating ? { "X-CSRF-Token": getCsrfToken() } : {}),
      ...(options.headers as Record<string, string> | undefined),
    },
  });
}
