"use client";

import { useState, useEffect, useCallback } from "react";
import { cn } from "@/lib/utils";
import {
  Lightbulb, RefreshCw, AlertTriangle, Shield,
  Info, ChevronDown, ChevronUp, ExternalLink, Zap, Target,
} from "lucide-react";
import { useScanStore } from "@/lib/store";

interface Tip {
  id: string;
  category: string;
  title: string;
  body: string;
  severity: "high" | "medium" | "low";
  cwe?: string;
  references?: string[];
}

const SEVERITY_META = {
  high:   { color: "#ff3a5c", label: "HIGH",   icon: AlertTriangle },
  medium: { color: "#ff9b3a", label: "MED",    icon: Shield },
  low:    { color: "#54b35f", label: "LOW",    icon: Info },
};

const CATEGORY_COLORS: Record<string, string> = {
  XSS:      "#ff3a5c",
  SQLi:     "#ff9b3a",
  SSRF:     "#7c6aff",
  IDOR:     "#00e5cc",
  Auth:     "#54b35f",
  API:      "#4a8a9a",
  CORS:     "#ffcc3a",
  InfoLeak: "#c8d8e0",
  Recon:    "#8ab4c4",
  Report:   "#4a6a7a",
  CMS:      "#ff9b3a",
  Other:    "#4a6a7a",
};

function TipCard({ tip }: { tip: Tip }) {
  const [expanded, setExpanded] = useState(false);
  const sev = SEVERITY_META[tip.severity] ?? SEVERITY_META.low;
  const SevIcon = sev.icon;
  const catColor = CATEGORY_COLORS[tip.category] ?? "#4a6a7a";

  return (
    <div
      className={cn(
        "border rounded transition-all duration-200",
        "border-[#1a2a32] bg-[#0a1015] hover:border-[#2a3a42]",
      )}
    >
      <button
        className="w-full flex items-start gap-3 p-4 text-left"
        onClick={() => setExpanded(e => !e)}
      >
        {/* severity dot */}
        <div
          className="w-1.5 h-full min-h-[48px] rounded-full flex-shrink-0 mt-0.5"
          style={{ backgroundColor: sev.color }}
        />

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1 flex-wrap">
            <span
              className="text-[10px] font-bold px-1.5 py-0.5 rounded border uppercase tracking-widest"
              style={{ color: catColor, borderColor: catColor + "40", backgroundColor: catColor + "10" }}
            >
              {tip.category}
            </span>
            <span
              className="flex items-center gap-1 text-[10px] font-bold uppercase tracking-widest"
              style={{ color: sev.color }}
            >
              <SevIcon size={10} />
              {sev.label}
            </span>
            {tip.cwe && (
              <span className="text-[10px] text-[#4a6a7a] font-mono">{tip.cwe}</span>
            )}
          </div>
          <p className="text-[13px] text-[#c8d8e0] font-medium leading-snug pr-4">{tip.title}</p>
        </div>

        <div className="flex-shrink-0 text-[#4a6a7a] mt-1">
          {expanded ? <ChevronUp size={14} /> : <ChevronDown size={14} />}
        </div>
      </button>

      {expanded && (
        <div className="px-4 pb-4 pl-8 border-t border-[#1a2a32] pt-3">
          <p className="text-[12px] text-[#8ab4c4] leading-relaxed">{tip.body}</p>
          {tip.references && tip.references.length > 0 && (
            <div className="mt-3 flex flex-wrap gap-2">
              {tip.references.map((ref, i) => (
                <a
                  key={i}
                  href={ref}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center gap-1 text-[11px] text-[#7c6aff] hover:text-[#9c8aff] transition-colors"
                >
                  <ExternalLink size={10} />
                  {new URL(ref).hostname}
                </a>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function ContextualTip({ tip }: { tip: Tip }) {
  const sev = SEVERITY_META[tip.severity] ?? SEVERITY_META.low;
  const catColor = CATEGORY_COLORS[tip.category] ?? "#4a6a7a";
  return (
    <div className="border border-[#7c6aff]/40 bg-[#7c6aff]/5 rounded p-4">
      <div className="flex items-center gap-2 mb-2">
        <Zap size={13} className="text-[#7c6aff]" />
        <span className="text-[11px] font-bold text-[#7c6aff] uppercase tracking-widest">
          AI Contextual Hint
        </span>
        <span
          className="text-[10px] px-1.5 py-0.5 rounded border uppercase tracking-widest ml-auto"
          style={{ color: catColor, borderColor: catColor + "40", backgroundColor: catColor + "10" }}
        >
          {tip.category}
        </span>
        <span className="text-[10px] font-bold uppercase" style={{ color: sev.color }}>
          {sev.label}
        </span>
      </div>
      <p className="text-[13px] text-[#c8d8e0] font-medium mb-2">{tip.title}</p>
      <p className="text-[12px] text-[#8ab4c4] leading-relaxed">{tip.body}</p>
      {tip.cwe && (
        <p className="mt-2 text-[11px] text-[#4a6a7a] font-mono">{tip.cwe}</p>
      )}
    </div>
  );
}

const TOKEN = () =>
  typeof localStorage !== "undefined" ? localStorage.getItem("access_token") ?? "" : "";

export function TipsPanel() {
  const [tips, setTips]               = useState<Tip[]>([]);
  const [contextTip, setContextTip]   = useState<Tip | null>(null);
  const [loading, setLoading]         = useState(false);
  const [ctxLoading, setCtxLoading]   = useState(false);
  const [error, setError]             = useState("");
  const [techFilter, setTechFilter]   = useState("");
  const [date, setDate]               = useState("");
  const [fromCache, setFromCache]     = useState(false);

  const { scanID, stats, roe } = useScanStore();

  const fetchTips = useCallback(async (tech?: string) => {
    setLoading(true);
    setError("");
    try {
      const q = tech ? `?tech=${encodeURIComponent(tech)}` : "";
      const res = await fetch(`/api/v1/tips${q}`, {
        headers: { Authorization: `Bearer ${TOKEN()}` },
      });
      if (!res.ok) throw new Error(`${res.status}`);
      const data = await res.json();
      setTips(data.tips ?? []);
      setDate(data.date ?? "");
      setFromCache(data.cached ?? false);
    } catch (e: unknown) {
      setError(e instanceof Error ? e.message : "Failed to load tips");
    } finally {
      setLoading(false);
    }
  }, []);

  const fetchContextualTip = useCallback(async () => {
    if (!scanID || !roe) return;
    setCtxLoading(true);
    try {
      const res = await fetch("/api/v1/tips/contextual", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${TOKEN()}`,
        },
        body: JSON.stringify({
          target: roe.target,
          tech: techFilter,
          findings: [],
        }),
      });
      if (!res.ok) throw new Error(`${res.status}`);
      const data = await res.json();
      if (data.tip?.title) setContextTip(data.tip);
    } catch {
      // non-critical — contextual tip is bonus
    } finally {
      setCtxLoading(false);
    }
  }, [scanID, roe, techFilter]);

  useEffect(() => { fetchTips(); }, [fetchTips]);

  // Auto-fetch contextual tip when scan is active with findings
  useEffect(() => {
    if (scanID && stats.vulns > 0 && !contextTip) {
      fetchContextualTip();
    }
  }, [scanID, stats.vulns, contextTip, fetchContextualTip]);

  const handleTechSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    fetchTips(techFilter);
    setContextTip(null);
  };

  return (
    <div className="flex flex-col h-full overflow-hidden">
      {/* Header */}
      <div className="flex items-center justify-between px-4 py-3 border-b border-[#1a2a32] bg-[#080c0e] flex-shrink-0">
        <div className="flex items-center gap-2">
          <Lightbulb size={14} className="text-[#ffcc3a]" />
          <span className="text-[11px] font-bold text-[#c8d8e0] uppercase tracking-widest">
            Daily Tips
          </span>
          {date && (
            <span className="text-[10px] text-[#4a6a7a] font-mono">{date}</span>
          )}
          {fromCache && (
            <span className="text-[10px] text-[#4a6a7a] border border-[#1a2a32] rounded px-1">
              cached
            </span>
          )}
        </div>
        <button
          onClick={() => fetchTips(techFilter)}
          disabled={loading}
          className={cn(
            "flex items-center gap-1.5 px-3 py-1.5 rounded text-[11px] font-semibold uppercase tracking-widest",
            "border border-[#1a2a32] text-[#4a8a9a] hover:text-[#00e5cc] hover:border-[#00e5cc]/40 transition-all",
            loading && "opacity-50 cursor-not-allowed",
          )}
        >
          <RefreshCw size={11} className={loading ? "animate-spin" : ""} />
          Refresh
        </button>
      </div>

      {/* Tech filter */}
      <form
        onSubmit={handleTechSubmit}
        className="flex items-center gap-2 px-4 py-2 border-b border-[#1a2a32] bg-[#0a1015] flex-shrink-0"
      >
        <Target size={11} className="text-[#4a6a7a] flex-shrink-0" />
        <input
          type="text"
          value={techFilter}
          onChange={e => setTechFilter(e.target.value)}
          placeholder="Filter by tech stack (e.g. nginx,php,wordpress)"
          className="flex-1 bg-transparent text-[12px] text-[#c8d8e0] placeholder-[#4a6a7a] outline-none font-mono"
        />
        <button
          type="submit"
          className="text-[11px] px-2 py-0.5 rounded border border-[#1a2a32] text-[#7c6aff] hover:border-[#7c6aff]/40 transition-colors"
        >
          Apply
        </button>
      </form>

      <div className="flex-1 overflow-y-auto p-4 space-y-3">
        {/* Contextual tip from active scan */}
        {ctxLoading && (
          <div className="border border-[#7c6aff]/20 rounded p-4 animate-pulse">
            <div className="flex items-center gap-2">
              <Zap size={12} className="text-[#7c6aff]" />
              <span className="text-[11px] text-[#7c6aff]">Generating contextual hint...</span>
            </div>
          </div>
        )}
        {contextTip && !ctxLoading && (
          <ContextualTip tip={contextTip} />
        )}
        {scanID && stats.vulns > 0 && !contextTip && !ctxLoading && (
          <button
            onClick={fetchContextualTip}
            className="w-full border border-dashed border-[#7c6aff]/30 rounded p-3 text-[12px] text-[#7c6aff] hover:border-[#7c6aff]/60 transition-colors flex items-center justify-center gap-2"
          >
            <Zap size={12} />
            Generate contextual hint for current scan ({stats.vulns} findings)
          </button>
        )}

        {/* Error */}
        {error && (
          <div className="border border-[#ff3a5c]/30 bg-[#ff3a5c]/5 rounded p-3 text-[12px] text-[#ff3a5c]">
            {error}
          </div>
        )}

        {/* Loading skeleton */}
        {loading && tips.length === 0 && (
          <div className="space-y-3">
            {[...Array(5)].map((_, i) => (
              <div key={i} className="border border-[#1a2a32] rounded p-4 animate-pulse bg-[#0a1015]">
                <div className="flex gap-2 mb-2">
                  <div className="h-4 w-14 bg-[#1a2a32] rounded" />
                  <div className="h-4 w-10 bg-[#1a2a32] rounded" />
                </div>
                <div className="h-4 bg-[#1a2a32] rounded w-3/4" />
              </div>
            ))}
          </div>
        )}

        {/* Tips list */}
        {!loading && tips.length === 0 && !error && (
          <div className="text-center py-16 text-[#4a6a7a] text-[12px]">
            No tips loaded. Click Refresh.
          </div>
        )}
        {tips.map(tip => (
          <TipCard key={tip.id} tip={tip} />
        ))}
      </div>

      {/* Footer */}
      <div className="px-4 py-2 border-t border-[#1a2a32] bg-[#080c0e] flex-shrink-0 text-[10px] text-[#4a6a7a]">
        Tips are AI-generated and cached 24h. Always verify findings manually before reporting.
      </div>
    </div>
  );
}
