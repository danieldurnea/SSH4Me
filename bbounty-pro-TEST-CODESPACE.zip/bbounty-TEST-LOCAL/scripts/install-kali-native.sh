#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
# DEPRECATED — Nu mai folosi acest script!
#
# Kali containerul a fost eliminat în BBounty Pro v3.3-zen.
# Toate cele 78 tooluri rulează nativ pe Ubuntu 22.04/24.04 LTS.
#
# Folosește în schimb:
#   sudo bash scripts/install-ubuntu.sh
#   sudo bash scripts/fix-failed-tools.sh
#
# Motive eliminare Kali container:
#   - 4-6 GB imagine Docker (inutil)
#   - Rula ca root (risc major de securitate)
#   - Network egress nelimitat
#   - Toate toolurile funcționează pe Ubuntu nativ
# ─────────────────────────────────────────────────────────────────────────────
echo "❌ DEPRECATED: acest script nu mai e folosit."
echo "   Folosește: sudo bash scripts/install-ubuntu.sh"
exit 1
