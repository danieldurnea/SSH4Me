#!/usr/bin/env bash
# .devcontainer/setup.sh — rulat O SINGURĂ DATĂ la crearea Codespace
set -euo pipefail

echo "🔧 BBounty Pro — Codespace Setup..."

# ── Python deps ───────────────────────────────────────────────────────────────
echo "📦 Instalez Python dependencies..."
pip install --quiet --upgrade \
    fastapi uvicorn[standard] \
    google-generativeai \
    pydantic slowapi \
    python-dotenv

# ── Go tools ─────────────────────────────────────────────────────────────────
echo "🔨 Instalez Go tools..."
export GOPATH="$HOME/go"
export PATH="$PATH:$GOPATH/bin"

go install github.com/projectdiscovery/subfinder/v2/cmd/subfinder@latest  2>/dev/null || true
go install github.com/projectdiscovery/httpx/cmd/httpx@latest             2>/dev/null || true
go install github.com/projectdiscovery/nuclei/v3/cmd/nuclei@latest        2>/dev/null || true
go install github.com/ffuf/ffuf/v2@latest                                  2>/dev/null || true
go install github.com/tomnomnom/waybackurls@latest                         2>/dev/null || true
go install github.com/tomnomnom/anew@latest                                2>/dev/null || true
go install github.com/hahwul/dalfox/v2@latest                             2>/dev/null || true
go install github.com/projectdiscovery/katana/cmd/katana@latest           2>/dev/null || true

echo "export PATH=\$PATH:\$HOME/go/bin" >> "$HOME/.bashrc"

# ── pnpm + Node deps ──────────────────────────────────────────────────────────
echo "📦 Instalez Node dependencies..."
npm install -g pnpm --quiet 2>/dev/null || true

if [[ -f "apps/web/package.json" ]]; then
    cd apps/web
    pnpm install --silent 2>/dev/null || npm install --silent
    cd ../..
fi

# ── Go orchestrator ───────────────────────────────────────────────────────────
echo "🔨 Compilez orchestratorul Go..."
if [[ -f "apps/orchestrator/go.mod" ]]; then
    cd apps/orchestrator
    go mod download 2>/dev/null || true
    go build -o ../../orchestrator ./cmd/server/ 2>/dev/null || echo "⚠️ Build orchestrator — skip"
    cd ../..
fi

# ── Redis config ──────────────────────────────────────────────────────────────
mkdir -p "$HOME/.bbounty"
cat > "$HOME/.bbounty/redis.conf" << 'EOF'
requirepass testpass123
maxmemory 256mb
maxmemory-policy allkeys-lru
daemonize no
loglevel warning
EOF

# ── .env pentru Codespace ─────────────────────────────────────────────────────
if [[ ! -f ".env" ]]; then
    cat > ".env" << 'ENVEOF'
# BBounty Pro — Codespace Config
# IMPORTANT: Setează GEMINI_API_KEY în:
# Settings → Secrets and variables → Codespaces → New secret
TEST_MODE=true
NO_AUTH=true
GEMINI_MODEL=gemini-1.5-flash
REDIS_URL=redis://:testpass123@localhost:6379
FRONTEND_URL=http://localhost:3000
AI_PROXY_URL=http://localhost:8001
JWT_SECRET=codespace-jwt-not-for-production
AUDIT_HMAC_SECRET=codespace-hmac-not-for-production
CORS_ORIGINS=http://localhost:3000
POSTGRES_DISABLED=true
ENVEOF
    echo "⚠️  Setează GEMINI_API_KEY în GitHub Codespaces Secrets!"
fi

# ── Nuclei templates ──────────────────────────────────────────────────────────
if command -v nuclei &>/dev/null; then
    nuclei -update-templates -silent 2>/dev/null || true
fi

echo ""
echo "✅ Setup complet!"
echo "   Pornire: bash .devcontainer/start-services.sh"
echo "   sau: pnpm dev (frontend only)"
