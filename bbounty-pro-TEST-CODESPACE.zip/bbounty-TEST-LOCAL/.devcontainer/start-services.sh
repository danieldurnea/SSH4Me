#!/usr/bin/env bash
# .devcontainer/start-services.sh — rulat la FIECARE pornire Codespace
set -euo pipefail

CYAN='\033[0;36m'; GREEN='\033[0;32m'; YELLOW='\033[1;33m'; NC='\033[0m'; BOLD='\033[1m'

echo -e "${BOLD}${CYAN}BBounty Pro — Codespace Starting...${NC}\n"

# Încarcă .env
set -a; source .env 2>/dev/null || true; set +a
export PATH="$PATH:$HOME/go/bin"

# Verifică GEMINI_API_KEY
if [[ -z "${GEMINI_API_KEY:-}" ]]; then
    echo -e "${YELLOW}⚠️  GEMINI_API_KEY nu e setat!${NC}"
    echo -e "   Mergi la: ${CYAN}Settings → Secrets → Codespaces → New secret${NC}"
    echo -e "   Cheie gratuită: ${CYAN}https://aistudio.google.com/app/apikey${NC}\n"
fi

# ── Redis ─────────────────────────────────────────────────────────────────────
if command -v redis-server &>/dev/null; then
    redis-server "$HOME/.bbounty/redis.conf" --daemonize yes \
                 --pidfile "$HOME/.bbounty/redis.pid" \
                 --logfile "$HOME/.bbounty/redis.log" 2>/dev/null || true
    sleep 0.5
    if redis-cli -a testpass123 ping &>/dev/null 2>&1; then
        echo -e "${GREEN}[✓]${NC} Redis pornit"
    else
        echo -e "${YELLOW}[!]${NC} Redis — poate e deja pornit"
    fi
fi

# ── AI Proxy Gemini ───────────────────────────────────────────────────────────
if [[ -f "apps/ai-proxy/main.py" ]]; then
    pkill -f "uvicorn.*main:app" 2>/dev/null || true
    sleep 0.3
    cd apps/ai-proxy
    GEMINI_API_KEY="${GEMINI_API_KEY:-}" \
    uvicorn main:app --host 0.0.0.0 --port 8001 \
        --log-level warning > "$HOME/.bbounty/ai-proxy.log" 2>&1 &
    echo $! > "$HOME/.bbounty/ai-proxy.pid"
    cd ../..
    sleep 1
    if curl -sf http://localhost:8001/health &>/dev/null; then
        echo -e "${GREEN}[✓]${NC} AI Proxy Gemini → http://localhost:8001"
    else
        echo -e "${YELLOW}[!]${NC} AI Proxy pornit (verifică logul)"
    fi
fi

# ── Orchestrator Go ───────────────────────────────────────────────────────────
if [[ -f "orchestrator" ]]; then
    pkill -f "./orchestrator" 2>/dev/null || true
    sleep 0.3
    ENV=test NO_AUTH=true \
    ./orchestrator > "$HOME/.bbounty/orchestrator.log" 2>&1 &
    echo $! > "$HOME/.bbounty/orchestrator.pid"
    sleep 1
    if curl -sf http://localhost:8080/healthz &>/dev/null; then
        echo -e "${GREEN}[✓]${NC} Orchestrator Go → http://localhost:8080"
    else
        echo -e "${YELLOW}[!]${NC} Orchestrator pornit (verifică logul)"
    fi
elif [[ -f "apps/orchestrator/go.mod" ]]; then
    echo -e "${YELLOW}[!]${NC} Orchestrator necompilit — rulează: cd apps/orchestrator && go run ./cmd/server/"
fi

# ── Frontend Next.js ──────────────────────────────────────────────────────────
echo ""
echo -e "${BOLD}${GREEN}════════════════════════════════════════${NC}"
echo -e "${BOLD}${GREEN}  ✓ Servicii pornite!${NC}"
echo -e "${BOLD}${GREEN}════════════════════════════════════════${NC}"
echo ""
echo -e "  ${CYAN}Frontend:${NC}  cd apps/web && pnpm dev"
echo -e "  ${CYAN}AI Proxy:${NC}  http://localhost:8001/health"
echo -e "  ${CYAN}API:${NC}       http://localhost:8080/healthz"
echo ""
echo -e "  ${YELLOW}Logs:${NC}"
echo -e "  tail -f $HOME/.bbounty/ai-proxy.log"
echo -e "  tail -f $HOME/.bbounty/orchestrator.log"
echo ""
