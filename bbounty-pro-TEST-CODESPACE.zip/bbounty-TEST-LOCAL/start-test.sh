#!/usr/bin/env bash
# ─────────────────────────────────────────────────────────────────────────────
#  BBounty Pro — START LOCAL TEST
#  Rulează: bash start-test.sh
# ─────────────────────────────────────────────────────────────────────────────

set -euo pipefail

CYAN='\033[0;36m'; GREEN='\033[0;32m'; RED='\033[0;31m'; BOLD='\033[1m'; NC='\033[0m'

echo -e "${BOLD}${CYAN}"
echo "  ╔══════════════════════════════════════════╗"
echo "  ║   BBounty Pro — Local Test Mode          ║"
echo "  ║   Gemini Only · No Login · No Postgres   ║"
echo "  ╚══════════════════════════════════════════╝"
echo -e "${NC}"

# Verifică că .env.test are GEMINI_API_KEY completat
if [[ ! -f .env.test ]]; then
    echo -e "${RED}Eroare: .env.test nu există!${NC}"
    echo "Copiază: cp .env.test.example .env.test și completează GEMINI_API_KEY"
    exit 1
fi

source .env.test 2>/dev/null || true

if [[ -z "${GEMINI_API_KEY:-}" ]]; then
    echo -e "${RED}Eroare: GEMINI_API_KEY nu e setat în .env.test!${NC}"
    echo -e "Obții cheia gratuit la: ${CYAN}https://aistudio.google.com/app/apikey${NC}"
    exit 1
fi

echo -e "${GREEN}[✓]${NC} GEMINI_API_KEY detectat"

# Pornește serviciile
echo -e "\n${CYAN}Pornind serviciile...${NC}\n"
cd infra
docker compose -f docker-compose.test.yml --env-file ../.env.test up --build -d

echo -e "\n${GREEN}${BOLD}════════════════════════════════════════${NC}"
echo -e "${GREEN}${BOLD}  ✓ BBounty Pro Test — PORNIT!${NC}"
echo -e "${GREEN}${BOLD}════════════════════════════════════════${NC}"
echo ""
echo -e "  Dashboard:  ${CYAN}http://localhost:3000${NC}  ← fără login"
echo -e "  API:        ${CYAN}http://localhost:8080${NC}"
echo -e "  AI Proxy:   ${CYAN}http://localhost:8001/health${NC}"
echo ""
echo -e "  Oprire: ${CYAN}docker compose -f infra/docker-compose.test.yml down${NC}"
echo ""
